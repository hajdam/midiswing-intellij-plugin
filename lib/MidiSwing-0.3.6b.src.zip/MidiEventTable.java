import javax.swing.table.AbstractTableModel;
import javax.swing.JOptionPane;
import java.awt.event.ActionEvent;
import java.awt.GridBagConstraints;
import java.awt.Component;
import javax.swing.JScrollPane;
import java.awt.Dimension;
import javax.swing.table.TableModel;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import javax.swing.JPanel;

// 
// Decompiled by Procyon v0.5.30
// 

public class MidiEventTable extends JPanel implements ActionListener
{
    private boolean DEBUG;
    MidiSwing midiSwing;
    private JTable table;
    private MyTableModel model;
    private JButton del;
    private JButton ins;
    
    public MidiEventTable(final MidiSwing midiSwing) {
        super(new GridBagLayout());
        this.DEBUG = false;
        this.midiSwing = midiSwing;
        this.model = new MyTableModel(this.midiSwing);
        (this.table = new JTable(this.model)).setPreferredScrollableViewportSize(new Dimension(500, 70));
        final MidiSwing midiSwing2 = this.midiSwing;
        (this.del = new JButton(MidiSwing.resource.getString("DELETE"))).setActionCommand("removeLine");
        this.del.addActionListener(this);
        (this.ins = new JButton("Insert")).setActionCommand("insertLine");
        this.ins.addActionListener(this);
        final JScrollPane scrollPane = new JScrollPane(this.table);
        final GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weighty = 0.9;
        gridBagConstraints.fill = 1;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 2;
        this.add(scrollPane, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.weighty = 0.1;
        gridBagConstraints.gridwidth = 1;
        gridBagConstraints.fill = 0;
        gridBagConstraints.anchor = 22;
        this.add(this.ins, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        this.add(this.del, gridBagConstraints);
    }
    
    public void update() {
        this.model.fireTableStructureChanged();
    }
    
    public void actionPerformed(final ActionEvent actionEvent) {
        if ("removeLine".equals(actionEvent.getActionCommand())) {
            final int selectedRow = this.table.getSelectedRow();
            if (selectedRow >= 0) {
                this.midiSwing.getTrack(this.midiSwing.currentTrack).remove(this.midiSwing.getTrack(this.midiSwing.currentTrack).get(selectedRow));
                this.update();
            }
        }
        else if ("insertLine".equals(actionEvent.getActionCommand())) {
            JOptionPane.showMessageDialog(this, "Insert Line", "Not Implemented", 2);
        }
    }
    
    class MyTableModel extends AbstractTableModel
    {
        private MidiSwing midiSwing;
        private String[] columnNames;
        
        public MyTableModel(final MidiSwing midiSwing) {
            final String[] columnNames = new String[5];
            final int n = 0;
            final MidiSwing midiSwing2 = this.midiSwing;
            columnNames[n] = MidiSwing.resource.getString("TIME_STAMP_COLUMN");
            final int n2 = 1;
            final MidiSwing midiSwing3 = this.midiSwing;
            columnNames[n2] = MidiSwing.resource.getString("EVENT_COLUMN");
            final int n3 = 2;
            final MidiSwing midiSwing4 = this.midiSwing;
            columnNames[n3] = MidiSwing.resource.getString("CHANNEL_COLUMN");
            final int n4 = 3;
            final MidiSwing midiSwing5 = this.midiSwing;
            columnNames[n4] = MidiSwing.resource.getString("TYPE_COLUMN");
            final int n5 = 4;
            final MidiSwing midiSwing6 = this.midiSwing;
            columnNames[n5] = MidiSwing.resource.getString("VALUE_COLUMN");
            this.columnNames = columnNames;
            this.midiSwing = midiSwing;
        }
        
        public int getColumnCount() {
            return this.columnNames.length;
        }
        
        public int getRowCount() {
            return this.midiSwing.getTrackLength(this.midiSwing.currentTrack);
        }
        
        public String getColumnName(final int n) {
            return this.columnNames[n];
        }
        
        public Object getValueAt(final int n, final int n2) {
            return this.midiSwing.getEventInfo(this.midiSwing.getEvent(this.midiSwing.currentTrack, n))[n2];
        }
        
        public Class getColumnClass(final int n) {
            return this.getValueAt(0, n).getClass();
        }
        
        public boolean isCellEditable(final int n, final int n2) {
            return n2 == 0;
        }
        
        public void setValueAt(final Object o, final int n, final int n2) {
            switch (n2) {
                case 0: {
                    this.midiSwing.getTrack(this.midiSwing.currentTrack).get(n).setTick(Integer.parseInt((String)o));
                    break;
                }
            }
        }
    }
}
