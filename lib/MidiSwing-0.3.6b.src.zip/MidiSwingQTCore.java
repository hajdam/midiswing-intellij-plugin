import javax.sound.midi.ShortMessage;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.Transmitter;
import java.util.List;
import javax.sound.midi.Receiver;
import javax.sound.midi.MidiDevice;
import quicktime.QTException;
import quicktime.QTSession;
import com.apple.component.ComponentDescription;
import java.io.File;
import java.util.Vector;
import com.apple.audio.toolbox.AUNode;
import com.apple.audio.units.MusicDevice;
import com.apple.audio.toolbox.AUGraph;

// 
// Decompiled by Procyon v0.5.30
// 

public class MidiSwingQTCore extends MidiSwingQT
{
    private static AUGraph myAUGraph;
    private static MusicDevice[] musicSynth;
    private static AUNode[] synth;
    private static AUNode[] limiter;
    private static boolean[] soundBankLoaded;
    private static Vector soundBankFileList;
    private static Vector soundBankNameList;
    private static Vector soundBankInstrumentKitList;
    private int quickTimeInstrumentsNumber;
    private static String soundBankDirectory;
    
    public MidiSwingQTCore(final int n, final File file, final int n2) {
        super(n, file, n2);
    }
    
    public void setupMidi() {
        super.setupMidi();
        this.quickTimeInstrumentsNumber = this.midiOutputs.size();
        this.defaultOutputNumber = this.quickTimeInstrumentsNumber;
        for (int i = 0; i < MidiSwingQTCore.soundBankFileList.size(); ++i) {
            this.midiOutputs.add(new CoreAudioMidiDevice(MidiSwingQTCore.musicSynth[i], (String)MidiSwingQTCore.soundBankFileList.get(i), (String)MidiSwingQTCore.soundBankNameList.get(i)));
            MidiSwingQTCore.instrumentKitList.add(MidiSwingQTCore.soundBankInstrumentKitList.get(i));
        }
    }
    
    private static void setupCoreAudio() {
        try {
            MidiSwingQTCore.soundBankDirectory = System.getProperty("user.home") + "/Library/Audio/Sounds/Banks";
            MidiSwingQTCore.soundBankFileList = new Vector();
            MidiSwingQTCore.soundBankNameList = new Vector();
            MidiSwingQTCore.soundBankInstrumentKitList = new Vector();
            MidiSwingQTCore.soundBankFileList.addElement("");
            MidiSwingQTCore.soundBankNameList.addElement(MidiSwingQTCore.resource.getString("QUICKTIME_MUSICAL_INSTRUMENTS"));
            MidiSwingQTCore.soundBankInstrumentKitList.addElement(MidiSwingQTCore.GM_Kit);
            findSoundBanks(MidiSwingQTCore.soundBankDirectory);
            final int size = MidiSwingQTCore.soundBankFileList.size();
            MidiSwingQTCore.myAUGraph = new AUGraph();
            MidiSwingQTCore.synth = new AUNode[size];
            MidiSwingQTCore.limiter = new AUNode[size];
            MidiSwingQTCore.musicSynth = new MusicDevice[size];
            MidiSwingQTCore.soundBankLoaded = new boolean[size];
            for (int i = 0; i < size; ++i) {
                final ComponentDescription componentDescription = new ComponentDescription(1635085940, 1836413796, 1684828960, 0, 0);
                MidiSwingQTCore.synth[i] = MidiSwingQTCore.myAUGraph.newNode(componentDescription);
                componentDescription.setSubType(1701208948);
                componentDescription.setManufacturer(1819112562);
                MidiSwingQTCore.limiter[i] = MidiSwingQTCore.myAUGraph.newNode(componentDescription);
                MidiSwingQTCore.soundBankLoaded[i] = false;
            }
            final ComponentDescription componentDescription2 = new ComponentDescription(1635085940, 1835628658, 1936554098, 0, 0);
            final AUNode node = MidiSwingQTCore.myAUGraph.newNode(componentDescription2);
            componentDescription2.setSubType(1869968416);
            componentDescription2.setManufacturer(1684366880);
            final AUNode node2 = MidiSwingQTCore.myAUGraph.newNode(componentDescription2);
            MidiSwingQTCore.myAUGraph.open();
            MidiSwingQTCore.myAUGraph.initialize();
            for (int j = 0; j < size; ++j) {
                MidiSwingQTCore.musicSynth[j] = (MusicDevice)MidiSwingQTCore.myAUGraph.getNodeInfo_AudioUnit(MidiSwingQTCore.synth[j]);
                MidiSwingQTCore.myAUGraph.connectNodeInput(MidiSwingQTCore.synth[j], 0, MidiSwingQTCore.limiter[j], 0);
                MidiSwingQTCore.myAUGraph.connectNodeInput(MidiSwingQTCore.limiter[j], 0, node, j + 1);
            }
            MidiSwingQTCore.myAUGraph.connectNodeInput(node, 0, node2, 0);
            while (!MidiSwingQTCore.myAUGraph.update(false)) {
                Thread.yield();
            }
            MidiSwingQTCore.myAUGraph.start();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    void cleanUp() {
        try {
            if (MidiSwingQTCore.myAUGraph != null) {
                MidiSwingQTCore.myAUGraph.stop();
                MidiSwingQTCore.myAUGraph.uninitialize();
                MidiSwingQTCore.myAUGraph.close();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    static void findSoundBanks(final String s) {
        final File file = new File(s);
        if (!file.exists()) {
            return;
        }
        final String[] list = file.list();
        if (list.length == 0) {
            return;
        }
        final Vector vector = new Vector();
        for (int i = 0; i < list.length; ++i) {
            final String s2 = list[i];
            if (MidiSwingQTCore.debug) {
                System.out.println("File : " + s2);
            }
            if (s2.endsWith(".dls") || s2.endsWith(".DLS")) {
                MidiSwingQTCore.soundBankFileList.addElement(s + File.separator + s2);
                MidiSwingQTCore.soundBankNameList.addElement(s2);
                MidiSwingQTCore.soundBankInstrumentKitList.addElement(MidiSwingQTCore.GM_Kit);
            }
            if (s2.endsWith(".sf2") || s2.endsWith(".SF2")) {
                final String string = s + File.separator + s2;
                MidiSwingQTCore.soundBankFileList.addElement(string);
                final SoundFont soundFont = new SoundFont(new File(string));
                MidiSwingQTCore.soundBankNameList.addElement("Core Audio " + soundFont.getName());
                MidiSwingQTCore.soundBankInstrumentKitList.addElement(soundFont.getKit());
            }
        }
    }
    
    public static void initializeQTCore() {
        System.out.println("QuickTime - Core Audio");
        System.setProperty("apple.laf.useScreenMenuBar", "true");
        try {
            QTSession.open();
        }
        catch (QTException ex) {
            ex.printStackTrace();
            QTSession.close();
        }
        setupCoreAudio();
    }
    
    public static void main(final String[] array) {
        initialize();
        initializeQTCore();
        MidiSwingQTCore.numberOfWindows = 0;
        if (array.length == 1) {
            new MidiSwingQTCore(0, new File(array[0]), 1);
        }
        else {
            new MidiSwingQTCore(0, null, 1);
        }
    }
    
    public class CoreAudioMidiDevice implements MidiDevice
    {
        public MusicDevice musicDevice;
        String soundBankFileName;
        public CoreAudioMidiDeviceInfo info;
        public Receiver receiver;
        private boolean isOpen;
        
        public CoreAudioMidiDevice(final MusicDevice musicDevice, final String soundBankFileName, final String s) {
            this.musicDevice = musicDevice;
            this.soundBankFileName = soundBankFileName;
            this.info = new CoreAudioMidiDeviceInfo(s, new String(""), new String("Core Audio Music Device"), new String(""));
            this.isOpen = false;
            this.receiver = new CoreAudioReceiver(musicDevice);
        }
        
        public void close() {
            this.isOpen = false;
        }
        
        public Info getDeviceInfo() {
            return this.info;
        }
        
        public int getMaxReceivers() {
            return 1;
        }
        
        public int getMaxTransmitters() {
            return 0;
        }
        
        public long getMicrosecondPosition() {
            return 0L;
        }
        
        public Receiver getReceiver() {
            return this.receiver;
        }
        
        public List<Receiver> getReceivers() {
            return null;
        }
        
        public Transmitter getTransmitter() {
            return null;
        }
        
        public List<Transmitter> getTransmitters() {
            return null;
        }
        
        public boolean isOpen() {
            return this.isOpen;
        }
        
        public void open() {
            if (!this.isOpen) {
                if (this.soundBankFileName != "") {
                    try {
                        this.musicDevice.setProperty_SoundBank(new File(this.soundBankFileName));
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                this.isOpen = true;
            }
        }
        
        public String getBankFilename() {
            return this.soundBankFileName;
        }
        
        public class CoreAudioMidiDeviceInfo extends Info
        {
            public CoreAudioMidiDeviceInfo(final String s, final String s2, final String s3, final String s4) {
                super(s, s2, s3, s4);
            }
        }
        
        public class CoreAudioReceiver implements Receiver
        {
            private MusicDevice ReceiversMusicDevice;
            
            public CoreAudioReceiver(final MusicDevice receiversMusicDevice) {
                this.ReceiversMusicDevice = receiversMusicDevice;
            }
            
            public void close() {
            }
            
            public void send(final MidiMessage midiMessage, final long n) {
                if (midiMessage instanceof ShortMessage) {
                    final int command = ((ShortMessage)midiMessage).getCommand();
                    final int channel = ((ShortMessage)midiMessage).getChannel();
                    final int data1 = ((ShortMessage)midiMessage).getData1();
                    final int data2 = ((ShortMessage)midiMessage).getData2();
                    try {
                        this.ReceiversMusicDevice.sendMIDIEvent(command + channel, data1, data2, 0);
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
    }
}
