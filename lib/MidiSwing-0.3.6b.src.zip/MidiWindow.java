import javax.swing.text.html.HTMLDocument;
import javax.swing.text.html.HTMLFrameHyperlinkEvent;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.JEditorPane;
import java.awt.event.WindowEvent;
import java.awt.event.KeyEvent;
import javax.swing.filechooser.FileFilter;
import javax.swing.JScrollPane;
import java.net.URLEncoder;
import java.net.URL;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.JMenu;
import java.awt.Toolkit;
import javax.swing.JTabbedPane;
import java.awt.Component;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Dimension;
import java.io.File;
import java.awt.event.ActionEvent;
import java.awt.Insets;
import javax.swing.Icon;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JFileChooser;
import javax.swing.JComboBox;
import javax.swing.JToggleButton;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JSlider;
import javax.swing.JProgressBar;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.WindowListener;
import javax.swing.JFrame;

// 
// Decompiled by Procyon v0.5.30
// 

public class MidiWindow extends JFrame implements WindowListener, KeyListener, ActionListener
{
    public MidiSwing midiSwing;
    public PianoRoll pianoRoll;
    public MidiEventTable midiEventTable;
    public JProgressBar progressBar;
    public JSlider tempoSlider;
    public JTextField tempoField;
    public JButton tempoButton;
    public JToggleButton[] channelButton;
    public JToggleButton[] channelButton2;
    public JComboBox trackChooser;
    public JComboBox outputChooser;
    private JButton buttonPlay;
    public JToggleButton buttonRecord;
    public JToggleButton buttonLoop;
    protected JFileChooser chooser;
    protected JMenuBar menuBar;
    protected JPanel topPane;
    private MidiFilter midiFilter;
    private LyricsFilter lyricsFilter;
    public boolean shortcutKey;
    public boolean altKey;
    public InputOptions inputOptions;
    public OutputOptions outputOptions;
    public JFrame sendFrame;
    public JTextArea textArea;
    public JTextField textField;
    public JMenuItem addTrackMenuItem;
    public JMenuItem deleteTrackMenuItem;
    public JMenuItem convertToSMF0menuItem;
    public JMenuItem convertToSMF1menuItem;
    public JCheckBoxMenuItem pianoRollMenuItem;
    public JCheckBoxMenuItem keyboardMenuItem;
    public JRadioButtonMenuItem[] outputMenuItem;
    public JRadioButtonMenuItem[] inputMenuItem;
    public JRadioButtonMenuItem singleTrackDisplayMenuItem;
    public JCheckBoxMenuItem attachDataToNotesMenuItem;
    protected ImageIcon[] buttonIcon;
    protected ImageIcon[] buttonPressedIcon;
    protected ImageIcon pointerBlackIcon;
    protected ImageIcon pointerGreyIcon;
    protected ImageIcon pointerEmptyIcon;
    public static final Color[] channelColor;
    
    public static Color velocityColor(final Color color, final long n) {
        final double n2 = n / 127.0;
        final double n3 = 1.0 - n / 127.0;
        return new Color((int)Math.floor(n2 * color.getRed() + n3 * 255.0), (int)Math.floor(n2 * color.getGreen() + n3 * 255.0), (int)Math.floor(n2 * color.getBlue() + n3 * 255.0));
    }
    
    public void fireEvent(final Event event) {
        this.midiSwing.eventReceived(event);
    }
    
    public void setPlayPosition(final long n, final boolean b) {
        this.progressBar.setValue((int)n);
        this.pianoRoll.setPlayPosition(n, b);
        this.updateTempoField();
    }
    
    private void updateTempoField() {
        long tempo = this.midiSwing.getTempo();
        if (tempo == -1L) {
            tempo = 500000L;
        }
        final double n = this.tempoSlider.getValue();
        this.midiSwing.setTempoFactor((n - 50.0) / 50.0);
        final String value = String.valueOf(Math.round(Math.exp(2.2 * (n - 50.0) / 50.0) * 6.0E7 / tempo));
        if (!String.valueOf(this.tempoField.getText()).equals(value)) {
            this.tempoField.setText("" + value);
        }
    }
    
    public MidiWindow(final MidiSwing midiSwing, final String s) {
        super(s);
        this.pointerBlackIcon = new ImageIcon(this.getClass().getClassLoader().getResource("images/pointerBlack.gif"));
        this.pointerGreyIcon = new ImageIcon(this.getClass().getClassLoader().getResource("images/pointerGrey.gif"));
        this.pointerEmptyIcon = new ImageIcon(this.getClass().getClassLoader().getResource("images/pointerEmpty.gif"));
        (this.buttonIcon = new ImageIcon[16])[0] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button01.gif"));
        this.buttonIcon[1] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button02.gif"));
        this.buttonIcon[2] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button03.gif"));
        this.buttonIcon[3] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button04.gif"));
        this.buttonIcon[4] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button05.gif"));
        this.buttonIcon[5] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button06.gif"));
        this.buttonIcon[6] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button07.gif"));
        this.buttonIcon[7] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button08.gif"));
        this.buttonIcon[8] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button09.gif"));
        this.buttonIcon[9] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button10.gif"));
        this.buttonIcon[10] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button11.gif"));
        this.buttonIcon[11] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button12.gif"));
        this.buttonIcon[12] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button13.gif"));
        this.buttonIcon[13] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button14.gif"));
        this.buttonIcon[14] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button15.gif"));
        this.buttonIcon[15] = new ImageIcon(this.getClass().getClassLoader().getResource("images/button16.gif"));
        (this.buttonPressedIcon = new ImageIcon[16])[0] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected01.gif"));
        this.buttonPressedIcon[1] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected02.gif"));
        this.buttonPressedIcon[2] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected03.gif"));
        this.buttonPressedIcon[3] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected04.gif"));
        this.buttonPressedIcon[4] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected05.gif"));
        this.buttonPressedIcon[5] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected06.gif"));
        this.buttonPressedIcon[6] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected07.gif"));
        this.buttonPressedIcon[7] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected08.gif"));
        this.buttonPressedIcon[8] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected09.gif"));
        this.buttonPressedIcon[9] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected10.gif"));
        this.buttonPressedIcon[10] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected11.gif"));
        this.buttonPressedIcon[11] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected12.gif"));
        this.buttonPressedIcon[12] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected13.gif"));
        this.buttonPressedIcon[13] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected14.gif"));
        this.buttonPressedIcon[14] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected15.gif"));
        this.buttonPressedIcon[15] = new ImageIcon(this.getClass().getClassLoader().getResource("images/buttonSelected16.gif"));
        this.midiSwing = midiSwing;
        final MidiSwing midiSwing2 = this.midiSwing;
        if (MidiSwing.debug) {
            System.out.println("Starting the graphical interface...");
        }
        this.setFocusable(true);
        this.requestFocus();
        this.addWindowListener(this);
        this.addKeyListener(this);
        (this.buttonRecord = new JToggleButton(new ImageIcon(this.getClass().getClassLoader().getResource("images/record.gif")))).setMargin(new Insets(10, 20, 10, 20));
        this.buttonRecord.setForeground(new Color(255, 0, 0));
        this.buttonRecord.setFocusable(false);
        (this.buttonLoop = new JToggleButton(new ImageIcon(this.getClass().getClassLoader().getResource("images/loop.gif")))).setMargin(new Insets(10, 20, 10, 20));
        this.buttonLoop.setForeground(new Color(255, 0, 0));
        this.buttonLoop.setFocusable(false);
        final JButton button = new JButton(new ImageIcon(this.getClass().getClassLoader().getResource("images/rewind.gif")));
        button.setMargin(new Insets(10, 20, 10, 20));
        button.setForeground(new Color(255, 0, 0));
        button.setFocusable(false);
        (this.buttonPlay = new JButton(new ImageIcon(this.getClass().getClassLoader().getResource("images/play.gif")))).setMargin(new Insets(10, 20, 10, 20));
        this.buttonPlay.setFocusable(false);
        final JButton button2 = new JButton(new ImageIcon(this.getClass().getClassLoader().getResource("images/stop.gif")));
        button2.setMargin(new Insets(10, 20, 10, 20));
        button2.setFocusable(false);
        this.buttonRecord.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                MidiWindow.this.fireEvent(new Event(4, this));
            }
        });
        this.buttonLoop.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                MidiWindow.this.fireEvent(new Event(5, this));
            }
        });
        button.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                MidiWindow.this.fireEvent(new Event(3, this));
            }
        });
        this.buttonPlay.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                MidiWindow.this.fireEvent(new Event(1, this));
            }
        });
        button2.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                MidiWindow.this.fireEvent(new Event(2, this));
            }
        });
        (this.chooser = new JFileChooser()).setCurrentDirectory(new File(this.midiSwing.currentDirectory));
        this.chooser.setSelectedFile(new File(this.midiSwing.selectedFile));
        this.midiFilter = new MidiFilter();
        this.lyricsFilter = new LyricsFilter();
        (this.progressBar = new JProgressBar(0, 1)).setValue(0);
        this.progressBar.setStringPainted(true);
        this.progressBar.setPreferredSize(new Dimension(160, 20));
        (this.tempoSlider = new JSlider(0)).setPaintTicks(true);
        this.tempoSlider.setMajorTickSpacing(50);
        this.tempoSlider.setFocusable(false);
        this.tempoSlider.setPreferredSize(new Dimension(160, 25));
        this.tempoSlider.addChangeListener(new ChangeListener() {
            public void stateChanged(final ChangeEvent changeEvent) {
                MidiWindow.this.updateTempoField();
            }
        });
        this.tempoSlider.addMouseListener(new MouseListener() {
            public void mouseClicked(final MouseEvent mouseEvent) {
            }
            
            public void mouseEntered(final MouseEvent mouseEvent) {
            }
            
            public void mouseExited(final MouseEvent mouseEvent) {
            }
            
            public void mousePressed(final MouseEvent mouseEvent) {
            }
            
            public void mouseReleased(final MouseEvent mouseEvent) {
                if (mouseEvent.getClickCount() == 2) {
                    MidiWindow.this.tempoSlider.setValue(50);
                    MidiWindow.this.midiSwing.setTempoFactor(0.0);
                }
            }
        });
        (this.tempoField = new JTextField("120")).setEditable(false);
        this.tempoField.setFocusable(false);
        (this.tempoButton = new JButton(new ImageIcon(this.getClass().getClassLoader().getResource("images/apply.gif")))).setMargin(new Insets(8, 4, 4, 8));
        this.tempoButton.setFocusable(false);
        this.tempoButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                MidiWindow.this.midiSwing.applyTempoFactor((MidiWindow.this.tempoSlider.getValue() - 50.0) / 50.0);
            }
        });
        (this.trackChooser = new JComboBox()).setMaximumRowCount(20);
        this.trackChooser.setFocusable(false);
        this.trackChooser.addPopupMenuListener(new PopupMenuListener() {
            public void popupMenuWillBecomeInvisible(final PopupMenuEvent popupMenuEvent) {
                MidiWindow.this.midiSwing.selectTrack(MidiWindow.this.trackChooser.getSelectedIndex());
            }
            
            public void popupMenuWillBecomeVisible(final PopupMenuEvent popupMenuEvent) {
            }
            
            public void popupMenuCanceled(final PopupMenuEvent popupMenuEvent) {
            }
        });
        (this.outputChooser = new JComboBox()).setMaximumRowCount(30);
        this.outputChooser.setFocusable(false);
        for (int i = 0; i < this.midiSwing.getNumberOfOutputs(); ++i) {
            this.outputChooser.addItem(this.midiSwing.getNameOfOutput(i));
        }
        this.outputChooser.addPopupMenuListener(new PopupMenuListener() {
            public void popupMenuWillBecomeInvisible(final PopupMenuEvent popupMenuEvent) {
                MidiWindow.this.midiSwing.setOutputForTrack(MidiWindow.this.outputChooser.getSelectedIndex(), MidiWindow.this.midiSwing.currentTrack, true);
                MidiWindow.this.midiEventTable.update();
            }
            
            public void popupMenuWillBecomeVisible(final PopupMenuEvent popupMenuEvent) {
            }
            
            public void popupMenuCanceled(final PopupMenuEvent popupMenuEvent) {
            }
        });
        this.outputChooser.setEnabled(true);
        final MidiSwing midiSwing3 = this.midiSwing;
        final JLabel label = new JLabel(MidiSwing.resource.getString("TRACK_LABEL"));
        final MidiSwing midiSwing4 = this.midiSwing;
        final JLabel label2 = new JLabel(MidiSwing.resource.getString("CHANNEL_LABEL"));
        final MidiSwing midiSwing5 = this.midiSwing;
        final JLabel label3 = new JLabel(MidiSwing.resource.getString("OUTPUT_LABEL"));
        final MidiSwing midiSwing6 = this.midiSwing;
        final JLabel label4 = new JLabel(MidiSwing.resource.getString("TEMPO_LABEL"));
        final MidiSwing midiSwing7 = this.midiSwing;
        final JLabel label5 = new JLabel(MidiSwing.resource.getString("POSITION_LABEL"));
        label5.setPreferredSize(new Dimension(80, 25));
        label4.setPreferredSize(new Dimension(80, 25));
        this.topPane = new JPanel();
        final JPanel panel = new JPanel();
        final JPanel panel2 = new JPanel();
        final JPanel panel3 = new JPanel();
        final JPanel panel4 = new JPanel();
        final JPanel panel5 = new JPanel();
        this.topPane.setBorder(BorderFactory.createEmptyBorder(3, 30, 3, 30));
        panel2.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 30));
        panel5.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        panel5.setLayout(new GridBagLayout());
        final GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        this.channelButton = new JToggleButton[16];
        this.channelButton2 = new JToggleButton[16];
        for (int j = 0; j < 16; ++j) {
            (this.channelButton[j] = new JToggleButton()).setPreferredSize(new Dimension(22, 22));
            this.channelButton[j].setIcon(this.buttonIcon[j]);
            this.channelButton[j].setSelectedIcon(this.buttonPressedIcon[j]);
            this.channelButton[j].setPressedIcon(this.buttonPressedIcon[j]);
            this.channelButton[j].setHorizontalAlignment(0);
            this.channelButton[j].setContentAreaFilled(false);
            this.channelButton[j].setIconTextGap(0);
            this.channelButton[j].setBorderPainted(false);
            this.channelButton[j].setMargin(new Insets(0, 0, 0, 0));
            this.channelButton[j].setFont(new Font("Arial", 0, 8));
            this.channelButton[j].setActionCommand("" + j);
            this.channelButton[j].addItemListener(new ItemListener() {
                public void itemStateChanged(final ItemEvent itemEvent) {
                    final int intValue = Integer.valueOf(((JToggleButton)itemEvent.getItem()).getActionCommand());
                    final int stateChange = itemEvent.getStateChange();
                    if (stateChange == 1) {
                        MidiWindow.this.midiSwing.enableChannel(intValue);
                    }
                    if (stateChange == 2) {
                        MidiWindow.this.midiSwing.disableChannel(intValue);
                    }
                }
            });
            this.channelButton[j].setFocusable(false);
            gridBagConstraints.gridx = j;
            gridBagConstraints.gridy = 0;
            panel5.add(this.channelButton[j], gridBagConstraints);
            (this.channelButton2[j] = new JToggleButton()).setPreferredSize(new Dimension(22, 11));
            this.channelButton2[j].setIcon(this.pointerEmptyIcon);
            this.channelButton2[j].setSelectedIcon(this.pointerBlackIcon);
            this.channelButton2[j].setRolloverIcon(this.pointerGreyIcon);
            this.channelButton2[j].setContentAreaFilled(false);
            this.channelButton2[j].setBorderPainted(false);
            this.channelButton2[j].setMargin(new Insets(0, 0, 0, 0));
            this.channelButton2[j].setFocusable(false);
            this.channelButton2[j].setActionCommand("" + j);
            this.channelButton2[j].addActionListener(new ActionListener() {
                public void actionPerformed(final ActionEvent actionEvent) {
                    final int intValue = Integer.valueOf(actionEvent.getActionCommand());
                    if (MidiWindow.this.midiSwing.midiFileType == 0) {
                        MidiWindow.this.midiSwing.selectChannel(intValue);
                    }
                    else {
                        MidiWindow.this.midiSwing.selectTrackWhoseMainChannelIs(intValue);
                    }
                }
            });
            gridBagConstraints.gridx = j;
            gridBagConstraints.gridy = 1;
            panel5.add(this.channelButton2[j], gridBagConstraints);
        }
        panel2.add(this.buttonRecord);
        panel2.add(button);
        panel2.add(this.buttonPlay);
        panel2.add(button2);
        panel2.add(this.buttonLoop);
        panel.setLayout(new GridBagLayout());
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        panel.add(panel2, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panel.add(panel3, gridBagConstraints);
        panel3.setLayout(new GridBagLayout());
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = 17;
        panel3.add(label5, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panel3.add(label4, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        panel3.add(this.progressBar, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        panel3.add(this.tempoSlider, gridBagConstraints);
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        panel3.add(this.tempoField, gridBagConstraints);
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 1;
        panel3.add(this.tempoButton, gridBagConstraints);
        panel4.setLayout(new GridBagLayout());
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = 17;
        panel4.add(label, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panel4.add(label3, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        panel4.add(label2, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        panel4.add(this.trackChooser, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        panel4.add(this.outputChooser, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        panel4.add(panel5, gridBagConstraints);
        this.topPane.setLayout(new GridBagLayout());
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        this.topPane.add(panel, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        this.topPane.add(panel4, gridBagConstraints);
        this.pianoRoll = new PianoRoll(this);
        this.midiEventTable = new MidiEventTable(this.midiSwing);
        final JTabbedPane tabbedPane2;
        final JTabbedPane tabbedPane = tabbedPane2 = new JTabbedPane();
        final MidiSwing midiSwing8 = this.midiSwing;
        final String string = MidiSwing.resource.getString("PIANOROLL_LABEL");
        final Icon icon = null;
        final PianoRoll pianoRoll = this.pianoRoll;
        final MidiSwing midiSwing9 = this.midiSwing;
        tabbedPane2.addTab(string, icon, pianoRoll, MidiSwing.resource.getString("PIANOROLL_DESC"));
        final JTabbedPane tabbedPane3 = tabbedPane;
        final MidiSwing midiSwing10 = this.midiSwing;
        final String string2 = MidiSwing.resource.getString("MIDIEVENTS_LABEL");
        final Icon icon2 = null;
        final MidiEventTable midiEventTable = this.midiEventTable;
        final MidiSwing midiSwing11 = this.midiSwing;
        tabbedPane3.addTab(string2, icon2, midiEventTable, MidiSwing.resource.getString("MIDIEVENTS_DESC"));
        tabbedPane.setFocusable(false);
        final JPanel panel6 = new JPanel();
        panel6.setLayout(new GridBagLayout());
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = 17;
        panel6.add(this.topPane, gridBagConstraints);
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = 17;
        gridBagConstraints.fill = 1;
        panel6.add(tabbedPane, gridBagConstraints);
        this.getContentPane().add(panel6, "Center");
        this.setDefaultCloseOperation(0);
        this.setSize(new Dimension(this.midiSwing.windowWidth, this.midiSwing.windowHeight));
        final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(screenSize.width / 2 - this.midiSwing.windowWidth / 2 - 0, screenSize.height / 2 - this.midiSwing.windowHeight / 2 - 0);
        this.setJMenuBar(this.menuBar = new JMenuBar());
        final MidiSwing midiSwing12 = this.midiSwing;
        final JMenu menu = new JMenu(MidiSwing.resource.getString("FILE"));
        menu.setMnemonic(70);
        this.menuBar.add(menu);
        final MidiSwing midiSwing13 = this.midiSwing;
        final JMenuItem menuItem = new JMenuItem(MidiSwing.resource.getString("NEW_SMF0"));
        menuItem.setActionCommand("NEW_SMF0");
        menuItem.addActionListener(this);
        menu.add(menuItem);
        final MidiSwing midiSwing14 = this.midiSwing;
        final JMenuItem menuItem2 = new JMenuItem(MidiSwing.resource.getString("NEW_SMF1"));
        menuItem2.setActionCommand("NEW_SMF1");
        menuItem2.setAccelerator(KeyStroke.getKeyStroke(78, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem2.addActionListener(this);
        menu.add(menuItem2);
        final MidiSwing midiSwing15 = this.midiSwing;
        final JMenuItem menuItem3 = new JMenuItem(MidiSwing.resource.getString("OPEN"));
        menuItem3.setActionCommand("OPEN");
        menuItem3.setAccelerator(KeyStroke.getKeyStroke(79, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem3.addActionListener(this);
        menu.add(menuItem3);
        final MidiSwing midiSwing16 = this.midiSwing;
        final JMenuItem menuItem4 = new JMenuItem(MidiSwing.resource.getString("OPEN_IN_NEW_WINDOW"));
        menuItem4.setActionCommand("OPEN_IN_NEW_WINDOW");
        menuItem4.addActionListener(this);
        menu.add(menuItem4);
        final MidiSwing midiSwing17 = this.midiSwing;
        final JMenuItem menuItem5 = new JMenuItem(MidiSwing.resource.getString("CLOSE"));
        menuItem5.setActionCommand("CLOSE");
        menuItem5.setAccelerator(KeyStroke.getKeyStroke(87, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem5.addActionListener(this);
        menu.add(menuItem5);
        menu.addSeparator();
        final MidiSwing midiSwing18 = this.midiSwing;
        final JMenuItem menuItem6 = new JMenuItem(MidiSwing.resource.getString("SAVE"));
        menuItem6.setActionCommand("SAVE");
        menuItem6.setAccelerator(KeyStroke.getKeyStroke(83, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem6.addActionListener(this);
        menu.add(menuItem6);
        final MidiSwing midiSwing19 = this.midiSwing;
        final JMenuItem menuItem7 = new JMenuItem(MidiSwing.resource.getString("SAVE_AS"));
        menuItem7.setActionCommand("SAVE_AS");
        menuItem7.addActionListener(this);
        menu.add(menuItem7);
        menu.addSeparator();
        final MidiSwing midiSwing20 = this.midiSwing;
        (this.convertToSMF0menuItem = new JMenuItem(MidiSwing.resource.getString("CONVERT_TO_SMF0"))).setActionCommand("CONVERT_TO_SMF0");
        this.convertToSMF0menuItem.addActionListener(this);
        menu.add(this.convertToSMF0menuItem);
        final MidiSwing midiSwing21 = this.midiSwing;
        (this.convertToSMF1menuItem = new JMenuItem(MidiSwing.resource.getString("CONVERT_TO_SMF1"))).setActionCommand("CONVERT_TO_SMF1");
        this.convertToSMF1menuItem.addActionListener(this);
        menu.add(this.convertToSMF1menuItem);
        final MidiSwing midiSwing22 = this.midiSwing;
        final JMenu menu2 = new JMenu(MidiSwing.resource.getString("EDIT"));
        menu2.setMnemonic(69);
        this.menuBar.add(menu2);
        final MidiSwing midiSwing23 = this.midiSwing;
        final JMenuItem menuItem8 = new JMenuItem(MidiSwing.resource.getString("UNDO"));
        menuItem8.setActionCommand("UNDO");
        menuItem8.setAccelerator(KeyStroke.getKeyStroke(90, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem8.addActionListener(this);
        menu2.add(menuItem8);
        menu2.addSeparator();
        final MidiSwing midiSwing24 = this.midiSwing;
        final JMenuItem menuItem9 = new JMenuItem(MidiSwing.resource.getString("CUT"));
        menuItem9.setActionCommand("CUT");
        menuItem9.setAccelerator(KeyStroke.getKeyStroke(88, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem9.addActionListener(this);
        menu2.add(menuItem9);
        final MidiSwing midiSwing25 = this.midiSwing;
        final JMenuItem menuItem10 = new JMenuItem(MidiSwing.resource.getString("COPY"));
        menuItem10.setActionCommand("COPY");
        menuItem10.setAccelerator(KeyStroke.getKeyStroke(67, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem10.addActionListener(this);
        menu2.add(menuItem10);
        final MidiSwing midiSwing26 = this.midiSwing;
        final JMenuItem menuItem11 = new JMenuItem(MidiSwing.resource.getString("PASTE"));
        menuItem11.setActionCommand("PASTE");
        menuItem11.setAccelerator(KeyStroke.getKeyStroke(86, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem11.addActionListener(this);
        menu2.add(menuItem11);
        final MidiSwing midiSwing27 = this.midiSwing;
        final JMenuItem menuItem12 = new JMenuItem(MidiSwing.resource.getString("DELETE"));
        menuItem12.setActionCommand("DELETE");
        menuItem12.setAccelerator(KeyStroke.getKeyStroke(8, 0));
        menuItem12.addActionListener(this);
        menu2.add(menuItem12);
        final MidiSwing midiSwing28 = this.midiSwing;
        final JMenuItem menuItem13 = new JMenuItem(MidiSwing.resource.getString("SELECT_ALL"));
        menuItem13.setActionCommand("SELECT_ALL");
        menuItem13.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem13.addActionListener(this);
        menu2.add(menuItem13);
        final MidiSwing midiSwing29 = this.midiSwing;
        final JMenuItem menuItem14 = new JMenuItem(MidiSwing.resource.getString("DESELECT_ALL"));
        menuItem14.setActionCommand("DESELECT_ALL");
        menuItem14.setAccelerator(KeyStroke.getKeyStroke(65, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem14.addActionListener(this);
        menu2.add(menuItem14);
        menu2.addSeparator();
        final MidiSwing midiSwing30 = this.midiSwing;
        final JMenuItem menuItem15 = new JMenuItem(MidiSwing.resource.getString("QUANTIZE"));
        menuItem15.setActionCommand("QUANTIZE");
        menuItem15.setAccelerator(KeyStroke.getKeyStroke(75, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menuItem15.addActionListener(this);
        menu2.add(menuItem15);
        final MidiSwing midiSwing31 = this.midiSwing;
        final JMenu menu3 = new JMenu(MidiSwing.resource.getString("OPTIONS"));
        this.menuBar.add(menu3);
        final MidiSwing midiSwing32 = this.midiSwing;
        (this.pianoRollMenuItem = new JCheckBoxMenuItem(MidiSwing.resource.getString("ANIMATE_PIANOROLL"))).setActionCommand("ANIMATE_PIANOROLL");
        this.pianoRollMenuItem.addActionListener(this);
        this.pianoRollMenuItem.setSelected(true);
        menu3.add(this.pianoRollMenuItem);
        final MidiSwing midiSwing33 = this.midiSwing;
        (this.keyboardMenuItem = new JCheckBoxMenuItem(MidiSwing.resource.getString("ANIMATE_KEYBOARD"))).setActionCommand("ANIMATE_KEYBOARD");
        this.keyboardMenuItem.addActionListener(this);
        this.keyboardMenuItem.setSelected(true);
        menu3.add(this.keyboardMenuItem);
        final MidiSwing midiSwing34 = this.midiSwing;
        final JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem(MidiSwing.resource.getString("BEAT_TEMPO_WHILE_RECORDING"));
        checkBoxMenuItem.setActionCommand("BEAT_TEMPO_WHILE_RECORDING");
        checkBoxMenuItem.addActionListener(this);
        checkBoxMenuItem.setSelected(false);
        menu3.add(checkBoxMenuItem);
        final MidiSwing midiSwing35 = this.midiSwing;
        final JCheckBoxMenuItem checkBoxMenuItem2 = new JCheckBoxMenuItem(MidiSwing.resource.getString("MAGNETISE_GRID"));
        checkBoxMenuItem2.setActionCommand("MAGNETISE_GRID");
        checkBoxMenuItem2.addActionListener(this);
        checkBoxMenuItem2.setSelected(false);
        menu3.add(checkBoxMenuItem2);
        menu3.addSeparator();
        final MidiSwing midiSwing36 = this.midiSwing;
        (this.attachDataToNotesMenuItem = new JCheckBoxMenuItem(MidiSwing.resource.getString("ATTACH_DATA_TO_NOTES"))).setActionCommand("ATTACH_DATA_TO_NOTES");
        this.attachDataToNotesMenuItem.setSelected(true);
        this.attachDataToNotesMenuItem.addActionListener(this);
        menu3.add(this.attachDataToNotesMenuItem);
        menu3.addSeparator();
        final MidiSwing midiSwing37 = this.midiSwing;
        final JMenuItem menuItem16 = new JMenuItem(MidiSwing.resource.getString("CHECKFORUPDATES"));
        menuItem16.setActionCommand("CHECKFORUPDATES");
        menuItem16.addActionListener(this);
        menu3.add(menuItem16);
        final MidiSwing midiSwing38 = this.midiSwing;
        final JMenuItem menuItem17 = new JMenuItem(MidiSwing.resource.getString("REPORT_BUG"));
        menuItem17.setActionCommand("REPORT_BUG");
        menuItem17.addActionListener(this);
        menu3.add(menuItem17);
        final MidiSwing midiSwing39 = this.midiSwing;
        final JMenuItem menuItem18 = new JMenuItem(MidiSwing.resource.getString("ABOUT_MIDISWING"));
        menuItem18.setActionCommand("ABOUT_MIDISWING");
        menuItem18.addActionListener(this);
        menu3.add(menuItem18);
        final MidiSwing midiSwing40 = this.midiSwing;
        final JMenu menu4 = new JMenu(MidiSwing.resource.getString("TRACK"));
        this.menuBar.add(menu4);
        final MidiSwing midiSwing41 = this.midiSwing;
        (this.addTrackMenuItem = new JMenuItem(MidiSwing.resource.getString("ADD_TRACK"))).setActionCommand("ADD_TRACK");
        this.addTrackMenuItem.addActionListener(this);
        menu4.add(this.addTrackMenuItem);
        final MidiSwing midiSwing42 = this.midiSwing;
        (this.deleteTrackMenuItem = new JMenuItem(MidiSwing.resource.getString("DELETE_CURRENT_TRACK"))).setActionCommand("DELETE_CURRENT_TRACK");
        this.deleteTrackMenuItem.addActionListener(this);
        menu4.add(this.deleteTrackMenuItem);
        final MidiSwing midiSwing43 = this.midiSwing;
        final JMenuItem menuItem19 = new JMenuItem(MidiSwing.resource.getString("RENAME_CURRENT_TRACK"));
        menuItem19.setActionCommand("RENAME_CURRENT_TRACK");
        menuItem19.addActionListener(this);
        menu4.add(menuItem19);
        final MidiSwing midiSwing44 = this.midiSwing;
        final JMenuItem menuItem20 = new JMenuItem(MidiSwing.resource.getString("IMPORT_LYRICS"));
        menuItem20.setActionCommand("IMPORT_LYRICS");
        menuItem20.addActionListener(this);
        menu4.add(menuItem20);
        menu4.addSeparator();
        final MidiSwing midiSwing45 = this.midiSwing;
        (this.singleTrackDisplayMenuItem = new JRadioButtonMenuItem(MidiSwing.resource.getString("GREY_OUT_OTHER_TRACKS"))).setActionCommand("GREY_OUT_OTHER_TRACKS");
        this.singleTrackDisplayMenuItem.setSelected(false);
        this.singleTrackDisplayMenuItem.addActionListener(this);
        menu4.add(this.singleTrackDisplayMenuItem);
        final MidiSwing midiSwing46 = this.midiSwing;
        final JMenu menu5 = new JMenu(MidiSwing.resource.getString("INPUT"));
        this.menuBar.add(menu5);
        final int numberOfInputs = this.midiSwing.getNumberOfInputs();
        this.inputMenuItem = new JRadioButtonMenuItem[numberOfInputs];
        for (int k = 0; k < numberOfInputs; ++k) {
            (this.inputMenuItem[k] = new JRadioButtonMenuItem(this.midiSwing.getNameOfInput(k))).setActionCommand("Input" + k);
            this.inputMenuItem[k].addActionListener(this);
            if (k == 0) {
                this.inputMenuItem[k].setSelected(true);
            }
            else {
                this.inputMenuItem[k].setSelected(false);
            }
            menu5.add(this.inputMenuItem[k]);
        }
        if (numberOfInputs == 0) {
            final JMenu menu6 = menu5;
            final MidiSwing midiSwing47 = this.midiSwing;
            menu6.add(new JMenuItem(MidiSwing.resource.getString("NOINPUTFOUND")));
        }
        final MidiSwing midiSwing48 = this.midiSwing;
        final JMenu menu7 = new JMenu(MidiSwing.resource.getString("OUTPUT"));
        this.menuBar.add(menu7);
        final int numberOfOutputs = this.midiSwing.getNumberOfOutputs();
        this.outputMenuItem = new JRadioButtonMenuItem[numberOfOutputs];
        for (int l = 0; l < numberOfOutputs; ++l) {
            (this.outputMenuItem[l] = new JRadioButtonMenuItem(this.midiSwing.getNameOfOutput(l))).setActionCommand("Output" + l);
            this.outputMenuItem[l].addActionListener(this);
            menu7.add(this.outputMenuItem[l]);
        }
        this.inputOptions = new InputOptions(this);
        this.outputOptions = new OutputOptions(this);
        final MidiSwing midiSwing49 = this.midiSwing;
        if (MidiSwing.debug) {
            System.out.println("Done.");
        }
    }
    
    public int getResolution() {
        return this.midiSwing.getResolution();
    }
    
    public void play() {
        this.buttonPlay.setSelected(true);
    }
    
    public void stop() {
        this.buttonPlay.setSelected(false);
    }
    
    public void record(final boolean selected) {
        this.buttonRecord.setSelected(selected);
    }
    
    public void loop(final boolean selected) {
        this.buttonLoop.setSelected(selected);
    }
    
    public void updateProgressBar(final long n) {
        this.progressBar.setMaximum((int)n);
    }
    
    public void about() {
        final URL resource = this.getClass().getClassLoader().getResource("help/info.html");
        try {
            new displayURL(resource, 450, 262, this);
        }
        catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error");
        }
    }
    
    public void sendMessage(String encode, String encode2) {
        if (encode2.compareTo("") != 0) {
            encode2 = URLEncoder.encode(encode2);
            encode = URLEncoder.encode(encode);
            try {
                BrowserControl.displayURL(new URL("http://www.les-stooges.org/pascal/message2.php?message=" + encode2 + "&expediteur=" + encode + "&sujet=MidiSwing"));
            }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error");
            }
        }
    }
    
    public void reportBug() {
        final MidiSwing midiSwing = this.midiSwing;
        this.sendFrame = new JFrame(MidiSwing.resource.getString("REPORT_BUG"));
        (this.textArea = new JTextArea()).setRows(8);
        this.textArea.setColumns(25);
        this.textArea.setLineWrap(true);
        this.textArea.setWrapStyleWord(true);
        final JScrollPane scrollPane = new JScrollPane(this.textArea);
        scrollPane.setVerticalScrollBarPolicy(22);
        scrollPane.setPreferredSize(new Dimension(300, 100));
        (this.textField = new JTextField()).setColumns(25);
        final MidiSwing midiSwing2 = this.midiSwing;
        final JButton button = new JButton(MidiSwing.resource.getString("SEND"));
        button.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                try {
                    MidiWindow.this.sendMessage(MidiWindow.this.textField.getText(), MidiWindow.this.textArea.getText());
                }
                catch (Exception ex) {}
                MidiWindow.this.sendFrame.dispose();
            }
        });
        final MidiSwing midiSwing3 = this.midiSwing;
        final JLabel label = new JLabel(MidiSwing.resource.getString("MESSAGE_LABEL"));
        final MidiSwing midiSwing4 = this.midiSwing;
        final JLabel label2 = new JLabel(MidiSwing.resource.getString("E-MAIL_LABEL"));
        final MidiSwing midiSwing5 = this.midiSwing;
        final JLabel label3 = new JLabel(MidiSwing.resource.getString("EXPLANATION_LABEL"));
        final JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setLayout(new GridBagLayout());
        final GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = 17;
        panel.add(label, gridBagConstraints);
        gridBagConstraints.fill = 1;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        panel.add(scrollPane, gridBagConstraints);
        gridBagConstraints.fill = 0;
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        panel.add(label2, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        panel.add(this.textField, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        panel.add(label3, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        panel.add(button, gridBagConstraints);
        this.sendFrame.getContentPane().add(panel, "Center");
        this.sendFrame.setDefaultCloseOperation(2);
        this.sendFrame.setFocusable(false);
        final int n = 450;
        final int n2 = 320;
        this.sendFrame.setSize(new Dimension(n, n2));
        final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.sendFrame.setLocation((screenSize.width - n) / 2, screenSize.height / 3 - n2 / 2);
        this.sendFrame.show();
        this.requestFocus();
    }
    
    public void newFile(final int midiFileType) {
        if (this.midiSwing.emptyDocument) {
            this.midiSwing.midiFileType = midiFileType;
            this.midiSwing.loadFile((File)null);
        }
        else {
            final Object[] array = { new Integer(this.midiSwing.index + 1), null, new Integer(midiFileType) };
            try {
                this.midiSwing.getClass().getConstructors()[0].newInstance(array);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public void openFile() {
        if (this.midiSwing.modified) {
            final MidiSwing midiSwing = this.midiSwing;
            final String string = MidiSwing.resource.getString("MSG_SAVE_BEFORE_CLOSING");
            final MidiSwing midiSwing2 = this.midiSwing;
            switch (JOptionPane.showConfirmDialog(this, string, MidiSwing.resource.getString("MSG_FILE_NOT_SAVED"), 1, 2)) {
                case 0: {
                    this.saveFile();
                    this.openFile();
                    break;
                }
                case 1: {
                    this.midiSwing.modified = false;
                    this.openFile();
                }
            }
        }
        else {
            this.chooser.setFileFilter(this.midiFilter);
            final int showOpenDialog = this.chooser.showOpenDialog(this);
            this.requestFocus();
            if (showOpenDialog == 0) {
                this.pianoRoll.emptySelection();
                this.midiSwing.loadFile(this.chooser.getSelectedFile());
            }
        }
        this.requestFocus();
    }
    
    public void openFileInNewWindow() {
        this.chooser.setFileFilter(this.midiFilter);
        final int showOpenDialog = this.chooser.showOpenDialog(this);
        this.requestFocus();
        if (showOpenDialog == 0) {
            final Object[] array = { new Integer(this.midiSwing.index + 1), this.chooser.getSelectedFile(), new Integer(0) };
            try {
                this.midiSwing.getClass().getConstructors()[0].newInstance(array);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public void closeFile(final boolean b) {
        if (this.midiSwing.modified) {
            final MidiSwing midiSwing = this.midiSwing;
            final String string = MidiSwing.resource.getString("MSG_SAVE_BEFORE_CLOSING");
            final MidiSwing midiSwing2 = this.midiSwing;
            final int showConfirmDialog = JOptionPane.showConfirmDialog(this, string, MidiSwing.resource.getString("MSG_FILE_NOT_SAVED"), 1, 2);
            this.requestFocus();
            switch (showConfirmDialog) {
                case 0: {
                    this.saveFile();
                    this.closeFile(b);
                    break;
                }
                case 1: {
                    this.midiSwing.modified = false;
                    this.closeFile(b);
                }
            }
        }
        else {
            this.midiSwing.close(b);
        }
    }
    
    public void saveFile() {
        if (this.midiSwing.file != null) {
            if (this.midiSwing.file.exists()) {
                this.midiSwing.writeFile();
            }
            else {
                this.saveFileAs();
            }
        }
        else {
            this.saveFileAs();
        }
    }
    
    public void saveFileAs() {
        this.chooser.setFileFilter(this.midiFilter);
        if (this.chooser.showSaveDialog(this) == 0) {
            if (this.chooser.getSelectedFile().exists()) {
                final StringBuilder sb = new StringBuilder();
                final MidiSwing midiSwing = this.midiSwing;
                final String string = sb.append(MidiSwing.resource.getString("MSG_OVERWRITE")).append(this.chooser.getSelectedFile().getName()).append("?").toString();
                final MidiSwing midiSwing2 = this.midiSwing;
                switch (JOptionPane.showConfirmDialog(this, string, MidiSwing.resource.getString("MSG_FILE_ALREADY_EXISTS"), 1, 2)) {
                    case 0: {
                        this.midiSwing.writeFile(this.chooser.getSelectedFile());
                        break;
                    }
                    case 1: {
                        this.saveFileAs();
                    }
                }
            }
            else {
                this.midiSwing.writeFile(this.chooser.getSelectedFile());
            }
        }
        this.requestFocus();
    }
    
    public void convertToSMF0() {
        final MidiSwing midiSwing = this.midiSwing;
        final String string = MidiSwing.resource.getString("MSG_ARE_YOU_SURE_SMF0");
        final MidiSwing midiSwing2 = this.midiSwing;
        switch (JOptionPane.showConfirmDialog(this, string, MidiSwing.resource.getString("CONVERT_TO_SMF0"), 1, 2)) {
            case 0: {
                this.midiSwing.convertToSMF0();
            }
            case 1: {}
        }
        this.requestFocus();
    }
    
    public void convertToSMF1() {
        this.midiSwing.convertToSMF1();
    }
    
    public void setMidiFileType(final int n) {
        if (n == 0) {
            this.convertToSMF0menuItem.setEnabled(false);
            this.convertToSMF1menuItem.setEnabled(true);
            this.addTrackMenuItem.setEnabled(false);
            this.deleteTrackMenuItem.setEnabled(false);
        }
        if (n == 1) {
            this.convertToSMF0menuItem.setEnabled(true);
            this.convertToSMF1menuItem.setEnabled(false);
            this.addTrackMenuItem.setEnabled(true);
            this.deleteTrackMenuItem.setEnabled(true);
        }
    }
    
    public void undo() {
        this.pianoRoll.restoreNotes();
    }
    
    public void cut() {
        this.pianoRoll.cutSelection();
    }
    
    public void copy() {
        this.pianoRoll.copySelection();
    }
    
    public void delete() {
        this.pianoRoll.deleteSelection();
    }
    
    public void paste() {
        this.pianoRoll.pasteClipboard(this.pianoRoll.playPosition);
    }
    
    public void selectAll() {
        this.pianoRoll.selectAll();
    }
    
    public void deselectAll() {
        this.pianoRoll.emptySelection();
        this.pianoRoll.repaint();
    }
    
    public void quantize() {
        this.pianoRoll.quantizeSelection();
    }
    
    public void importLyrics() {
        this.chooser.setFileFilter(this.lyricsFilter);
        final int showOpenDialog = this.chooser.showOpenDialog(this);
        this.requestFocus();
        if (showOpenDialog == 0) {
            this.midiSwing.importLyrics(this.chooser.getSelectedFile());
        }
    }
    
    public void selectOutput(final int outputForAllTracks) {
        final MidiSwing midiSwing = this.midiSwing;
        if (MidiSwing.debug) {
            System.out.println("Change of output device");
        }
        for (int i = 0; i < this.outputMenuItem.length; ++i) {
            this.outputMenuItem[i].setSelected(false);
        }
        if (outputForAllTracks >= 0 && outputForAllTracks < this.outputMenuItem.length) {
            final MidiSwing midiSwing2 = this.midiSwing;
            if (MidiSwing.debug) {
                System.out.println("deviceNumber =" + outputForAllTracks);
            }
            this.midiSwing.setOutputForAllTracks(outputForAllTracks);
        }
        this.midiSwing.setPlayPosition(this.pianoRoll.playPosition, false);
    }
    
    public void selectInput(final int n) {
        final MidiSwing midiSwing = this.midiSwing;
        if (MidiSwing.debug) {
            System.out.println("Change of input device");
        }
        this.midiSwing.stop();
        for (int i = 0; i < this.inputMenuItem.length; ++i) {
            this.inputMenuItem[i].setSelected(false);
        }
        if (n >= 0 && n < this.inputMenuItem.length) {
            final MidiSwing midiSwing2 = this.midiSwing;
            if (MidiSwing.debug) {
                System.out.println("deviceNumber =" + n);
            }
            this.inputMenuItem[n].setSelected(true);
            this.midiSwing.selectInput(n);
        }
        this.midiSwing.setPlayPosition(this.pianoRoll.playPosition, false);
    }
    
    public void keyPressed(final KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 157 || keyEvent.getKeyCode() == 17) {
            this.shortcutKey = true;
            this.repaint();
        }
        if (keyEvent.getKeyCode() == 18) {
            this.altKey = true;
            this.repaint();
        }
        if (keyEvent.getKeyCode() == 32) {
            this.midiSwing.playstop();
        }
        if (keyEvent.getKeyCode() == 72) {
            this.pianoRoll.singleTrackDisplay();
        }
        if (keyEvent.getKeyCode() == 84) {
            this.pianoRoll.switchMode();
        }
        if (keyEvent.getModifiers() == Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()) {
            if (keyEvent.getKeyCode() == 37) {
                if (this.midiSwing.midiFileType == 0) {
                    this.midiSwing.selectChannel(Math.max(0, this.midiSwing.currentChannel - 1));
                }
                else {
                    this.midiSwing.selectTrack(Math.max(1, this.midiSwing.currentTrack - 1));
                }
            }
            if (keyEvent.getKeyCode() == 39) {
                if (this.midiSwing.midiFileType == 0) {
                    this.midiSwing.selectChannel(Math.min(15, this.midiSwing.currentChannel + 1));
                }
                else {
                    this.midiSwing.selectTrack(Math.min(this.midiSwing.numberOfTracks - 1, this.midiSwing.currentTrack + 1));
                }
            }
            if (keyEvent.getKeyCode() == 38) {
                this.pianoRoll.previousController();
            }
            if (keyEvent.getKeyCode() == 40) {
                this.pianoRoll.nextController();
            }
        }
        else {
            if (keyEvent.getKeyCode() == 37 && this.pianoRoll.anyNoteSelected()) {
                this.pianoRoll.alterSelection(-480L, 0, 1.0, 1.0);
            }
            if (keyEvent.getKeyCode() == 39 && this.pianoRoll.anyNoteSelected()) {
                this.pianoRoll.alterSelection(480L, 0, 1.0, 1.0);
            }
            if (keyEvent.getKeyCode() == 38 && this.pianoRoll.anyNoteSelected()) {
                this.pianoRoll.alterSelection(0L, 1, 1.0, 1.0);
            }
            if (keyEvent.getKeyCode() == 40 && this.pianoRoll.anyNoteSelected()) {
                this.pianoRoll.alterSelection(0L, -1, 1.0, 1.0);
            }
        }
        this.pianoRoll.keyPressed(keyEvent);
    }
    
    public void keyReleased(final KeyEvent keyEvent) {
        if (keyEvent.getKeyCode() == 157) {
            this.shortcutKey = false;
            this.repaint();
        }
        if (keyEvent.getKeyCode() == 18) {
            this.altKey = false;
            this.repaint();
        }
        this.pianoRoll.keyReleased(keyEvent);
        this.repaint();
    }
    
    public void keyTyped(final KeyEvent keyEvent) {
    }
    
    public void windowActivated(final WindowEvent windowEvent) {
    }
    
    public void windowClosed(final WindowEvent windowEvent) {
    }
    
    public void windowClosing(final WindowEvent windowEvent) {
        this.closeFile(true);
    }
    
    public void windowDeactivated(final WindowEvent windowEvent) {
    }
    
    public void windowDeiconified(final WindowEvent windowEvent) {
    }
    
    public void windowIconified(final WindowEvent windowEvent) {
    }
    
    public void windowOpened(final WindowEvent windowEvent) {
    }
    
    public void actionPerformed(final ActionEvent actionEvent) {
        if (actionEvent.getActionCommand() == "NEW_SMF0") {
            this.newFile(0);
        }
        if (actionEvent.getActionCommand() == "NEW_SMF1") {
            this.newFile(1);
        }
        if (actionEvent.getActionCommand() == "OPEN") {
            this.openFile();
        }
        if (actionEvent.getActionCommand() == "OPEN_IN_NEW_WINDOW") {
            this.openFileInNewWindow();
        }
        if (actionEvent.getActionCommand() == "CLOSE") {
            this.closeFile(false);
        }
        if (actionEvent.getActionCommand() == "SAVE") {
            this.saveFile();
        }
        if (actionEvent.getActionCommand() == "SAVE_AS") {
            this.saveFileAs();
        }
        if (actionEvent.getActionCommand() == "CONVERT_TO_SMF0") {
            this.convertToSMF0();
        }
        if (actionEvent.getActionCommand() == "CONVERT_TO_SMF1") {
            this.convertToSMF1();
        }
        if (actionEvent.getActionCommand() == "UNDO") {
            this.undo();
        }
        if (actionEvent.getActionCommand() == "CUT") {
            this.cut();
        }
        if (actionEvent.getActionCommand() == "COPY") {
            this.copy();
        }
        if (actionEvent.getActionCommand() == "PASTE") {
            this.paste();
        }
        if (actionEvent.getActionCommand() == "DELETE") {
            this.delete();
        }
        if (actionEvent.getActionCommand() == "SELECT_ALL") {
            this.selectAll();
        }
        if (actionEvent.getActionCommand() == "DESELECT_ALL") {
            this.deselectAll();
        }
        if (actionEvent.getActionCommand() == "QUANTIZE") {
            this.quantize();
        }
        if (actionEvent.getActionCommand() == "ADD_TRACK") {
            this.midiSwing.createTrackAndSelectIt(-2);
        }
        if (actionEvent.getActionCommand() == "DELETE_CURRENT_TRACK") {
            this.midiSwing.deleteTrack(this.midiSwing.currentTrack);
        }
        if (actionEvent.getActionCommand() == "RENAME_CURRENT_TRACK") {
            this.midiSwing.renameTrack(this.midiSwing.currentTrack);
        }
        if (actionEvent.getActionCommand() == "GREY_OUT_OTHER_TRACKS") {
            this.pianoRoll.singleTrackDisplay();
        }
        if (actionEvent.getActionCommand() == "IMPORT_LYRICS") {
            this.importLyrics();
        }
        if (actionEvent.getActionCommand() == "ANIMATE_PIANOROLL") {
            this.pianoRoll.animatePianoRoll();
        }
        if (actionEvent.getActionCommand() == "ANIMATE_KEYBOARD") {
            this.pianoRoll.animateKeyboard();
        }
        if (actionEvent.getActionCommand() == "BEAT_TEMPO_WHILE_RECORDING") {
            this.midiSwing.beatWhileRecording();
        }
        if (actionEvent.getActionCommand() == "MAGNETISE_GRID") {
            this.midiSwing.magnetiseGrid();
        }
        if (actionEvent.getActionCommand() == "ATTACH_DATA_TO_NOTES") {
            this.pianoRoll.attachDataToNotes();
        }
        if (actionEvent.getActionCommand() == "CHECKFORUPDATES") {
            this.midiSwing.checkForUpdates(true);
        }
        if (actionEvent.getActionCommand() == "ABOUT_MIDISWING") {
            this.about();
        }
        if (actionEvent.getActionCommand() == "REPORT_BUG") {
            this.reportBug();
        }
        if (actionEvent.getActionCommand() == "INPUT_OPTIONS") {
            this.inputOptions.setVisible(true);
        }
        if (actionEvent.getActionCommand() == "OUTPUT_OPTIONS") {
            this.outputOptions.setVisible(true);
        }
        if (actionEvent.getActionCommand().startsWith("Output")) {
            this.selectOutput(Integer.valueOf(actionEvent.getActionCommand().substring(6)));
        }
        if (actionEvent.getActionCommand().startsWith("Input")) {
            this.selectInput(Integer.valueOf(actionEvent.getActionCommand().substring(5)));
        }
    }
    
    static {
        channelColor = new Color[] { new Color(0, 0, 255), new Color(200, 0, 255), new Color(255, 150, 150), new Color(255, 0, 0), new Color(255, 150, 0), new Color(200, 200, 0), new Color(60, 170, 113), new Color(0, 200, 0), new Color(0, 255, 255), new Color(43, 149, 248), new Color(100, 100, 255), new Color(255, 0, 255), new Color(100, 0, 255), new Color(160, 130, 107), new Color(114, 147, 162), new Color(120, 162, 95) };
    }
    
    public class displayURL extends JFrame
    {
        JEditorPane html;
        
        public displayURL(final URL url, final int n, final int n2, final MidiWindow midiWindow) {
            super("MidiSwing");
            try {
                (this.html = new JEditorPane(url)).setEditable(false);
                this.html.addHyperlinkListener(new HyperlinkListener() {
                    public void hyperlinkUpdate(final HyperlinkEvent hyperlinkEvent) {
                        if (hyperlinkEvent.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
                            if (hyperlinkEvent instanceof HTMLFrameHyperlinkEvent) {
                                ((HTMLDocument)displayURL.this.html.getDocument()).processHTMLFrameHyperlinkEvent((HTMLFrameHyperlinkEvent)hyperlinkEvent);
                            }
                            else {
                                BrowserControl.displayURL(hyperlinkEvent.getURL());
                            }
                        }
                    }
                });
                final JScrollPane scrollPane = new JScrollPane();
                scrollPane.getViewport().add(this.html);
                this.getContentPane().add(scrollPane, "Center");
                this.setDefaultCloseOperation(2);
                this.setFocusable(false);
                this.setSize(new Dimension(n, n2));
                final Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                this.setLocation(screenSize.width / 2 - n / 2, screenSize.height / 2 - n2 / 2);
                this.show();
            }
            catch (Exception ex) {
                final MidiSwing midiSwing = midiWindow.midiSwing;
                JOptionPane.showMessageDialog(midiWindow, MidiSwing.resource.getString("CONNECTION_ERROR"));
            }
        }
    }
}
