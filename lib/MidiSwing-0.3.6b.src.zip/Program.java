import javax.sound.midi.MidiEvent;

// 
// Decompiled by Procyon v0.5.30
// 

public class Program
{
    public int programNumber;
    public int bankNumber;
    private PianoRoll p;
    public int channelNumber;
    public int trackNumber;
    private long start;
    public MidiEvent programEvent;
    public MidiEvent bankEvent;
    private boolean selected;
    
    public Program(final int programNumber, final int bankNumber, final int channelNumber, final long start, final int trackNumber, final MidiEvent programEvent, final MidiEvent bankEvent, final boolean selected, final PianoRoll p9) {
        this.programNumber = programNumber;
        this.bankNumber = bankNumber;
        this.start = start;
        this.trackNumber = trackNumber;
        this.channelNumber = channelNumber;
        this.programEvent = programEvent;
        this.bankEvent = bankEvent;
        this.selected = selected;
        this.p = p9;
    }
    
    public long getTimestamp() {
        return this.start;
    }
    
    public void setTimestamp(final long start) {
        this.start = start;
    }
    
    public void set(final int programNumber, final int bankNumber) {
        this.programNumber = programNumber;
        this.bankNumber = bankNumber;
    }
    
    public int getChannel() {
        return this.channelNumber;
    }
    
    public int getProgram() {
        return this.programNumber;
    }
    
    public int getBank() {
        return this.bankNumber;
    }
}
