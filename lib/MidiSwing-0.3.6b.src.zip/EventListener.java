// 
// Decompiled by Procyon v0.5.30
// 

public interface EventListener
{
    void eventReceived(final Event p0);
}
