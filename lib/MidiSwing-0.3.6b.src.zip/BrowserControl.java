import java.io.IOException;
import java.net.URL;

// 
// Decompiled by Procyon v0.5.30
// 

public class BrowserControl
{
    private static final String WIN_ID = "Windows";
    private static final String WIN_PATH = "rundll32";
    private static final String WIN_FLAG = "url.dll,FileProtocolHandler";
    private static final String MAC_ID = "Mac";
    private static final String MAC_PATH = "open";
    private static final String UNIX_PATH = "netscape";
    private static final String UNIX_FLAG = "-remote openURL";
    
    public static void displayURL(final URL url) {
        final boolean windowsPlatform = isWindowsPlatform();
        final boolean macPlatform = isMacPlatform();
        String s = null;
        try {
            if (windowsPlatform) {
                s = "rundll32 url.dll,FileProtocolHandler " + url;
                Runtime.getRuntime().exec(s);
            }
            else if (macPlatform) {
                s = "open " + url;
                Runtime.getRuntime().exec(s);
            }
            else {
                s = "netscape -remote openURL(" + url + ")";
                final Process exec = Runtime.getRuntime().exec(s);
                try {
                    if (exec.waitFor() != 0) {
                        s = "netscape " + url;
                        Runtime.getRuntime().exec(s);
                    }
                }
                catch (InterruptedException ex) {
                    System.err.println("Error bringing up browser, cmd='" + s + "'");
                    System.err.println("Caught: " + ex);
                }
            }
        }
        catch (IOException ex2) {
            System.err.println("Could not invoke browser, command=" + s);
            System.err.println("Caught: " + ex2);
        }
    }
    
    public static boolean isWindowsPlatform() {
        final String property = System.getProperty("os.name");
        return property != null && property.startsWith("Windows");
    }
    
    public static boolean isMacPlatform() {
        final String property = System.getProperty("os.name");
        return property != null && property.startsWith("Mac");
    }
}
