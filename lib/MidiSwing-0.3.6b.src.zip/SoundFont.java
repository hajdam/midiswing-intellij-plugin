import java.io.IOException;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.File;

// 
// Decompiled by Procyon v0.5.30
// 

public class SoundFont
{
    public String name;
    private File file;
    private String filename;
    private InstrumentKit instrumentKit;
    
    public SoundFont(final File file) {
        final byte[] array = { 0 };
        final byte[] array2 = new byte[2];
        final byte[] array3 = new byte[4];
        this.instrumentKit = new InstrumentKit();
        this.file = file;
        if (file == null) {
            this.name = "QuickTime Musical Intruments";
            this.filename = "";
        }
        else {
            this.name = "No name!";
            this.filename = file.getAbsolutePath();
            try {
                final FileInputStream fileInputStream = new FileInputStream(file);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex2) {
                    System.out.println("End of file");
                }
                final String s = new String(array3);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex3) {
                    System.out.println("End of file");
                }
                littleEndianByteArrayToUnsignedInt(array3);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex4) {
                    System.out.println("End of file");
                }
                final String s2 = new String(array3);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex5) {
                    System.out.println("End of file");
                }
                final String s3 = new String(array3);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex6) {
                    System.out.println("End of file");
                }
                final int littleEndianByteArrayToUnsignedInt = littleEndianByteArrayToUnsignedInt(array3);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex7) {
                    System.out.println("End of file");
                }
                final String s4 = new String(array3);
                long n = 4L;
                while (n < littleEndianByteArrayToUnsignedInt) {
                    try {
                        fileInputStream.read(array3);
                        n += 4L;
                    }
                    catch (EOFException ex8) {
                        System.out.println("End of file");
                    }
                    final String s5 = new String(array3);
                    try {
                        fileInputStream.read(array3);
                        n += 4L;
                    }
                    catch (EOFException ex9) {
                        System.out.println("End of file");
                    }
                    littleEndianByteArrayToUnsignedInt(array3);
                    if (s5.compareTo("ifil") != 0) {
                        if (s5.compareTo("iver") != 0) {
                            int n2 = 0;
                            int i = 0;
                            String string = "";
                            while (i == 0) {
                                try {
                                    fileInputStream.read(array);
                                    ++n;
                                }
                                catch (EOFException ex10) {
                                    System.out.println("End of file");
                                }
                                ++n2;
                                if (unsignedByteToInt(array[0]) == 0 && n2 % 2 == 0) {
                                    i = 1;
                                }
                                else {
                                    string += new String(array);
                                }
                            }
                            if (s5.compareTo("INAM") == 0) {
                                this.name = string;
                                continue;
                            }
                            continue;
                        }
                    }
                    try {
                        fileInputStream.read(array2);
                        n += 2L;
                    }
                    catch (EOFException ex11) {
                        System.out.println("End of file");
                    }
                    littleEndianByteArrayToUnsignedInt(array2);
                    try {
                        fileInputStream.read(array2);
                        n += 2L;
                    }
                    catch (EOFException ex12) {
                        System.out.println("End of file");
                    }
                    littleEndianByteArrayToUnsignedInt(array2);
                }
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex13) {
                    System.out.println("End of file");
                }
                final String s6 = new String(array3);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex14) {
                    System.out.println("End of file");
                }
                fileInputStream.skip(littleEndianByteArrayToUnsignedInt(array3));
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex15) {
                    System.out.println("End of file");
                }
                final String s7 = new String(array3);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex16) {
                    System.out.println("End of file");
                }
                final int littleEndianByteArrayToUnsignedInt2 = littleEndianByteArrayToUnsignedInt(array3);
                try {
                    fileInputStream.read(array3);
                }
                catch (EOFException ex17) {
                    System.out.println("End of file");
                }
                final String s8 = new String(array3);
                int littleEndianByteArrayToUnsignedInt3;
                for (long n3 = 4L; n3 < littleEndianByteArrayToUnsignedInt2; n3 += fileInputStream.skip(littleEndianByteArrayToUnsignedInt3)) {
                    try {
                        fileInputStream.read(array3);
                        n3 += 4L;
                    }
                    catch (EOFException ex18) {
                        System.out.println("End of file");
                    }
                    final String s9 = new String(array3);
                    try {
                        fileInputStream.read(array3);
                        n3 += 4L;
                    }
                    catch (EOFException ex19) {
                        System.out.println("End of file");
                    }
                    littleEndianByteArrayToUnsignedInt3 = littleEndianByteArrayToUnsignedInt(array3);
                    if (s9.compareTo("phdr") == 0) {
                        int n5;
                        for (int j = 0; j < littleEndianByteArrayToUnsignedInt3; j = n5 + 14) {
                            int k = 0;
                            String string2 = "";
                            while (k == 0) {
                                try {
                                    fileInputStream.read(array);
                                }
                                catch (EOFException ex20) {
                                    System.out.println("End of file");
                                }
                                if (unsignedByteToInt(array[0]) == 0) {
                                    k = 1;
                                }
                                else {
                                    string2 += new String(array);
                                }
                            }
                            fileInputStream.skip(20 - string2.length() - 1);
                            long n4 = n3 + 20L;
                            n5 = j + 20;
                            try {
                                fileInputStream.read(array2);
                                n4 += 2L;
                                n5 += 2;
                            }
                            catch (EOFException ex21) {
                                System.out.println("End of file");
                            }
                            final int littleEndianByteArrayToUnsignedInt4 = littleEndianByteArrayToUnsignedInt(array2);
                            try {
                                fileInputStream.read(array2);
                                n4 += 2L;
                                n5 += 2;
                            }
                            catch (EOFException ex22) {
                                System.out.println("End of file");
                            }
                            this.instrumentKit.add(string2, littleEndianByteArrayToUnsignedInt4, littleEndianByteArrayToUnsignedInt(array2));
                            fileInputStream.skip(14L);
                            n3 = n4 + 14L;
                        }
                    }
                    else {}
                }
                fileInputStream.close();
            }
            catch (IOException ex) {
                System.out.println("IO Exception = " + ex);
            }
        }
    }
    
    public String getName() {
        return this.name;
    }
    
    public String getPath() {
        return this.filename;
    }
    
    public InstrumentKit getKit() {
        return this.instrumentKit;
    }
    
    public static void main(final String[] array) {
        if (array.length == 1) {
            new SoundFont(new File(array[0]));
        }
        else {
            System.exit(0);
        }
    }
    
    public static int unsignedByteToInt(final byte b) {
        return b & 0xFF;
    }
    
    public static int littleEndianByteArrayToUnsignedInt(final byte[] array) {
        int n = 0;
        for (int i = 0; i < array.length; ++i) {
            n += (array[i + 0] & 0xFF) << i * 8;
        }
        return n;
    }
}
