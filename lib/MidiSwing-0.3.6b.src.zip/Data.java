import javax.sound.midi.MidiEvent;

// 
// Decompiled by Procyon v0.5.30
// 

public class Data
{
    public static final int KEYBOARD = 0;
    public static final int INSTRUMENTS = 1;
    public static final int VOLUME = 2;
    public static final int PITCHBEND = 3;
    public static final int PANPOT = 4;
    public static final int REVERBERATION = 5;
    public static final int TEMPO = 6;
    public static final int TIMESIGNATURE = 7;
    public static final int LYRICS = 8;
    public static final int DEVICE = 9;
    public static final int HOLDPEDAL = 10;
    public static final int NDATATYPES = 11;
    public Object dataValue;
    public PianoRoll p;
    public int dataType;
    public int channelNumber;
    public int trackNumber;
    public long start;
    public MidiEvent beginningEvent;
    public boolean selected;
    
    public Data(final int dataType, final Object dataValue, final int channelNumber, final long start, final int trackNumber, final MidiEvent beginningEvent, final boolean selected, final PianoRoll p8) {
        this.dataType = dataType;
        this.dataValue = dataValue;
        this.start = start;
        this.trackNumber = trackNumber;
        this.channelNumber = channelNumber;
        this.beginningEvent = beginningEvent;
        this.selected = selected;
        this.p = p8;
    }
    
    public Data copy() {
        return new Data(this.dataType, this.dataValue, this.channelNumber, this.start, this.trackNumber, this.beginningEvent, this.selected, this.p);
    }
    
    public long getTimestamp() {
        return this.start;
    }
    
    public void setTimestamp(final long start) {
        this.start = start;
    }
    
    public void setData(final int dataType, final Object dataValue) {
        this.dataType = dataType;
        this.dataValue = dataValue;
    }
    
    public int getIntValue() {
        return (int)this.dataValue;
    }
    
    public Object getValue() {
        return this.dataValue;
    }
    
    public int getChannel() {
        return this.channelNumber;
    }
    
    public String getDataName(final int n) {
        final MidiSwing midiSwing = this.p.midiWindow.midiSwing;
        return MidiSwing.resource.getString("data_" + n);
    }
}
