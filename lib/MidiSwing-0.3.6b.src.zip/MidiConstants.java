import java.util.ResourceBundle;

// 
// Decompiled by Procyon v0.5.30
// 

public abstract class MidiConstants
{
    public static ResourceBundle resource;
    private static String[] controllerTable;
    private static String[] instrumentNameTable;
    private static String[] instrumentClassTable;
    private static String[] drumsetNameTable;
    
    public static String getGMdrumsetName(final int n) {
        return MidiConstants.resource.getString("GMdrumset_" + n);
    }
    
    public static String getGMinstrumentClassName(final int n) {
        return MidiConstants.resource.getString("GMinstrumentClass_" + n);
    }
    
    public static String getGMinstrumentName(final int n) {
        return MidiConstants.resource.getString("GMinstrument_" + n);
    }
    
    public static String getControllerName(final int n) {
        return MidiConstants.resource.getString("controller_" + n);
    }
    
    public static String getDataName(final int n) {
        return MidiConstants.resource.getString("data_" + n);
    }
    
    static {
        MidiConstants.resource = ResourceBundle.getBundle("MidiSwingResource");
        MidiConstants.controllerTable = new String[128];
        MidiConstants.instrumentNameTable = new String[128];
        MidiConstants.instrumentClassTable = new String[17];
        (MidiConstants.drumsetNameTable = new String[128])[0] = "Standard Drum Set";
        MidiConstants.drumsetNameTable[1] = "Standard Drum Set 2";
        MidiConstants.drumsetNameTable[8] = "Room Set";
        MidiConstants.drumsetNameTable[16] = "Power Set";
        MidiConstants.drumsetNameTable[24] = "Electronic Set";
        MidiConstants.drumsetNameTable[25] = "TR-808 Set";
        MidiConstants.drumsetNameTable[32] = "Jazz Set";
        MidiConstants.drumsetNameTable[40] = "Brush Set";
        MidiConstants.drumsetNameTable[48] = "Orchestral Set";
        MidiConstants.drumsetNameTable[56] = "SFX Set";
        MidiConstants.drumsetNameTable[127] = "CM-64/32 C Set";
        MidiConstants.instrumentClassTable[0] = "Piano";
        MidiConstants.instrumentClassTable[1] = "Chromatic Percussion";
        MidiConstants.instrumentClassTable[2] = "Organ";
        MidiConstants.instrumentClassTable[3] = "Guitar";
        MidiConstants.instrumentClassTable[4] = "Bass";
        MidiConstants.instrumentClassTable[5] = "String/Orchestra";
        MidiConstants.instrumentClassTable[6] = "Ensemble";
        MidiConstants.instrumentClassTable[7] = "Brass";
        MidiConstants.instrumentClassTable[8] = "Reed";
        MidiConstants.instrumentClassTable[9] = "Pipe";
        MidiConstants.instrumentClassTable[10] = "Synth Lead";
        MidiConstants.instrumentClassTable[11] = "Synth Pad";
        MidiConstants.instrumentClassTable[12] = "Synth Effect";
        MidiConstants.instrumentClassTable[13] = "Ethnic";
        MidiConstants.instrumentClassTable[14] = "Percussive";
        MidiConstants.instrumentClassTable[15] = "Sound Effect";
        MidiConstants.instrumentClassTable[16] = "Percussions";
        MidiConstants.instrumentNameTable[0] = "Acoustic Grand Piano";
        MidiConstants.instrumentNameTable[1] = "Bright Acoustic Piano";
        MidiConstants.instrumentNameTable[2] = "Electric Grand Piano";
        MidiConstants.instrumentNameTable[3] = "Honky Tonk Piano";
        MidiConstants.instrumentNameTable[4] = "Electric Piano 1";
        MidiConstants.instrumentNameTable[5] = "Electric Piano 2";
        MidiConstants.instrumentNameTable[6] = "Harpsichord";
        MidiConstants.instrumentNameTable[7] = "Clavinet";
        MidiConstants.instrumentNameTable[8] = "Celesta";
        MidiConstants.instrumentNameTable[9] = "Glockenspiel";
        MidiConstants.instrumentNameTable[10] = "Music Box";
        MidiConstants.instrumentNameTable[11] = "Vibraphone";
        MidiConstants.instrumentNameTable[12] = "Marimba";
        MidiConstants.instrumentNameTable[13] = "Xylophone";
        MidiConstants.instrumentNameTable[14] = "Tubular Bells";
        MidiConstants.instrumentNameTable[15] = "Dulcimer";
        MidiConstants.instrumentNameTable[16] = "Drawbar Organ";
        MidiConstants.instrumentNameTable[17] = "Percussive Organ";
        MidiConstants.instrumentNameTable[18] = "Rock Organ";
        MidiConstants.instrumentNameTable[19] = "Church Organ";
        MidiConstants.instrumentNameTable[20] = "Reed Organ";
        MidiConstants.instrumentNameTable[21] = "Accordeon";
        MidiConstants.instrumentNameTable[22] = "Harmonica";
        MidiConstants.instrumentNameTable[23] = "Tango Accordeon/Bandeon";
        MidiConstants.instrumentNameTable[24] = "Nylon Acoustic Guitar";
        MidiConstants.instrumentNameTable[25] = "Steel Acoustic Guitar";
        MidiConstants.instrumentNameTable[26] = "Jazz Electric Guitar";
        MidiConstants.instrumentNameTable[27] = "Clean Electric Guitar";
        MidiConstants.instrumentNameTable[28] = "Muted Electric Guitar";
        MidiConstants.instrumentNameTable[29] = "Overdrive Guitar";
        MidiConstants.instrumentNameTable[30] = "Distorted Guitar";
        MidiConstants.instrumentNameTable[31] = "Guitar Harmonics";
        MidiConstants.instrumentNameTable[32] = "Acoustic Bass";
        MidiConstants.instrumentNameTable[33] = "Fingered Bass";
        MidiConstants.instrumentNameTable[34] = "Picked Bass";
        MidiConstants.instrumentNameTable[35] = "Fretless Bass";
        MidiConstants.instrumentNameTable[36] = "Slap Bass 1";
        MidiConstants.instrumentNameTable[37] = "Slap Bass 2";
        MidiConstants.instrumentNameTable[38] = "Synth Bass 1";
        MidiConstants.instrumentNameTable[39] = "Synth Bass 2";
        MidiConstants.instrumentNameTable[40] = "Violin";
        MidiConstants.instrumentNameTable[41] = "Viola";
        MidiConstants.instrumentNameTable[42] = "Cello";
        MidiConstants.instrumentNameTable[43] = "Contrabass";
        MidiConstants.instrumentNameTable[44] = "Tremolo Strings";
        MidiConstants.instrumentNameTable[45] = "Pizzicato Strings";
        MidiConstants.instrumentNameTable[46] = "Orchestral Harp";
        MidiConstants.instrumentNameTable[47] = "Timpani";
        MidiConstants.instrumentNameTable[48] = "String Ensemble 1";
        MidiConstants.instrumentNameTable[49] = "String Ensemble 2";
        MidiConstants.instrumentNameTable[50] = "Synth Strings 1";
        MidiConstants.instrumentNameTable[51] = "Synth Strings 2";
        MidiConstants.instrumentNameTable[52] = "Choir Aahs";
        MidiConstants.instrumentNameTable[53] = "Choir Oohs";
        MidiConstants.instrumentNameTable[54] = "Synth Choir";
        MidiConstants.instrumentNameTable[55] = "Orchestral Hit";
        MidiConstants.instrumentNameTable[56] = "Trumpet";
        MidiConstants.instrumentNameTable[57] = "Trombone";
        MidiConstants.instrumentNameTable[58] = "Tuba";
        MidiConstants.instrumentNameTable[59] = "Muted Trumpet";
        MidiConstants.instrumentNameTable[60] = "French Horn";
        MidiConstants.instrumentNameTable[61] = "Brass Section";
        MidiConstants.instrumentNameTable[62] = "Synth Brass 1";
        MidiConstants.instrumentNameTable[63] = "Synth Brass 2";
        MidiConstants.instrumentNameTable[64] = "Soprano Sax";
        MidiConstants.instrumentNameTable[65] = "Alto Sax";
        MidiConstants.instrumentNameTable[66] = "Tenor Sax";
        MidiConstants.instrumentNameTable[67] = "Baritone Sax";
        MidiConstants.instrumentNameTable[68] = "Oboe";
        MidiConstants.instrumentNameTable[69] = "English Horn";
        MidiConstants.instrumentNameTable[70] = "Bassoon";
        MidiConstants.instrumentNameTable[71] = "Clarinet";
        MidiConstants.instrumentNameTable[72] = "Piccolo";
        MidiConstants.instrumentNameTable[73] = "Flute";
        MidiConstants.instrumentNameTable[74] = "Recorder";
        MidiConstants.instrumentNameTable[75] = "Pan Flute";
        MidiConstants.instrumentNameTable[76] = "Bottle Blow";
        MidiConstants.instrumentNameTable[77] = "Shakuhachi";
        MidiConstants.instrumentNameTable[78] = "Whistle";
        MidiConstants.instrumentNameTable[79] = "Ocarina";
        MidiConstants.instrumentNameTable[80] = "Synth Square Wave";
        MidiConstants.instrumentNameTable[81] = "Synth Sawtooth Wave";
        MidiConstants.instrumentNameTable[82] = "Synth Calliope";
        MidiConstants.instrumentNameTable[83] = "Synth Chiff";
        MidiConstants.instrumentNameTable[84] = "Synth Charang";
        MidiConstants.instrumentNameTable[85] = "Synth Voice";
        MidiConstants.instrumentNameTable[86] = "Synth Fifths Sawtooth Wave";
        MidiConstants.instrumentNameTable[87] = "Synth Brass & Lead";
        MidiConstants.instrumentNameTable[88] = "New Age Pad";
        MidiConstants.instrumentNameTable[89] = "Warm Pad";
        MidiConstants.instrumentNameTable[90] = "Polysynth Pad";
        MidiConstants.instrumentNameTable[91] = "Choir Pad";
        MidiConstants.instrumentNameTable[92] = "Bowed Pad";
        MidiConstants.instrumentNameTable[93] = "Metal Pad";
        MidiConstants.instrumentNameTable[94] = "Halo Pad";
        MidiConstants.instrumentNameTable[95] = "Sweep Pad";
        MidiConstants.instrumentNameTable[96] = "SFX Rain";
        MidiConstants.instrumentNameTable[97] = "SFX Soundtrack";
        MidiConstants.instrumentNameTable[98] = "SFX Crystal";
        MidiConstants.instrumentNameTable[99] = "SFX Atmosphere";
        MidiConstants.instrumentNameTable[100] = "SFX Brightness";
        MidiConstants.instrumentNameTable[101] = "SFX Goblins";
        MidiConstants.instrumentNameTable[102] = "SFX Echoes";
        MidiConstants.instrumentNameTable[103] = "SFX Science-Fiction";
        MidiConstants.instrumentNameTable[104] = "Sitar";
        MidiConstants.instrumentNameTable[105] = "Banjo";
        MidiConstants.instrumentNameTable[106] = "Shamisen";
        MidiConstants.instrumentNameTable[107] = "Koto";
        MidiConstants.instrumentNameTable[108] = "Kalimba";
        MidiConstants.instrumentNameTable[109] = "Bag Pipe";
        MidiConstants.instrumentNameTable[110] = "Fiddle";
        MidiConstants.instrumentNameTable[111] = "Shanai";
        MidiConstants.instrumentNameTable[112] = "Tinkle Bell";
        MidiConstants.instrumentNameTable[113] = "Agogo";
        MidiConstants.instrumentNameTable[114] = "Steel Drums";
        MidiConstants.instrumentNameTable[115] = "Woodblock";
        MidiConstants.instrumentNameTable[116] = "Taiko Drum";
        MidiConstants.instrumentNameTable[117] = "Melodic Tom";
        MidiConstants.instrumentNameTable[118] = "Synth Drum";
        MidiConstants.instrumentNameTable[119] = "Reverse Cymbal";
        MidiConstants.instrumentNameTable[120] = "Guitar Fret Noise";
        MidiConstants.instrumentNameTable[121] = "Breath Noise";
        MidiConstants.instrumentNameTable[122] = "Seashore";
        MidiConstants.instrumentNameTable[123] = "Bird Tweet";
        MidiConstants.instrumentNameTable[124] = "Telephone Ring";
        MidiConstants.instrumentNameTable[125] = "Helicopter";
        MidiConstants.instrumentNameTable[126] = "Applause";
        MidiConstants.instrumentNameTable[127] = "Gun Shot";
        MidiConstants.controllerTable[0] = "Bank Select (coarse)";
        MidiConstants.controllerTable[1] = "Modulation Wheel (coarse)";
        MidiConstants.controllerTable[2] = "Breath controller (coarse)";
        MidiConstants.controllerTable[4] = "Foot Pedal (coarse)";
        MidiConstants.controllerTable[5] = "Portamento Time (coarse)";
        MidiConstants.controllerTable[6] = "Data Entry (coarse)";
        MidiConstants.controllerTable[7] = "Volume (coarse)";
        MidiConstants.controllerTable[8] = "Balance (coarse)";
        MidiConstants.controllerTable[10] = "Pan position (coarse)";
        MidiConstants.controllerTable[11] = "Expression (coarse)";
        MidiConstants.controllerTable[12] = "Effect Control 1 (coarse)";
        MidiConstants.controllerTable[13] = "Effect Control 2 (coarse)";
        MidiConstants.controllerTable[16] = "General Purpose Slider 1";
        MidiConstants.controllerTable[17] = "General Purpose Slider 2";
        MidiConstants.controllerTable[18] = "General Purpose Slider 3";
        MidiConstants.controllerTable[19] = "General Purpose Slider 4";
        MidiConstants.controllerTable[32] = "Bank Select (fine)";
        MidiConstants.controllerTable[33] = "Modulation Wheel (fine)";
        MidiConstants.controllerTable[34] = "Breath controller (fine)";
        MidiConstants.controllerTable[36] = "Foot Pedal (fine)";
        MidiConstants.controllerTable[37] = "Portamento Time (fine)";
        MidiConstants.controllerTable[38] = "Data Entry (fine)";
        MidiConstants.controllerTable[39] = "Volume (fine)";
        MidiConstants.controllerTable[40] = "Balance (fine)";
        MidiConstants.controllerTable[42] = "Pan position (fine)";
        MidiConstants.controllerTable[43] = "Expression (fine)";
        MidiConstants.controllerTable[44] = "Effect Control 1 (fine)";
        MidiConstants.controllerTable[45] = "Effect Control 2 (fine)";
        MidiConstants.controllerTable[64] = "Hold Pedal (on/off)";
        MidiConstants.controllerTable[65] = "Portamento (on/off)";
        MidiConstants.controllerTable[66] = "Sustenuto Pedal (on/off)";
        MidiConstants.controllerTable[67] = "Soft Pedal (on/off)";
        MidiConstants.controllerTable[68] = "Legato Pedal (on/off)";
        MidiConstants.controllerTable[69] = "Hold 2 Pedal (on/off)";
        MidiConstants.controllerTable[70] = "Sound Variation";
        MidiConstants.controllerTable[71] = "Sound Timbre";
        MidiConstants.controllerTable[72] = "Sound Release Time";
        MidiConstants.controllerTable[73] = "Sound Attack Time";
        MidiConstants.controllerTable[74] = "Sound Brightness";
        MidiConstants.controllerTable[75] = "Sound Control 6";
        MidiConstants.controllerTable[76] = "Sound Control 7";
        MidiConstants.controllerTable[77] = "Sound Control 8";
        MidiConstants.controllerTable[78] = "Sound Control 9";
        MidiConstants.controllerTable[79] = "Sound Control 10";
        MidiConstants.controllerTable[80] = "General Purpose Button 1 (on/off)";
        MidiConstants.controllerTable[81] = "General Purpose Button 2 (on/off)";
        MidiConstants.controllerTable[82] = "General Purpose Button 3 (on/off)";
        MidiConstants.controllerTable[83] = "General Purpose Button 4 (on/off)";
        MidiConstants.controllerTable[91] = "Effects Level (Reverberation)";
        MidiConstants.controllerTable[92] = "Tremulo Level";
        MidiConstants.controllerTable[93] = "Chorus Level";
        MidiConstants.controllerTable[94] = "Celeste Level";
        MidiConstants.controllerTable[95] = "Phaser Level";
        MidiConstants.controllerTable[96] = "Data Button increment";
        MidiConstants.controllerTable[97] = "Data Button decrement";
        MidiConstants.controllerTable[98] = "Non-registered Parameter (fine)";
        MidiConstants.controllerTable[99] = "Non-registered Parameter (coarse)";
        MidiConstants.controllerTable[100] = "Registered Parameter (fine)";
        MidiConstants.controllerTable[101] = "Registered Parameter (coarse)";
        MidiConstants.controllerTable[120] = "All Sound Off";
        MidiConstants.controllerTable[121] = "All Controllers Off";
        MidiConstants.controllerTable[122] = "Local Keyboard (on/off)";
        MidiConstants.controllerTable[123] = "All Notes Off";
        MidiConstants.controllerTable[124] = "Omni Mode";
        MidiConstants.controllerTable[125] = "Omni Mode On";
        MidiConstants.controllerTable[126] = "Mono Operation";
        MidiConstants.controllerTable[127] = "Poly Operation";
    }
}
