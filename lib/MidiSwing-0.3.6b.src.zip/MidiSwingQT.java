import quicktime.QTException;
import quicktime.io.QTFile;
import java.io.File;

// 
// Decompiled by Procyon v0.5.30
// 

public class MidiSwingQT extends MidiSwing
{
    public VideoPanel videoPanel;
    public boolean animateVideo;
    
    public MidiSwingQT(final int n, final File file, final int n2) {
        super(n, file, n2);
        System.out.println("MidiSwingQT000-------------------------------");
    }
    
    @Override
    public void setupGUI() {
        System.out.println("MidiSwingQT-------------------------------");
        this.videoPanel = new VideoPanel();
        this.animateVideo = false;
        this.midiWindow = new MidiWindowQT(this, "");
    }
    
    public void openMovie() {
        if (this.videoPanel != null) {
            this.videoPanel.stopPlayer();
            try {
                this.videoPanel.createNewMovieFromURL("file://" + QTFile.standardGetFilePreview(QTFile.kStandardQTFileTypes).getPath());
                this.setPlayPosition(this.sequencer.getTickPosition(), false);
            }
            catch (QTException ex) {
                if (ex.errorCode() != -128) {
                    ex.printStackTrace();
                }
            }
        }
    }
    
    public void closeMovie() {
        if (this.videoPanel != null) {
            this.videoPanel.stopPlayer();
            this.videoPanel.closeMovie();
        }
    }
    
    public void switchVideo() {
        this.animateVideo = !this.animateVideo;
    }
    
    @Override
    public void setPlayPosition(final long n, final boolean b) {
        super.setPlayPosition(n, b);
        this.videoPanel.setTime((int)Math.floor(600.0 * this.sequencer.getMicrosecondPosition() / 1000000.0));
    }
    
    @Override
    public void play() {
        super.play();
        if (this.animateVideo) {
            this.videoPanel.startPlayer();
        }
    }
    
    @Override
    public void stop() {
        super.stop();
        if (this.animateVideo) {
            this.videoPanel.stopPlayer();
            final int n = (int)Math.floor(600.0 * this.getMicrosecondPosition() / 1000000.0);
        }
    }
    
    @Override
    public void rewind() {
        super.rewind();
        this.videoPanel.setTime(0);
        if (this.animateVideo) {
            this.videoPanel.stopPlayer();
        }
    }
}
