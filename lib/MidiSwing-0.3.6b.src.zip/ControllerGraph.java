import java.awt.Dimension;
import java.awt.Shape;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.Collection;
import java.util.Vector;
import java.awt.Rectangle;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.sound.midi.MidiEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPopupMenu;
import java.awt.Color;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import javax.swing.JPanel;

// 
// Decompiled by Procyon v0.5.30
// 

class ControllerGraph extends JPanel implements MouseListener, MouseMotionListener
{
    final int ON = 0;
    final int OFF = 1;
    final int tempoMax = 500;
    public PianoRoll p;
    public MidiSwing m;
    private long selectionStartX;
    private long selectionEndX;
    private long selectionMoveX;
    private int selectionStartY;
    private int selectionEndY;
    private int selectionMoveY;
    private int clickX;
    private int clickY;
    private int dragClickX;
    private int dragClickY;
    private Program pointedProgram;
    private Data pointedData;
    private boolean nameClicked;
    private Piano piano;
    
    public ControllerGraph(final PianoRoll p) {
        this.setBackground(Color.white);
        this.p = p;
        this.m = this.p.midiWindow.midiSwing;
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        this.selectionMoveX = 0L;
        this.selectionMoveY = 0;
        this.piano = new Piano();
    }
    
    public JPopupMenu createMenuFromKit(final InstrumentKit instrumentKit, final int n) {
        final JPopupMenu popupMenu = new JPopupMenu();
        final JPopupMenu popupMenu2 = new JPopupMenu();
        final ActionListener actionListener = new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                final int index = actionEvent.getActionCommand().indexOf("-");
                final int int1 = Integer.parseInt(actionEvent.getActionCommand().substring(0, index));
                final int int2 = Integer.parseInt(actionEvent.getActionCommand().substring(index + 1));
                if (ControllerGraph.this.p.mode2 == 2) {
                    ControllerGraph.this.pointedProgram.set(int1, int2);
                    ControllerGraph.this.p.alterProgram(ControllerGraph.this.pointedProgram);
                }
                if (ControllerGraph.this.p.mode2 == 4 && ControllerGraph.this.m.currentChannel != -1) {
                    final Program program = new Program(int1, int2, ControllerGraph.this.m.currentChannel, ControllerGraph.this.p.invertX(ControllerGraph.this.clickX), ControllerGraph.this.m.currentTrack, null, null, false, ControllerGraph.this.p);
                    ControllerGraph.this.p.insertProgram(ControllerGraph.this.m.currentTrack, ControllerGraph.this.m.currentChannel, program);
                    ControllerGraph.this.p.alterProgram(program);
                }
            }
        };
        if (instrumentKit.size() < 20) {
            for (int i = 0; i < instrumentKit.size() - 1; ++i) {
                JMenuItem menuItem;
                if (instrumentKit.getBank(i) > -1 && instrumentKit.getBank(i) < 128) {
                    menuItem = new JMenuItem("[" + instrumentKit.getPreset(i) + "-" + instrumentKit.getBank(i) + "] " + instrumentKit.getName(i));
                }
                else {
                    menuItem = new JMenuItem("[" + instrumentKit.getPreset(i) + "] " + instrumentKit.getName(i));
                }
                menuItem.setActionCommand("" + instrumentKit.getPreset(i) + "-" + instrumentKit.getBank(i));
                menuItem.addActionListener(actionListener);
                popupMenu2.add(menuItem);
            }
        }
        else {
            if (n != 9) {
                for (int j = 0; j < 16; ++j) {
                    final JMenu menu = new JMenu(MidiConstants.getGMinstrumentClassName(j));
                    for (int k = 0; k < 8; ++k) {
                        final int n2 = j * 8 + k;
                        final InstrumentKit subkitForPreset = instrumentKit.getSubkitForPreset(n2);
                        if (subkitForPreset.size() != 0) {
                            if (subkitForPreset.size() == 1) {
                                JMenuItem menuItem2;
                                if (subkitForPreset.getBank(0) > -1 && subkitForPreset.getBank(0) < 128) {
                                    menuItem2 = new JMenuItem("[" + n2 + "-" + subkitForPreset.getBank(0) + "] " + subkitForPreset.getName(0));
                                }
                                else {
                                    menuItem2 = new JMenuItem("[" + n2 + "] " + subkitForPreset.getName(0));
                                }
                                menuItem2.setActionCommand("" + n2 + "-" + subkitForPreset.getBank(0));
                                menuItem2.addActionListener(actionListener);
                                menu.add(menuItem2);
                            }
                            else {
                                final JMenu menu2 = new JMenu(MidiConstants.getGMinstrumentName(n2));
                                for (int l = 0; l < subkitForPreset.size(); ++l) {
                                    JMenuItem menuItem3;
                                    if (subkitForPreset.getBank(l) > -1 && subkitForPreset.getBank(l) < 128) {
                                        menuItem3 = new JMenuItem("[" + n2 + "-" + subkitForPreset.getBank(l) + "] " + subkitForPreset.getName(l));
                                    }
                                    else {
                                        menuItem3 = new JMenuItem("[" + n2 + "] " + subkitForPreset.getName(l));
                                    }
                                    menuItem3.setActionCommand("" + n2 + "-" + subkitForPreset.getBank(l));
                                    menuItem3.addActionListener(actionListener);
                                    menu2.add(menuItem3);
                                }
                                menu.add(menu2);
                            }
                        }
                    }
                    if (menu.getItemCount() != 0) {
                        popupMenu2.add(menu);
                    }
                }
            }
            if (n == 9) {
                final InstrumentKit subkitForBank = instrumentKit.getSubkitForBank(128);
                if (subkitForBank.size() != 0) {
                    for (int n3 = 0; n3 < subkitForBank.size(); ++n3) {
                        final JMenuItem menuItem4 = new JMenuItem("[" + subkitForBank.getPreset(n3) + "] " + subkitForBank.getName(n3));
                        menuItem4.setActionCommand("" + subkitForBank.getPreset(n3) + "-" + subkitForBank.getBank(n3));
                        menuItem4.addActionListener(actionListener);
                        popupMenu2.add(menuItem4);
                    }
                }
            }
        }
        popupMenu2.addSeparator();
        final MidiSwing m = this.m;
        final JMenuItem menuItem5 = new JMenuItem(MidiSwing.resource.getString("DELETE"));
        menuItem5.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                if (ControllerGraph.this.p.mode2 == 2) {
                    ControllerGraph.this.p.removeProgram(ControllerGraph.this.pointedProgram);
                    ControllerGraph.this.m.modification();
                }
            }
        });
        popupMenu2.add(menuItem5);
        return popupMenu2;
    }
    
    public void hitKey(final long n, final Color color) {
        final Key key = this.piano.getKey((int)n);
        if (key != null) {
            key.on(color);
        }
        this.repaint();
    }
    
    public void releaseKey(final long n) {
        final Key key = this.piano.getKey((int)n);
        if (key != null) {
            key.off();
        }
        this.repaint();
    }
    
    public void releaseAllKeys() {
        this.piano.releaseAllKeys();
    }
    
    public void paintData(final int n, final Graphics graphics) {
        long n2;
        if (this.p.singleTrackDisplay) {
            n2 = this.p.midiWindow.midiSwing.getCurrentTrack().ticks();
        }
        else {
            n2 = this.m.getSequenceLength();
        }
        int intValue = 0;
        long timestamp = 0L;
        Data data = null;
        int n3 = 0;
        int currentChannel = this.m.currentChannel;
        int n4 = 128;
        final int resolution = this.p.getResolution();
        final int width = this.getWidth();
        final int height = this.getHeight();
        final long viewPositionX = this.p.viewPositionX;
        final long n5 = (long)Math.min(n2, this.p.viewPositionX + width * resolution / this.p.scaleX);
        graphics.setColor(new Color(100, 160, 200));
        graphics.setFont(new Font("Arial", 0, 12));
        graphics.drawString(MidiConstants.getDataName(n), 20, 20);
        if (n == 6) {
            n3 = 15;
            currentChannel = 0;
            n4 = 500;
        }
        for (int i = this.m.numberOfTracks; i > 0; --i) {
            final int n6 = (i - 1 + this.m.currentTrack) % this.m.numberOfTracks;
            for (int j = n3; j < 16; ++j) {
                final int n7 = (j + 1 + currentChannel) % 16;
                if (this.p.midiWindow.channelButton[n7].isSelected() || n == 6) {
                    Color color;
                    if (n == 6) {
                        color = new Color(100, 100, 100);
                    }
                    else {
                        color = MidiWindow.channelColor[n7];
                    }
                    final int numberOfDataIn = this.p.getNumberOfDataIn(n6, n7, n);
                    if (numberOfDataIn != 0) {
                        data = this.p.getData(n6, n7, n, 0);
                        timestamp = data.getTimestamp();
                        intValue = data.getIntValue();
                        if (n == 6) {
                            intValue = 60000000 / intValue;
                        }
                    }
                    for (int k = 0; k < numberOfDataIn; ++k) {
                        long timestamp2;
                        int intValue2;
                        if (k == numberOfDataIn - 1) {
                            timestamp2 = n5;
                            intValue2 = intValue;
                        }
                        else {
                            data = this.p.getData(n6, n7, n, k + 1);
                            timestamp2 = data.getTimestamp();
                            intValue2 = data.getIntValue();
                            if (n == 6) {
                                intValue2 = 60000000 / intValue2;
                            }
                        }
                        final long min = Math.min(n5, timestamp2);
                        if (timestamp <= n5 && min >= viewPositionX) {
                            if (n6 == this.m.currentTrack || !this.p.singleTrackDisplay) {
                                if (n7 == currentChannel) {
                                    if (data.selected) {
                                        graphics.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 255));
                                    }
                                    else {
                                        graphics.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 100));
                                    }
                                    graphics.fillRect(this.p.mapX(timestamp), height * (n4 - intValue) / n4, this.p.scaleX(min - timestamp), height * intValue / n4);
                                }
                                graphics.setColor(color);
                            }
                            else {
                                graphics.setColor(new Color(200, 200, 200));
                            }
                            graphics.drawLine(this.p.mapX(timestamp), height * (n4 - intValue) / n4, this.p.mapX(min), height * (n4 - intValue) / n4);
                        }
                        timestamp = min;
                        intValue = intValue2;
                    }
                }
            }
        }
        if (this.p.mode2 == 5 && this.p.currentGraph == 2) {
            graphics.setColor(Color.black);
            graphics.drawLine(this.clickX, this.clickY, this.dragClickX, this.dragClickY);
        }
    }
    
    public void paintTimeSignature(final Graphics graphics) {
        final long ticks = this.p.midiWindow.midiSwing.getCurrentTrack().ticks();
        final int[] array = new int[4];
        final int n = 7;
        final int resolution = this.p.getResolution();
        final int width = this.getWidth();
        this.getHeight();
        final long viewPositionX = this.p.viewPositionX;
        final long n2 = (long)Math.min(ticks, this.p.viewPositionX + width * resolution / this.p.scaleX);
        graphics.setColor(new Color(100, 160, 200));
        graphics.setFont(new Font("Arial", 0, 12));
        graphics.drawString(MidiConstants.getDataName(n), 20, 20);
        graphics.setFont(new Font("Arial", 1, 22));
        graphics.setColor(new Color(20, 20, 20));
        for (int i = this.m.numberOfTracks; i > 0; --i) {
            final int n3 = (i - 1 + this.m.currentTrack) % this.m.numberOfTracks;
            for (int numberOfDataIn = this.p.getNumberOfDataIn(n3, 0, n), j = 0; j < numberOfDataIn; ++j) {
                final Data data = this.p.getData(n3, 0, n, j);
                final long timestamp = data.getTimestamp();
                if (timestamp >= viewPositionX && timestamp <= n2) {
                    final int[] array2 = (int[])data.getValue();
                    graphics.drawString("" + array2[0], this.p.mapX(timestamp) + 4 + 4, 50);
                    graphics.drawString("" + (1 << array2[1]), this.p.mapX(timestamp) + 4 + 4, 74);
                    graphics.drawLine(this.p.mapX(timestamp) + 3 + 4, 53, this.p.mapX(timestamp) + 16 + 4, 53);
                }
            }
        }
        if (this.p.mode2 == 5) {
            graphics.setColor(Color.black);
            graphics.drawLine(this.clickX, this.clickY, this.dragClickX, this.dragClickY);
        }
    }
    
    public void paintInstruments(final Graphics graphics) {
        final int resolution = this.p.getResolution();
        final int width = this.getWidth();
        final int height = this.getHeight();
        final long viewPositionX = this.p.viewPositionX;
        final long n = (long)(this.p.viewPositionX + width * resolution / this.p.scaleX);
        int max;
        if (this.m.numberOfSelectedChannels != 0) {
            max = Math.max(height / this.m.numberOfSelectedChannels, 20);
        }
        else {
            max = 10;
        }
        graphics.setFont(new Font("Arial", 0, max / 2));
        for (int i = this.m.numberOfTracks; i > 0; --i) {
            final int n2 = (i - 1 + this.m.currentTrack) % this.m.numberOfTracks;
            int n3 = 0;
            for (int j = 0; j < 16; ++j) {
                final int n4 = j;
                if (this.p.midiWindow.channelButton[n4].isSelected()) {
                    final Color color = MidiWindow.channelColor[n4];
                    for (int numberOfProgramsIn = this.p.getNumberOfProgramsIn(n2, n4), k = 0; k < numberOfProgramsIn; ++k) {
                        final Program program = this.p.getProgram(n2, n4, k);
                        final long timestamp = program.getTimestamp();
                        final long max2 = Math.max(viewPositionX, timestamp);
                        long timestamp2;
                        if (k == numberOfProgramsIn - 1) {
                            timestamp2 = n;
                        }
                        else {
                            timestamp2 = this.p.getProgram(n2, n4, k + 1).getTimestamp();
                        }
                        final long min = Math.min(n, timestamp2);
                        if (max2 <= n && min >= viewPositionX) {
                            if (n2 == this.m.currentTrack || !this.p.singleTrackDisplay) {
                                graphics.setColor(color);
                            }
                            else {
                                graphics.setColor(new Color(200, 200, 200));
                            }
                            graphics.fillRect(this.p.mapX(max2), n3, this.p.mapX(min), max);
                            graphics.setColor(new Color(255, 255, 255, 100));
                            graphics.drawLine(this.p.mapX(max2), n3, this.p.mapX(min), n3);
                            graphics.setColor(new Color(0, 0, 0, 100));
                            graphics.drawLine(this.p.mapX(max2), n3 + max - 1, this.p.mapX(min), n3 + max - 1);
                            graphics.setColor(new Color(255, 255, 255, 100));
                            graphics.drawLine(this.p.mapX(timestamp) + 1, n3 + 1, this.p.mapX(timestamp) + 1, n3 + max - 2);
                            graphics.setColor(new Color(0, 0, 0, 100));
                            graphics.drawLine(this.p.mapX(timestamp), n3, this.p.mapX(timestamp), n3 + max - 1);
                            if (color.getRed() + color.getGreen() + color.getBlue() < 382) {
                                graphics.setColor(new Color(255, 255, 255, 220));
                            }
                            else {
                                graphics.setColor(new Color(0, 0, 0, 220));
                            }
                            final InstrumentKit kitForChannel = this.m.getKitForChannel(program.getChannel());
                            final int bank = program.getBank();
                            String s = kitForChannel.getName(program.getProgram(), program.getBank());
                            if (bank == -1 && s.compareTo("") == 0) {
                                s = kitForChannel.getName(program.getProgram(), 0);
                            }
                            if (bank == 0 && s.compareTo("") == 0) {
                                s = kitForChannel.getName(program.getProgram(), -1);
                            }
                            if (s.compareTo("") == 0) {
                                final MidiSwing m = this.m;
                                s = MidiSwing.resource.getString("NOT_DEFINED_FOR_THIS_BANK");
                            }
                            String s2;
                            if (bank > -1 && bank < 128) {
                                s2 = "[" + program.getProgram() + "-" + program.getBank() + "] " + s;
                            }
                            else {
                                s2 = "[" + program.getProgram() + "] " + s;
                            }
                            graphics.drawString("(" + (n4 + 1) + ") " + s2, Math.min(this.p.mapX(max2), this.p.mapX(min) - 0) + 10, n3 + 2 * max / 3);
                        }
                    }
                    n3 += max;
                }
            }
        }
    }
    
    public void paintComponent(final Graphics graphics) {
        super.paintComponent(graphics);
        final int resolution = this.p.getResolution();
        final int width = this.getWidth();
        final int height = this.getHeight();
        final long viewPositionX = this.p.viewPositionX;
        final long n = (long)(this.p.viewPositionX + width * resolution / this.p.scaleX);
        final PianoRoll p = this.p;
        final int n2 = PianoRoll.controllerChooserList[this.p.controllerType];
        if (n2 != 0) {
            this.p.pianoRollGraph.paintMeasures(graphics);
        }
        switch (n2) {
            case 0: {
                this.piano.paint(graphics);
                break;
            }
            case 1: {
                this.paintInstruments(graphics);
                break;
            }
            case 4: {
                this.paintData(4, graphics);
                break;
            }
            case 2: {
                this.paintData(2, graphics);
                break;
            }
            case 5: {
                this.paintData(5, graphics);
                break;
            }
            case 3: {
                this.paintData(3, graphics);
                break;
            }
            case 6: {
                this.paintData(6, graphics);
                break;
            }
            case 7: {
                this.paintTimeSignature(graphics);
                break;
            }
            case 10: {
                this.paintData(10, graphics);
                break;
            }
        }
        if (n2 != 0) {
            graphics.setColor(Color.green);
            graphics.drawLine(this.p.mapX(this.p.playPosition), 0, this.p.mapX(this.p.playPosition), height);
        }
        final int n3 = 0;
        graphics.setColor(new Color(100, 100, 100));
        graphics.drawLine(0, n3, width, n3);
        for (int i = 0; i < 6; ++i) {
            graphics.setColor(new Color(0, 0, 0, 2 * (6 - i) * (6 - i)));
            graphics.drawLine(0, n3 + 1 + i, width, n3 + 1 + i);
        }
    }
    
    public void mouseClicked(final MouseEvent mouseEvent) {
        final PianoRoll p = this.p;
        if (PianoRoll.controllerChooserList[this.p.controllerType] == 0) {
            this.piano.mouseClicked(mouseEvent, this);
        }
    }
    
    public Program pointedProgram(final int n, final int n2) {
        final int min = Math.min(15, n2 / Math.max(this.getHeight() / this.m.numberOfSelectedChannels, 20));
        int n3 = -1;
        int n4 = -1;
        for (int n5 = 0; n5 < 16 && n3 == -1; ++n5) {
            final int n6 = n5;
            if (this.p.midiWindow.channelButton[n6].isSelected() && ++n4 == min) {
                n3 = n6;
            }
        }
        this.nameClicked = false;
        if (this.p.singleTrackDisplay) {
            final int currentTrack = this.m.currentTrack;
        }
        else {
            this.m.trackWhoseMainChannelIs(n3);
        }
        return this.p.getProgramAtTime(n3, this.p.invertX(n));
    }
    
    public Data pointedData(final int n, final int n2, final int n3) {
        Data dataAtTime = null;
        switch (n) {
            case 7: {
                dataAtTime = this.p.getDataAtTime(n, 0, 0, this.p.invertX(n2));
                if (dataAtTime != null && n2 > this.p.mapX(dataAtTime.getTimestamp()) + 20) {
                    dataAtTime = null;
                    break;
                }
                break;
            }
        }
        return dataAtTime;
    }
    
    public void mousePressed(final MouseEvent mouseEvent) {
        final PianoRoll p = this.p;
        final int n = PianoRoll.controllerChooserList[this.p.controllerType];
        if (n == 0) {
            this.piano.mousePressed(mouseEvent, this);
        }
        else {
            this.clickX = mouseEvent.getX();
            this.clickY = mouseEvent.getY();
            if (this.p.mode2 == 1) {
                this.p.midiWindow.midiSwing.setPlayPosition(this.p.invertX(mouseEvent.getX()), true);
            }
            if (this.p.mode2 == 2) {
                switch (n) {
                    case 1: {
                        this.pointedProgram = this.pointedProgram(this.clickX, this.clickY);
                        if (this.pointedProgram != null && this.clickX >= 20 + this.p.mapX(this.pointedProgram.getTimestamp())) {
                            this.nameClicked = true;
                            this.createMenuFromKit(this.m.getKitForChannel(this.pointedProgram.getChannel()), this.pointedProgram.getChannel()).show(this, this.clickX - 5, this.clickY);
                            break;
                        }
                        break;
                    }
                    case 7: {
                        this.pointedData = this.pointedData(7, this.clickX, this.clickY);
                        break;
                    }
                }
            }
            if (this.p.mode2 == 4) {
                final long invertX = this.p.invertX(this.clickX);
                switch (n) {
                    case 1: {
                        if (this.m.currentChannel != -1) {
                            this.createMenuFromKit(this.m.getKitForChannel(this.m.currentChannel), this.m.currentChannel).show(this, this.clickX - 5, this.clickY);
                            break;
                        }
                        break;
                    }
                    case 7: {
                        Data pointedData = this.pointedData(7, this.clickX, this.clickY);
                        int int1 = 4;
                        int int2 = 4;
                        if (pointedData != null) {
                            final int[] array = (int[])pointedData.getValue();
                            int1 = array[0];
                            int2 = 1 << array[1];
                        }
                        final JTextField textField = new JTextField("" + int1);
                        final JTextField textField2 = new JTextField("" + int2);
                        final Object[] array2 = new Object[4];
                        final int n2 = 0;
                        final MidiSwing m = this.m;
                        array2[n2] = MidiSwing.resource.getString("NUMERATOR");
                        array2[1] = textField;
                        final int n3 = 2;
                        final MidiSwing i = this.m;
                        array2[n3] = MidiSwing.resource.getString("DENOMINATOR");
                        array2[3] = textField2;
                        final int showConfirmDialog = JOptionPane.showConfirmDialog(this.m.midiWindow, array2);
                        this.m.midiWindow.requestFocus();
                        if (showConfirmDialog == 0) {
                            if (textField.getText() != "") {
                                int1 = Integer.parseInt(textField.getText());
                            }
                            if (textField2.getText() != "") {
                                int2 = Integer.parseInt(textField2.getText());
                            }
                            final int[] array3 = { int1, this.log(int2), 8, 8 };
                            if (pointedData == null) {
                                pointedData = new Data(7, array3, 0, invertX, 0, null, false, this.p);
                                this.p.insertData(0, 0, 7, pointedData);
                            }
                            else {
                                pointedData.setData(7, array3);
                            }
                            this.p.alterData(pointedData);
                            this.p.repaint();
                            break;
                        }
                        break;
                    }
                    default: {
                        this.p.mode2 = 5;
                        break;
                    }
                }
            }
        }
    }
    
    private int log(final int n) {
        int i;
        int n2;
        for (i = n, n2 = 0; i > 1; i /= 2, ++n2) {}
        return n2;
    }
    
    public void mouseReleased(final MouseEvent mouseEvent) {
        final PianoRoll p = this.p;
        final int n = PianoRoll.controllerChooserList[this.p.controllerType];
        if (n == 0) {
            this.piano.mouseReleased(mouseEvent, this);
        }
        else {
            int currentTrack;
            if (n != 6 && n != 7) {
                currentTrack = this.m.currentTrack;
            }
            else {
                currentTrack = 0;
            }
            if (this.p.mode2 == 2) {
                switch (n) {
                    case 1: {
                        if (this.pointedProgram != null) {
                            this.p.alterProgram(this.pointedProgram);
                        }
                        this.repaint();
                        break;
                    }
                    case 7: {
                        if (this.pointedData != null) {
                            if (mouseEvent.getY() > 0) {
                                this.p.alterData(this.pointedData);
                            }
                            else {
                                this.p.removeData(this.pointedData);
                            }
                        }
                        this.repaint();
                        break;
                    }
                }
            }
            if (this.p.mode2 == 5) {
                this.p.mode2 = 4;
                final long invertX = this.p.invertX(this.clickX);
                final long invertX2 = this.p.invertX(mouseEvent.getX());
                final int n2 = 128 * (this.getHeight() - this.clickY) / this.getHeight();
                final int n3 = 128 * (this.getHeight() - mouseEvent.getY()) / this.getHeight();
                int currentChannel;
                if (n == 6) {
                    currentChannel = 0;
                }
                else {
                    currentChannel = this.m.currentChannel;
                }
                if (currentChannel != -1) {
                    this.p.removeDataInTheRange(currentTrack, currentChannel, n, invertX, invertX2);
                }
                switch (n) {
                    case 10: {
                        if (currentChannel != -1) {
                            int n4;
                            if (n2 > 64) {
                                n4 = 127;
                            }
                            else {
                                n4 = 0;
                            }
                            final Data data = new Data(n, new Integer(n4), currentChannel, invertX, currentTrack, null, false, this.p);
                            this.p.insertData(currentTrack, currentChannel, n, data);
                            this.p.alterData(data);
                            break;
                        }
                        break;
                    }
                    default: {
                        int n5 = n2;
                        int i = 1;
                        while (i != 0) {
                            int min = Math.min(127, Math.max(0, n5));
                            long n6;
                            if (n2 == n3) {
                                n6 = invertX;
                            }
                            else {
                                n6 = invertX + (invertX2 - invertX) * (n5 - n2) / (n3 - n2);
                            }
                            if (n == 6) {
                                if (min == 0) {
                                    min = (int)Math.floor(1.536E7);
                                }
                                else {
                                    min = (int)Math.floor(7.68E9 / (500 * min));
                                }
                            }
                            if (currentChannel != -1) {
                                final Data data2 = new Data(n, new Integer(min), currentChannel, n6, currentTrack, null, false, this.p);
                                this.p.insertData(currentTrack, currentChannel, n, data2);
                                this.p.alterData(data2);
                            }
                            if (n2 <= n3) {
                                ++n5;
                                if (n5 < n3) {
                                    continue;
                                }
                                i = 0;
                            }
                            else {
                                --n5;
                                if (n5 > n3) {
                                    continue;
                                }
                                i = 0;
                            }
                        }
                        int min2 = Math.min(127, Math.max(0, n3));
                        if (n == 6) {
                            if (min2 == 0) {
                                min2 = (int)Math.floor(1.536E7);
                            }
                            else {
                                min2 = (int)Math.floor(7.68E9 / (500 * min2));
                            }
                        }
                        final long n7 = invertX2;
                        if (currentChannel != -1) {
                            final Data data3 = new Data(n, new Integer(min2), currentChannel, n7, currentTrack, null, false, this.p);
                            this.p.insertData(currentTrack, currentChannel, n, data3);
                            this.p.alterData(data3);
                            break;
                        }
                        break;
                    }
                }
                this.m.modification();
                this.repaint();
            }
        }
    }
    
    public void mouseEntered(final MouseEvent mouseEvent) {
        final PianoRoll p = this.p;
        final PianoRoll p2 = this.p;
        p.currentGraph = 2;
    }
    
    public void mouseExited(final MouseEvent mouseEvent) {
        final PianoRoll p = this.p;
        if (PianoRoll.controllerChooserList[this.p.controllerType] == 0) {
            this.piano.mouseExited(mouseEvent, this);
        }
    }
    
    public void mouseMoved(final MouseEvent mouseEvent) {
        final PianoRoll p = this.p;
        final int n = PianoRoll.controllerChooserList[this.p.controllerType];
        if (n != 0) {
            if (this.p.mode2 == 2) {
                switch (n) {
                    case 1: {
                        this.pointedProgram = this.pointedProgram(mouseEvent.getX(), mouseEvent.getY());
                        if (this.pointedProgram == null) {
                            break;
                        }
                        if (mouseEvent.getX() >= 20 + this.p.mapX(this.pointedProgram.getTimestamp())) {
                            this.nameClicked = true;
                            this.setCursor(this.p.fingerCursor);
                            break;
                        }
                        this.nameClicked = false;
                        this.setCursor(this.p.stretchCursor);
                        break;
                    }
                    case 7: {
                        this.pointedData = this.pointedData(7, mouseEvent.getX(), mouseEvent.getY());
                        if (this.pointedData != null) {
                            this.setCursor(this.p.stretchCursor);
                            break;
                        }
                        this.setCursor(this.p.arrowCursor);
                        break;
                    }
                }
            }
        }
    }
    
    public void mouseDragged(final MouseEvent mouseEvent) {
        final PianoRoll p = this.p;
        final int n = PianoRoll.controllerChooserList[this.p.controllerType];
        if (n == 0) {
            this.piano.mouseDragged(mouseEvent, this);
        }
        else {
            if (this.p.mode2 == 1) {
                this.p.midiWindow.midiSwing.setPlayPosition(this.p.invertX(mouseEvent.getX()), true);
            }
            if (this.p.mode2 == 2) {
                switch (n) {
                    case 1: {
                        if (this.pointedProgram != null && !this.nameClicked) {
                            this.pointedProgram.setTimestamp(Math.max(0L, this.p.invertX(mouseEvent.getX())));
                            this.p.removeProgram(this.pointedProgram);
                            this.p.insertProgram(this.pointedProgram.trackNumber, this.pointedProgram.channelNumber, this.pointedProgram);
                        }
                        this.repaint();
                        break;
                    }
                    case 7: {
                        if (this.pointedData != null) {
                            this.pointedData.setTimestamp(Math.max(0L, this.p.invertX(mouseEvent.getX())));
                            this.p.removeData(this.pointedData);
                            this.p.insertData(this.pointedData.trackNumber, this.pointedData.channelNumber, this.pointedData.dataType, this.pointedData);
                        }
                        this.p.repaint();
                        break;
                    }
                }
            }
            if (this.p.mode2 == 5) {
                this.dragClickX = mouseEvent.getX();
                this.dragClickY = mouseEvent.getY();
                this.repaint();
            }
        }
    }
    
    class Key extends Rectangle
    {
        int noteState;
        int kNum;
        Color noteColor;
        
        public Key(final int n, final int n2, final int n3, final int n4, final int kNum) {
            super(n, n2, n3, n4);
            this.noteState = 1;
            this.kNum = kNum;
        }
        
        public boolean isNoteOn() {
            return this.noteState == 0;
        }
        
        public void on(final Color noteColor) {
            this.setNoteState(0);
            this.setNoteColor(noteColor);
        }
        
        public void off() {
            this.setNoteState(1);
        }
        
        public void setNoteState(final int noteState) {
            this.noteState = noteState;
        }
        
        public void setNoteColor(final Color noteColor) {
            this.noteColor = noteColor;
        }
    }
    
    class Piano
    {
        int transpose;
        Vector keys;
        Vector whiteKeys;
        Vector blackKeys;
        Key firstKey;
        Key prevKey;
        final int kw = 16;
        final int kh = 73;
        
        public Piano() {
            this.keys = new Vector();
            this.whiteKeys = new Vector();
            this.blackKeys = new Vector();
            this.transpose = 12;
            final int[] array = { 0, 2, 4, 5, 7, 9, 11 };
            final int n = 8;
            int i = 0;
            int n2 = 0;
            while (i < n) {
                for (int j = 0; j < 7; ++j, n2 += 16) {
                    this.whiteKeys.add(new Key(n2, 0, 16, 73, i * 12 + array[j] + this.transpose));
                }
                ++i;
            }
            for (int k = 0, n3 = 0; k < n; ++k, n3 += 16) {
                final int n4 = k * 12 + this.transpose;
                final Vector blackKeys = this.blackKeys;
                n3 += 16;
                blackKeys.add(new Key(n3 - 4, 0, 8, 43, n4 + 1));
                final Vector blackKeys2 = this.blackKeys;
                n3 += 16;
                blackKeys2.add(new Key(n3 - 4, 0, 8, 43, n4 + 3));
                n3 += 16;
                final Vector blackKeys3 = this.blackKeys;
                n3 += 16;
                blackKeys3.add(new Key(n3 - 4, 0, 8, 43, n4 + 6));
                final Vector blackKeys4 = this.blackKeys;
                n3 += 16;
                blackKeys4.add(new Key(n3 - 4, 0, 8, 43, n4 + 8));
                final Vector blackKeys5 = this.blackKeys;
                n3 += 16;
                blackKeys5.add(new Key(n3 - 4, 0, 8, 43, n4 + 10));
            }
            this.keys.addAll(this.blackKeys);
            this.keys.addAll(this.whiteKeys);
        }
        
        public void mousePressed(final MouseEvent mouseEvent, final ControllerGraph controllerGraph) {
            this.prevKey = this.getKey(mouseEvent.getPoint());
            this.firstKey = this.prevKey;
            if (this.prevKey != null && ControllerGraph.this.m.currentChannel != -1) {
                ControllerGraph.this.m.playNote(ControllerGraph.this.m.currentChannel, ControllerGraph.this.m.getTickPosition(), this.prevKey.kNum, 127);
                if (ControllerGraph.this.p.mode2 == 4) {
                    final Note note = new Note(this.prevKey.kNum, 127, ControllerGraph.this.m.currentChannel, ControllerGraph.this.p.playPosition, ControllerGraph.this.p.playPosition + 480L, ControllerGraph.this.m.currentTrack, null, null, true, null, ControllerGraph.this.p);
                    ControllerGraph.this.p.addNote(ControllerGraph.this.m.currentTrack, note);
                    ControllerGraph.this.p.emptySelection();
                    ControllerGraph.this.p.addNoteToSelection(note);
                    ControllerGraph.this.p.pianoRollGraph.repaint();
                }
            }
        }
        
        public void mouseReleased(final MouseEvent mouseEvent, final ControllerGraph controllerGraph) {
            if (this.prevKey != null && ControllerGraph.this.m.currentChannel != -1) {
                ControllerGraph.this.m.stopNote(ControllerGraph.this.m.currentChannel, this.prevKey.kNum, 127);
                if (ControllerGraph.this.p.mode2 == 4) {
                    ControllerGraph.this.p.alterSelection(0L, ControllerGraph.this.p.pianoRollGraph.selectionMoveY, 1.0, 1.0);
                    ControllerGraph.this.p.pianoRollGraph.selectionMoveY = 0;
                }
            }
        }
        
        public void mouseExited(final MouseEvent mouseEvent, final ControllerGraph controllerGraph) {
            if (this.prevKey != null) {
                this.prevKey.off();
                this.prevKey = null;
            }
        }
        
        public void mouseClicked(final MouseEvent mouseEvent, final ControllerGraph controllerGraph) {
        }
        
        public void mouseEntered(final MouseEvent mouseEvent, final ControllerGraph controllerGraph) {
        }
        
        public void mouseDragged(final MouseEvent mouseEvent, final ControllerGraph controllerGraph) {
            if (ControllerGraph.this.m.currentChannel != -1) {
                final Key key = this.getKey(mouseEvent.getPoint());
                if (key != this.prevKey) {
                    if (this.prevKey != null) {
                        ControllerGraph.this.m.stopNote(ControllerGraph.this.m.currentChannel, this.prevKey.kNum, 127);
                    }
                    if (key != null) {
                        ControllerGraph.this.m.playNote(ControllerGraph.this.m.currentChannel, ControllerGraph.this.m.getTickPosition(), key.kNum, 127);
                    }
                    this.prevKey = key;
                }
                if (ControllerGraph.this.p.mode2 == 4) {
                    ControllerGraph.this.p.pianoRollGraph.selectionMoveY = key.kNum - this.firstKey.kNum;
                    ControllerGraph.this.p.pianoRollGraph.repaint();
                }
            }
        }
        
        public Key getKey(final Point point) {
            for (int i = 0; i < this.keys.size(); ++i) {
                if (((Key)this.keys.get(i)).contains(point)) {
                    return (Key)this.keys.get(i);
                }
            }
            return null;
        }
        
        public Key getKey(final int n) {
            for (int i = 0; i < this.keys.size(); ++i) {
                if (((Key)this.keys.get(i)).kNum == n) {
                    return (Key)this.keys.get(i);
                }
            }
            return null;
        }
        
        public void releaseAllKeys() {
            for (int i = 0; i < this.keys.size(); ++i) {
                ((Key)this.keys.get(i)).off();
            }
        }
        
        public void paint(final Graphics graphics) {
            final Graphics2D graphics2D = (Graphics2D)graphics;
            final Dimension size = ControllerGraph.this.getSize();
            graphics2D.setBackground(Color.lightGray);
            graphics2D.clearRect(0, 0, size.width, size.height);
            graphics2D.setColor(Color.white);
            graphics2D.fillRect(0, 0, 896, 73);
            for (int i = 0; i < this.whiteKeys.size(); ++i) {
                final Key key = this.whiteKeys.get(i);
                if (key.isNoteOn()) {
                    graphics2D.setColor(key.noteColor);
                    graphics2D.fill(key);
                    graphics2D.setColor(Color.black);
                    graphics2D.draw(key);
                }
                else {
                    graphics2D.setColor(Color.gray);
                    graphics2D.draw(key);
                }
            }
            for (int j = 0; j < this.blackKeys.size(); ++j) {
                final Key key2 = this.blackKeys.get(j);
                if (key2.isNoteOn()) {
                    graphics2D.setColor(key2.noteColor);
                    graphics2D.fill(key2);
                    graphics2D.setColor(Color.black);
                    graphics2D.draw(key2);
                }
                else {
                    graphics2D.setColor(Color.black);
                    graphics2D.fill(key2);
                }
            }
        }
    }
}
