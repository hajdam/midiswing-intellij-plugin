import javax.sound.midi.Transmitter;
import java.util.List;
import com.sun.media.sound.SoftSynthesizer;
import javax.swing.UIManager;
import java.util.Locale;
import java.net.URLConnection;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.awt.Component;
import javax.swing.JOptionPane;
import java.lang.reflect.Array;
import javax.sound.midi.SysexMessage;
import javax.sound.midi.Track;
import javax.sound.midi.MetaMessage;
import java.net.URL;
import javax.sound.midi.MidiDevice;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiEvent;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.MidiMessage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import javax.sound.midi.Instrument;
import javax.sound.midi.Soundbank;
import java.util.Vector;
import javax.sound.midi.Receiver;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Sequence;
import java.io.File;
import java.util.prefs.Preferences;
import java.util.ResourceBundle;

// 
// Decompiled by Procyon v0.5.30
// 

public class MidiSwing implements EventListener
{
    public static ResourceBundle resource;
    public static final String version = "0.3.6";
    public Preferences prefs;
    static boolean debug;
    public int index;
    public File file;
    private String fileName;
    protected int midiFileType;
    public boolean emptyDocument;
    public boolean modified;
    private boolean playing;
    private boolean recording;
    private boolean loop;
    protected Sequence sequence;
    protected Sequencer sequencer;
    protected Receiver inputFilter;
    protected Receiver outputFilter;
    protected Vector midiInputs;
    protected Vector midiOutputs;
    public Vector outputForTrack;
    public static InstrumentKit GM_Kit;
    protected static Vector instrumentKitList;
    protected int currentInput;
    private Soundbank soundbank;
    private Instrument[] instruments;
    public int defaultOutputNumber;
    public int javaSynthNumber;
    public int outputShift;
    public int inputShift;
    public MidiWindow midiWindow;
    public int numberOfTracks;
    public int currentTrack;
    public int currentChannel;
    public int numberOfSelectedChannels;
    public Vector trackMainChannelNumber;
    private Note[] noteOnPitch;
    public int signatureNumerator;
    public int signatureDenominator;
    public long noteDuration;
    public boolean beatWhileRecording;
    public boolean magnetiseGrid;
    public Timer guiTimer;
    public Timer seqTimer;
    static int numberOfWindows;
    public Vector lyrics;
    public Vector lyricsInfo;
    public int lyricsTrackNumber;
    public int karaokeSoftTrackNumber;
    public int launch_count;
    public int windowWidth;
    public int windowHeight;
    public int dividerLocation;
    public String selectedFile;
    public String currentDirectory;
    public long time;
    public long previousTime;
    private static boolean[] soundBankLoaded;
    private static Vector soundBankFileList;
    private static Vector soundBankNameList;
    private static Vector soundBankInstrumentKitList;
    
    public MidiSwing(final int index, final File file, final int midiFileType) {
        this.loop = false;
        this.outputShift = 0;
        this.inputShift = 0;
        this.noteOnPitch = new Note[128];
        this.noteDuration = 480L;
        this.time = -1L;
        this.previousTime = -1L;
        this.retrievePreferences();
        ++MidiSwing.numberOfWindows;
        this.index = index;
        this.midiFileType = midiFileType;
        this.signatureNumerator = 4;
        this.signatureDenominator = 4;
        this.setupMidi();
        this.setupGUI();
        this.selectInput(this.currentInput);
        this.loadFile(file);
        if (MidiSwing.debug) {
            System.out.println("Midi File type = " + midiFileType);
        }
        this.midiWindow.setVisible(true);
        this.midiWindow.pianoRoll.updateLengthX(this.getSequenceLength());
        this.midiWindow.pianoRoll.updateScrollBarY();
        if (MidiSwing.debug) {
            System.out.println("Length : " + (int)this.sequence.getTickLength());
        }
        this.guiTimer = new Timer(60, new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                MidiSwing.this.midiWindow.setPlayPosition(MidiSwing.this.getTickPosition(), false);
                if (MidiSwing.this.isPlaying() && MidiSwing.this.getTickPosition() >= MidiSwing.this.getSequenceLength()) {
                    MidiSwing.this.stop();
                    MidiSwing.this.setPlayPosition(MidiSwing.this.sequence.getTickLength(), false);
                }
                if (MidiSwing.this.isPlaying() && MidiSwing.this.isRecording() && MidiSwing.this.getTickPosition() >= MidiSwing.this.getSequenceLength() - 480L) {
                    MidiSwing.this.setEndOfCurrentTrack(MidiSwing.this.getSequenceLength() + 1920L);
                }
            }
        });
        this.beatWhileRecording = false;
        this.seqTimer = new Timer(10, new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                if (MidiSwing.this.isPlaying() && MidiSwing.this.isRecording() && MidiSwing.this.beatWhileRecording) {
                    MidiSwing.this.time = MidiSwing.this.getTickPosition();
                    final Data dataAtTime = MidiSwing.this.midiWindow.pianoRoll.getDataAtTime(7, 0, 0, MidiSwing.this.time);
                    int n = 4;
                    if (dataAtTime != null) {
                        final int[] array = (int[])dataAtTime.getValue();
                        int n2 = MidiSwing.this.getResolution() / (1 << array[1] - 2);
                        n = array[0];
                        if (n2 == 0) {
                            n2 = 480;
                        }
                        if (n == 0) {
                            n = 4;
                        }
                        MidiSwing.this.time = (MidiSwing.this.time - dataAtTime.getTimestamp()) / n2;
                    }
                    else {
                        MidiSwing.this.time /= 480L;
                    }
                    if (MidiSwing.this.time != MidiSwing.this.previousTime) {
                        if (MidiSwing.this.time % n == 0L) {
                            MidiSwing.this.playNoteJava(9, 34, 120);
                        }
                        else {
                            MidiSwing.this.playNoteJava(9, 33, 120);
                        }
                        MidiSwing.this.previousTime = MidiSwing.this.time;
                    }
                }
            }
        });
        if (this.launch_count % 4 == 0) {
            this.checkForUpdates(false);
            this.notifyTranslation();
        }
    }
    
    public int getResolution() {
        if (this.sequence != null) {
            return this.sequence.getResolution();
        }
        return 480;
    }
    
    public long getSequenceLength() {
        long tickLength = 0L;
        if (this.sequence != null) {
            tickLength = this.sequence.getTickLength();
        }
        return tickLength;
    }
    
    public long getTickPosition() {
        return this.sequencer.getTickPosition();
    }
    
    public long getMicrosecondPosition() {
        return this.sequencer.getMicrosecondPosition();
    }
    
    public void setupGUI() {
        this.midiWindow = new MidiWindow(this, "");
        this.updateChannels();
    }
    
    public void setupMidi() {
        this.inputFilter = new Receiver() {
            public void close() {
            }
            
            public void send(final MidiMessage midiMessage, final long n) {
                boolean b = true;
                if (midiMessage instanceof ShortMessage) {
                    final long tickPosition = MidiSwing.this.getTickPosition();
                    switch (((ShortMessage)midiMessage).getCommand()) {
                        case 144: {
                            int data1 = ((ShortMessage)midiMessage).getData1();
                            if (MidiSwing.this.currentChannel != 9) {
                                data1 += MidiSwing.this.inputShift;
                            }
                            final int data2 = ((ShortMessage)midiMessage).getData2();
                            if (data2 != 0) {
                                MidiSwing.this.playNote(MidiSwing.this.currentChannel, MidiSwing.this.getTickPosition(), data1, data2);
                            }
                            else {
                                MidiSwing.this.stopNote(MidiSwing.this.currentChannel, data1, data2);
                                if (!MidiSwing.this.playing) {
                                    MidiSwing.this.setPlayPosition(MidiSwing.this.getTickPosition(), false);
                                }
                            }
                            if (MidiSwing.this.recording) {
                                if (data2 != 0) {
                                    final Note note = new Note(data1, data2, MidiSwing.this.currentChannel, tickPosition, tickPosition + MidiSwing.this.noteDuration, MidiSwing.this.currentTrack, null, null, true, null, MidiSwing.this.midiWindow.pianoRoll);
                                    MidiSwing.this.noteOnPitch[data1] = note;
                                    if (MidiSwing.this.playing) {
                                        MidiSwing.this.midiWindow.pianoRoll.addNoteToSelection(note);
                                    }
                                    else {
                                        MidiSwing.this.midiWindow.pianoRoll.addNote(MidiSwing.this.currentTrack, note);
                                        MidiSwing.this.midiWindow.pianoRoll.emptySelection();
                                        MidiSwing.this.midiWindow.pianoRoll.addNoteToSelection(note);
                                        MidiSwing.this.midiWindow.pianoRoll.pianoRollGraph.repaint();
                                        MidiSwing.this.midiWindow.pianoRoll.alterSelection(0L, 0, 1.0, 1.0);
                                        MidiSwing.this.noteOnPitch[data1] = null;
                                    }
                                }
                                if (data2 == 0 && MidiSwing.this.noteOnPitch[data1] != null) {
                                    MidiSwing.this.noteOnPitch[data1].setEnd(tickPosition);
                                    MidiSwing.this.noteOnPitch[data1].setEndingEvent(new MidiEvent(midiMessage, tickPosition));
                                    MidiSwing.this.midiWindow.pianoRoll.addNote(MidiSwing.this.currentTrack, MidiSwing.this.noteOnPitch[data1]);
                                    MidiSwing.this.noteOnPitch[data1] = null;
                                    MidiSwing.this.midiWindow.pianoRoll.compareThenUpdateLengthX(tickPosition);
                                }
                            }
                            b = false;
                            break;
                        }
                        case 128: {
                            MidiSwing.this.stopNote(MidiSwing.this.currentChannel, ((ShortMessage)midiMessage).getData1(), ((ShortMessage)midiMessage).getData2());
                            if (!MidiSwing.this.playing) {
                                MidiSwing.this.setPlayPosition(MidiSwing.this.getTickPosition(), false);
                            }
                            if (MidiSwing.this.recording && MidiSwing.this.playing) {
                                int data3 = ((ShortMessage)midiMessage).getData1();
                                if (MidiSwing.this.currentChannel != 9) {
                                    data3 += MidiSwing.this.inputShift;
                                }
                                if (MidiSwing.this.noteOnPitch[data3] != null) {
                                    MidiSwing.this.noteOnPitch[data3].setEnd(tickPosition);
                                    MidiSwing.this.noteOnPitch[data3].setEndingEvent(new MidiEvent(midiMessage, tickPosition));
                                    MidiSwing.this.midiWindow.pianoRoll.addNote(MidiSwing.this.currentTrack, MidiSwing.this.noteOnPitch[data3]);
                                    MidiSwing.this.noteOnPitch[data3] = null;
                                    MidiSwing.this.midiWindow.pianoRoll.compareThenUpdateLengthX(tickPosition);
                                }
                            }
                            b = false;
                            break;
                        }
                        case 224: {
                            final int data4 = ((ShortMessage)midiMessage).getData2();
                            if (MidiSwing.this.recording && MidiSwing.this.playing) {
                                final Data data5 = new Data(3, new Integer(data4), MidiSwing.this.currentChannel, tickPosition, MidiSwing.this.currentTrack, null, true, MidiSwing.this.midiWindow.pianoRoll);
                                MidiSwing.this.midiWindow.pianoRoll.addData(data5);
                                MidiSwing.this.midiWindow.pianoRoll.addDataToSelection(data5);
                                break;
                            }
                            break;
                        }
                        case 176: {
                            final int data6 = ((ShortMessage)midiMessage).getData1();
                            final int data7 = ((ShortMessage)midiMessage).getData2();
                            switch (data6) {
                                case 64: {
                                    if (MidiSwing.this.recording && MidiSwing.this.playing) {
                                        final Data data8 = new Data(10, new Integer(data7), MidiSwing.this.currentChannel, tickPosition, MidiSwing.this.currentTrack, null, true, MidiSwing.this.midiWindow.pianoRoll);
                                        MidiSwing.this.midiWindow.pianoRoll.addData(data8);
                                        MidiSwing.this.midiWindow.pianoRoll.addDataToSelection(data8);
                                        break;
                                    }
                                    break;
                                }
                            }
                            break;
                        }
                        case 192: {
                            ((ShortMessage)midiMessage).getData1();
                            break;
                        }
                    }
                }
                if (b) {
                    try {
                        MidiSwing.this.outputFilter.send(midiMessage, n);
                    }
                    catch (Exception ex) {}
                }
            }
        };
        this.outputFilter = new Receiver() {
            public void close() {
            }
            
            public void send(final MidiMessage midiMessage, final long n) {
                boolean b = true;
                int n2 = 0;
                Label_0254: {
                    if (midiMessage instanceof ShortMessage) {
                        n2 = ((ShortMessage)midiMessage).getChannel();
                        final int command = ((ShortMessage)midiMessage).getCommand();
                        switch (command) {
                            case 144: {
                                final int data1 = ((ShortMessage)midiMessage).getData1();
                                final int data2 = ((ShortMessage)midiMessage).getData2();
                                if (n2 != 9) {
                                    try {
                                        ((ShortMessage)midiMessage).setMessage(command, n2, data1 + MidiSwing.this.outputShift, data2);
                                    }
                                    catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                    break;
                                }
                                break;
                            }
                            case 128: {
                                final int data3 = ((ShortMessage)midiMessage).getData1();
                                final int data4 = ((ShortMessage)midiMessage).getData2();
                                if (n2 != 9) {
                                    try {
                                        ((ShortMessage)midiMessage).setMessage(command, n2, data3 + MidiSwing.this.outputShift, data4);
                                    }
                                    catch (Exception ex2) {
                                        ex2.printStackTrace();
                                    }
                                    break;
                                }
                                break;
                            }
                            case 176: {
                                final int data5 = ((ShortMessage)midiMessage).getData1();
                                ((ShortMessage)midiMessage).getData2();
                                switch (data5) {
                                    case 32: {
                                        b = false;
                                        break Label_0254;
                                    }
                                    case 64: {
                                        b = true;
                                        n2 = MidiSwing.this.currentChannel;
                                        break Label_0254;
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
                if (b && MidiSwing.this.isEnabledChannel(n2)) {
                    try {
                        MidiSwing.this.getOutputForTrack(MidiSwing.this.trackWhoseMainChannelIs(n2)).getReceiver().send(midiMessage, n);
                    }
                    catch (Exception ex3) {}
                }
            }
        };
        if (MidiSwing.debug) {
            System.out.println("");
        }
        if (MidiSwing.debug) {
            System.out.println("Scanning the available devices");
        }
        try {
            this.midiOutputs = new Vector();
            this.midiInputs = new Vector();
            MidiSwing.instrumentKitList = new Vector();
            for (int i = 0; i < MidiSystem.getMidiDeviceInfo().length; ++i) {
                final MidiDevice midiDevice = MidiSystem.getMidiDevice(MidiSystem.getMidiDeviceInfo()[i]);
                final String name = MidiSystem.getMidiDeviceInfo()[i].getName();
                final String vendor = MidiSystem.getMidiDeviceInfo()[i].getVendor();
                final String description = MidiSystem.getMidiDeviceInfo()[i].getDescription();
                if (midiDevice.getMaxReceivers() != 0 && (name != "Real Time Sequencer" || vendor != "Sun Microsystems")) {
                    if (MidiSwing.debug) {
                        System.out.println(i + ") " + name + " [OUTPUT]");
                    }
                    if (MidiSwing.debug) {
                        System.out.println("   " + vendor);
                    }
                    if (MidiSwing.debug) {
                        System.out.println("   " + description);
                    }
                    this.midiOutputs.add(midiDevice);
                    MidiSwing.instrumentKitList.add(MidiSwing.GM_Kit);
                    if (name == "Gervill") {
                        try {
                            try {
                                MidiSwing.soundBankFileList = new Vector();
                                MidiSwing.soundBankNameList = new Vector();
                                MidiSwing.soundBankInstrumentKitList = new Vector();
                                findSoundBanks(System.getProperty("user.home"));
                                findSoundBanks(System.getProperty("user.home") + "/Soundbanks");
                                findSoundBanks(System.getProperty("user.home") + "/Documents/Soundbanks");
                                findSoundBanks(System.getProperty("user.home") + "/Library/Audio/Sounds/Banks");
                                final int size = MidiSwing.soundBankFileList.size();
                                MidiSwing.soundBankLoaded = new boolean[size];
                                for (int j = 0; j < size; ++j) {
                                    final String s = MidiSwing.soundBankFileList.get(j);
                                    final String s2 = MidiSwing.soundBankNameList.get(j);
                                    if (MidiSwing.debug) {
                                        System.out.println(" --> " + s);
                                    }
                                    this.midiOutputs.add(new SoundbankDevice(s, s2));
                                    MidiSwing.instrumentKitList.add(MidiSwing.soundBankInstrumentKitList.get(j));
                                    MidiSwing.soundBankLoaded[j] = false;
                                }
                            }
                            catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        catch (Exception ex3) {
                            if (MidiSwing.debug) {
                                System.out.println("   Sound banks could not be loaded!");
                            }
                        }
                    }
                    if (name == "Java Sound Synthesizer") {
                        this.javaSynthNumber = this.midiOutputs.size() - 1;
                        try {
                            midiDevice.open();
                            this.soundbank = ((Synthesizer)midiDevice).getDefaultSoundbank();
                            System.out.println("First instrument " + ((Synthesizer)midiDevice).getLoadedInstruments()[1].getName());
                        }
                        catch (Exception ex4) {
                            if (MidiSwing.debug) {
                                System.out.println("   Default sound bank could not be loaded!");
                            }
                        }
                        if (this.soundbank != null) {
                            if (MidiSwing.debug) {
                                System.out.println("   Default sound bank " + this.soundbank.getName() + " " + this.soundbank.getVersion() + " (" + this.soundbank.getVendor() + ") loaded");
                            }
                        }
                        else {
                            if (MidiSwing.debug) {
                                System.out.println("   Trying the built-in sound bank...");
                            }
                            final URL resource = this.getClass().getClassLoader().getResource("banks/soundbank-min.gm");
                            if (resource != null) {
                                if (MidiSwing.debug) {
                                    System.out.println("   Sound bank found");
                                }
                                try {
                                    this.soundbank = MidiSystem.getSoundbank(resource);
                                    ((Synthesizer)midiDevice).loadAllInstruments(this.soundbank);
                                    if (MidiSwing.debug) {
                                        System.out.println("   Sound bank loaded");
                                    }
                                }
                                catch (Exception ex5) {
                                    if (MidiSwing.debug) {
                                        System.out.println("   Built-in sound bank could not be loaded!");
                                    }
                                }
                            }
                            else if (MidiSwing.debug) {
                                System.out.println("   Built-in sound bank could not be found! There's something rotten in the state of Denmark.");
                            }
                        }
                    }
                }
                if (midiDevice.getMaxTransmitters() != 0 && (name != "Real Time Sequencer" || vendor != "Sun Microsystems")) {
                    if (MidiSwing.debug) {
                        System.out.println(i + ") " + name + " [INPUT]");
                    }
                    if (MidiSwing.debug) {
                        System.out.println("   " + vendor);
                    }
                    if (MidiSwing.debug) {
                        System.out.println("   " + description);
                    }
                    this.midiInputs.add(midiDevice);
                }
            }
            this.defaultOutputNumber = this.javaSynthNumber;
            this.currentInput = 0;
            this.outputForTrack = new Vector();
            (this.sequencer = MidiSystem.getSequencer(false)).open();
            this.sequencer.getTransmitter().setReceiver(this.outputFilter);
        }
        catch (Exception ex2) {
            ex2.printStackTrace();
            return;
        }
        if (MidiSwing.debug) {
            System.out.println("Setting up midi done.");
        }
    }
    
    public void closeOpenNotes() {
        final long tickPosition = this.getTickPosition();
        for (int i = 0; i < 128; ++i) {
            if (this.noteOnPitch[i] != null) {
                this.noteOnPitch[i].setEnd(tickPosition);
                try {
                    final ShortMessage shortMessage = new ShortMessage();
                    shortMessage.setMessage(128, this.currentChannel, i, 0);
                    this.noteOnPitch[i].setEndingEvent(new MidiEvent(shortMessage, tickPosition));
                }
                catch (Exception ex) {}
                this.midiWindow.pianoRoll.addNote(this.currentTrack, this.noteOnPitch[i]);
                this.noteOnPitch[i] = null;
            }
        }
    }
    
    public int getNumberOfOutputs() {
        return this.midiOutputs.size();
    }
    
    public String getNameOfOutput(final int n) {
        final MidiDevice.Info deviceInfo = this.getOutput(n).getDeviceInfo();
        String s = deviceInfo.getName() + " ";
        if (!deviceInfo.getVendor().equals("")) {
            s = s + "(" + deviceInfo.getVendor() + ") ";
        }
        return s + deviceInfo.getVersion();
    }
    
    protected MidiDevice getOutput(final int n) {
        MidiDevice midiDevice = null;
        if (n < this.getNumberOfOutputs()) {
            midiDevice = this.midiOutputs.get(n);
        }
        return midiDevice;
    }
    
    public MidiDevice getOutputForTrack(final int n) {
        return this.getOutput(this.outputForTrack.get(n));
    }
    
    public void setOutputForAllTracks(final int selectedIndex) {
        for (int i = 0; i < this.numberOfTracks; ++i) {
            this.setOutputForTrack(selectedIndex, i, true);
        }
        this.midiWindow.outputChooser.setSelectedIndex(selectedIndex);
    }
    
    public void setOutputForTrack(final int n, final int n2, final boolean b) {
        if (n2 >= this.outputForTrack.size()) {
            this.outputForTrack.add(new Integer(this.defaultOutputNumber));
            this.setOutputForTrack(n, n2, b);
        }
        else {
            final MidiDevice output = this.getOutput(n);
            try {
                output.open();
                final ShortMessage shortMessage = new ShortMessage();
                shortMessage.setMessage(176, 122, 55);
                output.getReceiver().send(shortMessage, -1L);
            }
            catch (Exception ex) {
                ex.printStackTrace();
                return;
            }
            this.outputForTrack.setElementAt(new Integer(n), n2);
            if (b) {
                this.midiWindow.pianoRoll.controllerGraph.repaint();
                int i = 0;
                int n3 = 0;
                while (i == 0) {
                    final MidiEvent value = this.getTrack(n2).get(n3);
                    if (value.getMessage() instanceof MetaMessage && ((MetaMessage)value.getMessage()).getType() == 4) {
                        this.getTrack(n2).remove(value);
                    }
                    ++n3;
                    if (value.getTick() > 0L || n3 >= this.getTrack(n2).size()) {
                        i = 1;
                    }
                }
                final String nameOfOutput = this.getNameOfOutput(n);
                if (!nameOfOutput.equals("")) {
                    final byte[] bytes = nameOfOutput.getBytes();
                    final MetaMessage metaMessage = new MetaMessage();
                    try {
                        metaMessage.setMessage(4, bytes, bytes.length);
                        this.getTrack(n2).add(new MidiEvent(metaMessage, 0L));
                    }
                    catch (Exception ex2) {
                        ex2.printStackTrace();
                    }
                    this.modification();
                }
            }
        }
    }
    
    public void indicateOutput(final int n, final String s) {
        int n2 = -1;
        for (int i = 0; i < this.getNumberOfOutputs(); ++i) {
            if (this.getNameOfOutput(i).equals(s)) {
                n2 = i;
            }
        }
        if (n2 != -1) {
            this.setOutputForTrack(n2, n, false);
        }
    }
    
    public InstrumentKit getKitForChannel(final int n) {
        InstrumentKit gm_Kit = MidiSwing.GM_Kit;
        final int trackWhoseMainChannelIs = this.trackWhoseMainChannelIs(n);
        if (trackWhoseMainChannelIs != -1) {
            gm_Kit = (InstrumentKit)MidiSwing.instrumentKitList.get((int)this.outputForTrack.get(trackWhoseMainChannelIs));
        }
        return gm_Kit;
    }
    
    public int getNumberOfInputs() {
        return this.midiInputs.size();
    }
    
    public String getNameOfInput(final int n) {
        final MidiDevice.Info deviceInfo = this.getInput(n).getDeviceInfo();
        return deviceInfo.getName() + " (" + deviceInfo.getVendor() + ") " + deviceInfo.getVersion();
    }
    
    private MidiDevice getInput(final int n) {
        return this.midiInputs.get(n);
    }
    
    public void selectInput(final int currentInput) {
        if (this.getNumberOfInputs() != 0) {
            try {
                final MidiDevice input = this.getInput(this.currentInput);
                if (input != null && input.isOpen()) {
                    input.close();
                }
                this.getInput(currentInput).open();
                this.getInput(currentInput).getTransmitter().setReceiver(this.inputFilter);
            }
            catch (Exception ex) {
                ex.printStackTrace();
                return;
            }
            this.currentInput = currentInput;
        }
    }
    
    public MidiEvent getEvent(final int n, final int n2) {
        MidiEvent value = null;
        if (n < this.sequence.getTracks().length) {
            final Track track = this.sequence.getTracks()[n];
            if (n2 < track.size()) {
                value = track.get(n2);
            }
        }
        return value;
    }
    
    public String[] getEventInfo(final MidiEvent midiEvent) {
        final String[] array = { "", "", "", "", "" };
        if (midiEvent != null) {
            array[0] = String.valueOf(midiEvent.getTick());
            final String upperCase = Integer.toHexString(midiEvent.getMessage().getStatus()).toUpperCase();
            final char char1 = upperCase.charAt(0);
            final int intValue = Integer.valueOf(String.valueOf(upperCase.charAt(1)), 16);
            final String value = String.valueOf(intValue + 1);
            switch (char1) {
                case 56: {
                    array[1] = MidiSwing.resource.getString("NOTE_OFF");
                    array[2] = value;
                    array[3] = String.valueOf(((ShortMessage)midiEvent.getMessage()).getData1());
                    array[4] = MidiSwing.resource.getString("NOTE_VELOCITY_LABEL") + String.valueOf(((ShortMessage)midiEvent.getMessage()).getData2());
                    break;
                }
                case 57: {
                    array[1] = MidiSwing.resource.getString("NOTE_ON");
                    array[2] = value;
                    array[3] = String.valueOf(((ShortMessage)midiEvent.getMessage()).getData1());
                    array[4] = MidiSwing.resource.getString("NOTE_VELOCITY_LABEL") + String.valueOf(((ShortMessage)midiEvent.getMessage()).getData2());
                    break;
                }
                case 65: {
                    array[1] = MidiSwing.resource.getString("AFTERTOUCH");
                    array[2] = value;
                    array[3] = String.valueOf(((ShortMessage)midiEvent.getMessage()).getData1());
                    array[4] = "Pressure: " + String.valueOf(((ShortMessage)midiEvent.getMessage()).getData2());
                    break;
                }
                case 66: {
                    array[1] = MidiSwing.resource.getString("CONTROLLER");
                    array[2] = value;
                    array[3] = MidiConstants.getControllerName(((ShortMessage)midiEvent.getMessage()).getData1());
                    array[4] = String.valueOf(((ShortMessage)midiEvent.getMessage()).getData2());
                    break;
                }
                case 67: {
                    array[1] = MidiSwing.resource.getString("PROGRAM_CHANGE");
                    array[2] = value;
                    array[3] = "-";
                    array[4] = MidiConstants.getGMinstrumentName(((ShortMessage)midiEvent.getMessage()).getData1());
                    break;
                }
                case 68: {
                    array[1] = MidiSwing.resource.getString("CHANNEL_PRESSURE");
                    array[2] = value;
                    array[3] = "-";
                    array[4] = String.valueOf(((ShortMessage)midiEvent.getMessage()).getData1());
                    break;
                }
                case 69: {
                    array[1] = MidiSwing.resource.getString("PITCH_BEND");
                    array[2] = value;
                    array[3] = "-";
                    array[4] = String.valueOf(((ShortMessage)midiEvent.getMessage()).getData2());
                    break;
                }
                case 70: {
                    if (intValue < 15) {
                        array[1] = MidiSwing.resource.getString("SYSTEM_EXCLUSIVE") + " " + intValue;
                        final byte[] data = ((SysexMessage)midiEvent.getMessage()).getData();
                        String string = "";
                        for (int i = 0; i < Array.getLength(data); ++i) {
                            string += (char)data[i];
                        }
                        array[3] = (array[2] = "-");
                        array[4] = string;
                        break;
                    }
                    array[1] = MidiSwing.resource.getString("META_EVENT");
                    final int type = ((MetaMessage)midiEvent.getMessage()).getType();
                    final byte[] data2 = ((MetaMessage)midiEvent.getMessage()).getData();
                    String string2 = "";
                    for (int j = 0; j < Array.getLength(data2); ++j) {
                        string2 += (char)data2[j];
                    }
                    array[2] = "-";
                    array[3] = MidiSwing.resource.getString("UNKNOWN");
                    array[4] = "-";
                    switch (type) {
                        case 0: {
                            array[3] = MidiSwing.resource.getString("SEQUENCE_NUMBER");
                            break;
                        }
                        case 1: {
                            array[3] = MidiSwing.resource.getString("TEXT");
                            array[4] = string2;
                            break;
                        }
                        case 2: {
                            array[3] = MidiSwing.resource.getString("COPYRIGHT");
                            array[4] = string2;
                            break;
                        }
                        case 3: {
                            array[3] = MidiSwing.resource.getString("SEQUENCE_TRACK_NAME");
                            array[4] = string2;
                            break;
                        }
                        case 4: {
                            array[3] = MidiSwing.resource.getString("INSTRUMENT");
                            array[4] = string2;
                            break;
                        }
                        case 5: {
                            array[3] = MidiSwing.resource.getString("LYRIC");
                            array[4] = string2;
                            break;
                        }
                        case 6: {
                            array[3] = MidiSwing.resource.getString("MARKER");
                            array[4] = string2;
                            break;
                        }
                        case 7: {
                            array[3] = MidiSwing.resource.getString("CUE_POINT");
                            array[4] = string2;
                            break;
                        }
                        case 8: {
                            array[3] = MidiSwing.resource.getString("PROGRAM_PACTH_NAME");
                            array[4] = string2;
                            break;
                        }
                        case 9: {
                            array[3] = MidiSwing.resource.getString("DEVICE_PORT_NAME");
                            array[4] = string2;
                            break;
                        }
                        case 47: {
                            array[3] = MidiSwing.resource.getString("END_OF_TRACK");
                            break;
                        }
                        case 81: {
                            array[3] = MidiSwing.resource.getString("TEMPO");
                            final int n = 65536 * (data2[0] & 0xFF) + 256 * (data2[1] & 0xFF) + (data2[2] & 0xFF);
                            array[4] = String.valueOf(n) + " = " + String.valueOf(60000000 / n) + "bpm";
                            break;
                        }
                        case 84: {
                            array[3] = MidiSwing.resource.getString("SMPTE_OFFSET");
                            break;
                        }
                        case 88: {
                            array[3] = MidiSwing.resource.getString("TIME_SIGNATURE");
                            array[4] = "" + (data2[0] & 0xFF) + "/" + (1 << (data2[1] & 0xFF)) + "  - " + (data2[2] & 0xFF) + " " + (data2[3] & 0xFF);
                            break;
                        }
                        case 89: {
                            array[3] = MidiSwing.resource.getString("KEY_SIGNATURE");
                            if (data2[0] == 0) {
                                array[4] = "C ";
                            }
                            else {
                                array[4] = "" + Math.abs(data2[0]);
                                if (data2[0] < 0) {
                                    array[4] += MidiSwing.resource.getString("FLATS");
                                }
                                else {
                                    array[4] += MidiSwing.resource.getString("SHARPS");
                                }
                            }
                            if ((data2[1] & 0xFF) == 0x0) {
                                array[4] += MidiSwing.resource.getString("MAJOR");
                                break;
                            }
                            array[4] += MidiSwing.resource.getString("MINOR");
                            break;
                        }
                        case 127: {
                            array[3] = MidiSwing.resource.getString("PROPRIETARY_EVENT");
                            array[4] = string2;
                            break;
                        }
                    }
                    break;
                }
            }
        }
        return array;
    }
    
    public void midiReadEvents() {
        final Vector[][] array = new Vector[16][128];
        final PianoRoll pianoRoll = this.midiWindow.pianoRoll;
        this.initializeLyrics();
        if (MidiSwing.debug) {
            System.out.println("DivisionType: " + this.sequence.getDivisionType());
        }
        if (MidiSwing.debug) {
            System.out.println("Resolution: " + this.sequence.getResolution());
        }
        final Track[] tracks = this.sequence.getTracks();
        this.initializeTracks(Array.getLength(tracks));
        this.numberOfSelectedChannels = 0;
        this.currentChannel = -1;
        for (int i = 0; i < Array.getLength(tracks); ++i) {
            int n = -1;
            for (int j = 0; j < 16; ++j) {
                for (int k = 0; k < 128; ++k) {
                    array[j][k] = new Vector();
                }
            }
            this.addNewTrack(-1);
            for (int l = 0; l < Math.min(tracks[i].size(), 100000); ++l) {
                final MidiEvent value = tracks[i].get(l);
                long tick = value.getTick();
                final String upperCase = Integer.toHexString(value.getMessage().getStatus()).toUpperCase();
                final char char1 = upperCase.charAt(0);
                final int intValue = Integer.valueOf(String.valueOf(upperCase.charAt(1)), 16);
                if (value.getMessage() instanceof ShortMessage) {
                    final int channel = ((ShortMessage)value.getMessage()).getChannel();
                    this.enableChannel(channel);
                    this.setMainChannelForTrack(i, channel);
                }
                switch (char1) {
                    case 56: {
                        final int data1 = ((ShortMessage)value.getMessage()).getData1();
                        ((ShortMessage)value.getMessage()).getData2();
                        if (!array[intValue][data1].isEmpty()) {
                            final int intValue2 = array[intValue][data1].firstElement();
                            if (array[intValue][data1].size() > 1) {
                                tick = pianoRoll.getNote(i, (int)array[intValue][data1].get(1)).start - 1L;
                            }
                            pianoRoll.getNote(i, intValue2).setEnd(tick);
                            pianoRoll.getNote(i, intValue2).setEndingEvent(value);
                            array[intValue][data1].remove(0);
                            pianoRoll.compareThenUpdateLengthX(tick);
                            break;
                        }
                        break;
                    }
                    case 57: {
                        if (this.currentChannel == -1) {
                            this.currentChannel = intValue;
                        }
                        final int data2 = ((ShortMessage)value.getMessage()).getData1();
                        final int data3 = ((ShortMessage)value.getMessage()).getData2();
                        if (data3 != 0) {
                            ++n;
                            pianoRoll.addNote(i, new Note(data2, data3, intValue, tick, tick + 200L, i, value, null, false, null, pianoRoll));
                            array[intValue][data2].add(new Integer(n));
                            break;
                        }
                        if (!array[intValue][data2].isEmpty()) {
                            final int intValue3 = array[intValue][data2].firstElement();
                            if (array[intValue][data2].size() > 1) {
                                tick = pianoRoll.getNote(i, (int)array[intValue][data2].get(1)).start - 1L;
                            }
                            pianoRoll.getNote(i, intValue3).setEnd(tick);
                            pianoRoll.getNote(i, intValue3).setEndingEvent(value);
                            array[intValue][data2].remove(0);
                            pianoRoll.compareThenUpdateLengthX(tick);
                            break;
                        }
                        break;
                    }
                    case 66: {
                        final int data4 = ((ShortMessage)value.getMessage()).getData1();
                        final int data5 = ((ShortMessage)value.getMessage()).getData2();
                        switch (data4) {
                            case 10: {
                                pianoRoll.addData(i, intValue, 4, new Data(4, new Integer(data5), intValue, tick, i, value, false, pianoRoll));
                                break;
                            }
                            case 7: {
                                pianoRoll.addData(i, intValue, 2, new Data(2, new Integer(data5), intValue, tick, i, value, false, pianoRoll));
                                break;
                            }
                            case 91: {
                                pianoRoll.addData(i, intValue, 5, new Data(5, new Integer(data5), intValue, tick, i, value, false, pianoRoll));
                                break;
                            }
                            case 64: {
                                pianoRoll.addData(i, intValue, 10, new Data(10, new Integer(data5), intValue, tick, i, value, false, pianoRoll));
                                break;
                            }
                        }
                        break;
                    }
                    case 67: {
                        final int data6 = ((ShortMessage)value.getMessage()).getData1();
                        if (intValue == 9) {
                            pianoRoll.addProgram(i, intValue, new Program(data6, 128, intValue, tick, i, value, null, false, pianoRoll));
                            break;
                        }
                        pianoRoll.addProgram(i, intValue, new Program(data6, -1, intValue, tick, i, value, null, false, pianoRoll));
                        break;
                    }
                    case 69: {
                        pianoRoll.addData(i, intValue, 3, new Data(3, new Integer(((ShortMessage)value.getMessage()).getData2()), intValue, tick, i, value, false, pianoRoll));
                        break;
                    }
                    case 70: {
                        if (intValue < 15) {
                            break;
                        }
                        final int type = ((MetaMessage)value.getMessage()).getType();
                        final byte[] data7 = ((MetaMessage)value.getMessage()).getData();
                        String s = "";
                        switch (type) {
                            case 1: {
                                for (int n2 = 0; n2 < Array.getLength(data7); ++n2) {
                                    s += (char)data7[n2];
                                }
                                if (s.equals("@KMIDI KARAOKE FILE")) {
                                    this.karaokeSoftTrackNumber = i;
                                    break;
                                }
                                if (this.karaokeSoftTrackNumber == -1) {
                                    break;
                                }
                                if (this.lyricsTrackNumber == -1 && i != this.karaokeSoftTrackNumber) {
                                    this.lyricsTrackNumber = i;
                                }
                                if (s.length() <= 0 || this.lyricsTrackNumber == -1) {
                                    break;
                                }
                                if (s.charAt(0) == '@') {
                                    this.addLyricsInfo(this.lyricsTrackNumber, s, value);
                                    break;
                                }
                                this.addLyric(this.lyricsTrackNumber, s, value);
                                break;
                            }
                            case 3: {
                                for (int n3 = 0; n3 < Array.getLength(data7); ++n3) {
                                    s += (char)data7[n3];
                                }
                                this.midiWindow.trackChooser.removeItemAt(i);
                                this.midiWindow.trackChooser.addItem(s);
                                break;
                            }
                            case 4: {
                                for (int n4 = 0; n4 < Array.getLength(data7); ++n4) {
                                    s += (char)data7[n4];
                                }
                                this.indicateOutput(i, s);
                            }
                            case 5: {}
                            case 6: {}
                            case 7: {}
                            case 8: {}
                            case 9: {}
                            case 81: {
                                pianoRoll.addData(i, 0, 6, new Data(6, new Integer(65536 * (data7[0] & 0xFF) + 256 * (data7[1] & 0xFF) + (data7[2] & 0xFF)), 0, tick, i, value, false, pianoRoll));
                            }
                            case 88: {
                                this.signatureNumerator = (data7[0] & 0xFF);
                                this.signatureDenominator = 1 << (data7[1] & 0xFF);
                                pianoRoll.addData(i, 0, 7, new Data(7, new int[] { data7[0] & 0xFF, data7[1] & 0xFF, data7[2] & 0xFF, data7[3] & 0xFF }, 0, tick, i, value, false, pianoRoll));
                            }
                            case 89: {}
                        }
                        break;
                    }
                }
            }
        }
        if (this.currentTrack == -1) {
            this.currentTrack = 0;
        }
        if (this.currentChannel == -1) {
            this.currentChannel = 0;
        }
        if (this.lyrics.size() > 0) {
            this.midiWindow.pianoRoll.assignLyricsToTrack(-1);
        }
        if (this.lyricsInfo.size() > 0) {
            this.assignLyricsInfo();
        }
        this.updateChannels();
        pianoRoll.pianoRollGraph.repaint();
    }
    
    public void updateSequence() {
        for (int i = 0; i < 16; ++i) {}
        try {
            this.sequencer.setSequence(this.sequence);
        }
        catch (Exception ex) {
            System.out.println("ERREUR !");
            ex.printStackTrace();
        }
        for (int j = 0; j < 16; ++j) {}
        this.setPlayPosition(this.midiWindow.pianoRoll.playPosition, false);
        this.midiWindow.pianoRoll.update(this.getCurrentTrack().ticks());
        this.midiWindow.midiEventTable.update();
    }
    
    public void setEndOfCurrentTrack(long max) {
        try {
            if (this.getCurrentTrack() != null) {
                final int n = this.getCurrentTrack().size() - 1;
                if (n > -1) {
                    final MidiEvent value = this.getCurrentTrack().get(n);
                    if (n > 0) {
                        max = Math.max(max, this.getCurrentTrack().get(n - 1).getTick());
                    }
                    value.setTick(max);
                    this.midiWindow.pianoRoll.update(max);
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void convertToSMF0() {
        if (this.midiFileType == 1) {
            try {
                final Sequence sequence = new Sequence(this.sequence.getDivisionType(), this.sequence.getResolution(), 0);
                sequence.createTrack();
                final Track[] tracks = this.sequence.getTracks();
                for (int i = 0; i < Array.getLength(tracks); ++i) {
                    for (int j = 0; j < Math.min(tracks[i].size(), 100000); ++j) {
                        sequence.getTracks()[0].add(tracks[i].get(j));
                    }
                }
                this.sequence = sequence;
                this.midiFileType = 0;
                this.readSequence();
                this.modification();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public void convertToSMF1() {
        if (this.midiFileType == 0) {
            try {
                final Sequence sequence = new Sequence(this.sequence.getDivisionType(), this.sequence.getResolution(), 1);
                final Track[] tracks = this.sequence.getTracks();
                int n = 0;
                final int[] array = new int[17];
                for (int i = 0; i <= 16; ++i) {
                    array[i] = -1;
                }
                for (int j = 0; j < Array.getLength(tracks); ++j) {
                    for (int k = 0; k < Math.min(tracks[j].size(), 100000); ++k) {
                        final MidiEvent value = tracks[j].get(k);
                        final MidiMessage message = value.getMessage();
                        value.getTick();
                        int channel;
                        if (message instanceof ShortMessage) {
                            channel = ((ShortMessage)message).getChannel();
                        }
                        else {
                            channel = -1;
                        }
                        if (array[channel + 1] == -1) {
                            sequence.createTrack();
                            array[channel + 1] = n;
                            ++n;
                        }
                        sequence.getTracks()[array[channel + 1]].add(value);
                    }
                }
                this.sequence = sequence;
                this.midiFileType = 1;
                this.readSequence();
                this.modification();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
    
    public void modification() {
        this.updateSequence();
        this.midiWindow.pianoRoll.updateLengthX(this.getSequenceLength());
        this.midiWindow.setTitle("*" + this.fileName);
        this.modified = true;
        if (this.emptyDocument) {
            this.emptyDocument = false;
        }
    }
    
    public void writeFile() {
        this.writeFile(this.file);
    }
    
    public void writeFile(final File file) {
        if (file != null) {
            try {
                MidiSystem.write(this.sequence, this.midiFileType, file);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            this.setFile(file);
        }
        else {
            System.out.println("Erreur : fichier vide");
        }
    }
    
    public void setFile(final File file) {
        this.file = file;
        if (file == null) {
            this.fileName = MidiSwing.resource.getString("UNTITLED.MID");
            this.emptyDocument = true;
        }
        else {
            if (MidiSwing.debug) {
                System.out.println(file.getPath());
            }
            if (file.exists()) {
                this.fileName = file.getName();
                this.emptyDocument = false;
            }
            else {
                this.fileName = MidiSwing.resource.getString("UNTITLED.MID");
                this.emptyDocument = true;
            }
        }
        this.midiWindow.setTitle(this.fileName);
        this.modified = false;
    }
    
    public void loadFile(final String s) {
        this.loadFile(new File(s));
    }
    
    public void loadFile(final File file) {
        this.midiWindow.pianoRoll.selectionStart = 0L;
        this.midiWindow.pianoRoll.selectionEnd = 0L;
        this.midiWindow.pianoRoll.selectionStart0 = 0L;
        this.midiWindow.pianoRoll.selectionEnd0 = 0L;
        this.setFile(file);
        try {
            if (!this.emptyDocument) {
                this.sequence = MidiSystem.getSequence(file);
                this.midiFileType = MidiSystem.getMidiFileFormat(file).getType();
            }
            else {
                switch (this.midiFileType) {
                    case 0: {
                        if (MidiSwing.debug) {
                            System.out.println("Creating new SMF0 file");
                        }
                        this.sequence = new Sequence(0.0f, 480, 1);
                        break;
                    }
                    case 1: {
                        if (MidiSwing.debug) {
                            System.out.println("Creating new SMF1 file");
                        }
                        this.sequence = new Sequence(0.0f, 480, 1);
                        break;
                    }
                }
                this.setEndOfCurrentTrack(7680L);
            }
            this.readSequence();
            if (this.emptyDocument) {
                switch (this.midiFileType) {
                    case 0: {
                        this.setMainChannelForTrack(0, 0);
                        break;
                    }
                    case 1: {
                        this.createTrackAndSelectIt(0);
                        break;
                    }
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void readSequence() {
        if (MidiSwing.debug) {
            System.out.println("This is a SMF" + this.midiFileType + " file");
        }
        this.midiWindow.setMidiFileType(this.midiFileType);
        this.signatureNumerator = 4;
        this.signatureDenominator = 4;
        this.trackMainChannelNumber = new Vector();
        this.midiWindow.pianoRoll.updateLengthX(0L);
        this.midiReadEvents();
        this.updateSequence();
        this.fixTempo();
        if (this.emptyDocument) {
            this.createdWithMidiSwing();
        }
        this.rewind();
        if (this.midiFileType == 1) {
            if (this.getNumberOfTracks() > 1) {
                this.selectTrack(1);
            }
            else if (MidiSwing.debug) {
                System.out.println("* Type 1 midifile with only one track *");
            }
        }
        if (this.emptyDocument) {
            this.setEndOfCurrentTrack(7680L);
        }
        this.midiWindow.pianoRoll.emptyBackUp();
    }
    
    public long getTempo() {
        final Data dataAtTime = this.midiWindow.pianoRoll.getDataAtTime(6, 0, 0, this.getTickPosition());
        long longValue = -1L;
        if (dataAtTime != null) {
            longValue = (long)dataAtTime.getValue();
        }
        return longValue;
    }
    
    public void fixTempo() {
        final int n = 0;
        if (MidiSwing.debug) {
            System.out.println("Number of tracks " + this.numberOfTracks);
        }
        boolean b = false;
        if (this.getTrack(n).size() != 0) {
            int i = 0;
            b = false;
            int n2 = 0;
            while (i == 0) {
                final MidiEvent value = this.getTrack(n).get(n2);
                if (MidiSwing.debug) {
                    System.out.println("track " + n + "  - i = " + n2);
                }
                if (value.getMessage().getStatus() == 255) {
                    if (MidiSwing.debug) {
                        System.out.println("type = " + ((MetaMessage)value.getMessage()).getType());
                    }
                    if (((MetaMessage)value.getMessage()).getType() == 81) {
                        b = true;
                    }
                }
                ++n2;
                if (value.getTick() > 0L || n2 >= this.getTrack(n).size()) {
                    i = 1;
                }
            }
        }
        if (!b) {
            if (MidiSwing.debug) {
                System.out.println("* No tempo found *");
            }
            final Data data = new Data(6, new Integer(500000), 0, 0L, 0, null, false, this.midiWindow.pianoRoll);
            this.midiWindow.pianoRoll.insertData(0, 0, 6, data);
            this.midiWindow.pianoRoll.alterData(data);
        }
        int j = 0;
        boolean b2 = false;
        int n3 = 0;
        if (this.getTrack(n).size() != 0) {
            while (j == 0) {
                final MidiEvent value2 = this.getTrack(n).get(n3);
                if (value2.getMessage() instanceof MetaMessage && ((MetaMessage)value2.getMessage()).getType() == 88) {
                    b2 = true;
                }
                ++n3;
                if (value2.getTick() > 0L || n3 >= this.getTrack(n).size()) {
                    j = 1;
                }
            }
        }
        if (!b2) {
            if (MidiSwing.debug) {
                System.out.println("* No time signature found *");
            }
            this.midiWindow.pianoRoll.insertData(n, 0, 7, new Data(7, new int[] { 4, 2, 8, 8 }, 0, 0L, n, null, false, this.midiWindow.pianoRoll));
        }
    }
    
    public void createdWithMidiSwing() {
        final MetaMessage metaMessage = new MetaMessage();
        final byte[] bytes = new String("created with MidiSwing").getBytes();
        try {
            metaMessage.setMessage(1, bytes, bytes.length);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        this.getTrack(0).add(new MidiEvent(metaMessage, 0L));
    }
    
    public void setPlayPosition(final long tickPosition, final boolean b) {
        this.midiWindow.setPlayPosition(tickPosition, b);
        this.sequencer.setTickPosition(tickPosition);
    }
    
    public void beatWhileRecording() {
        if (this.beatWhileRecording) {
            this.beatWhileRecording = false;
        }
        else {
            this.beatWhileRecording = true;
        }
    }
    
    public void magnetiseGrid() {
        if (this.magnetiseGrid) {
            this.magnetiseGrid = false;
        }
        else {
            this.magnetiseGrid = true;
        }
    }
    
    public void record() {
        if (!this.recording) {
            this.recording = true;
            this.time = this.getTickPosition() / 480L;
            this.previousTime = this.time;
            if (this.playing) {
                this.midiWindow.pianoRoll.emptySelection();
            }
        }
        else {
            this.recording = false;
            if (this.playing) {
                this.closeOpenNotes();
                this.midiWindow.pianoRoll.pianoRollGraph.repaint();
                this.midiWindow.pianoRoll.alterSelection(0L, 0, 1.0, 1.0);
            }
        }
        this.midiWindow.record(this.recording);
    }
    
    public void loop() {
        if (!this.loop) {
            this.loop = true;
        }
        else {
            this.loop = false;
        }
        this.midiWindow.loop(this.loop);
    }
    
    public void setTempoFactor(final double n) {
        this.sequencer.setTempoFactor((float)(Object)new Double(Math.exp(2.2 * n)));
    }
    
    public void applyTempoFactor(final double n) {
        final double exp = Math.exp(2.2 * n);
        final Data dataAtTime = this.midiWindow.pianoRoll.getDataAtTime(6, 0, 0, this.getTickPosition());
        if (dataAtTime != null) {
            final int n2 = (int)Math.round((long)dataAtTime.getValue() / exp);
            long timestamp = dataAtTime.getTimestamp();
            final long selectionStart = this.midiWindow.pianoRoll.selectionStart;
            final long selectionEnd = this.midiWindow.pianoRoll.selectionEnd;
            if (selectionStart < selectionEnd) {
                timestamp = selectionStart;
                this.midiWindow.pianoRoll.removeDataInTheRange(0, 0, 6, selectionStart, selectionEnd);
            }
            else {
                this.midiWindow.pianoRoll.removeData(dataAtTime);
            }
            final Data data = new Data(6, new Integer(n2), 0, timestamp, 0, null, false, this.midiWindow.pianoRoll);
            this.midiWindow.pianoRoll.insertData(0, 0, 6, data);
            this.midiWindow.pianoRoll.alterData(data);
            this.modification();
            this.midiWindow.tempoSlider.setValue(50);
        }
    }
    
    public void rewind() {
        this.playing = false;
        this.midiWindow.stop();
        this.sequencer.setTickPosition(0L);
        this.sequencer.stop();
        this.midiWindow.progressBar.setValue(0);
        this.midiWindow.pianoRoll.setPlayPosition(0L, false);
        this.midiWindow.pianoRoll.updateViewPositionX(0L);
        this.midiWindow.pianoRoll.pianoRollGraph.repaint();
    }
    
    public void playstop() {
        if (this.isPlaying()) {
            this.stop();
        }
        else {
            this.play();
        }
    }
    
    public void play() {
        if (this.midiWindow.pianoRoll.selectionStart != this.midiWindow.pianoRoll.selectionEnd) {
            this.setPlayPosition(Math.min(this.midiWindow.pianoRoll.selectionStart, this.midiWindow.pianoRoll.selectionEnd), false);
        }
        else {
            if (this.getTickPosition() == this.getSequenceLength()) {
                this.rewind();
            }
            this.setPlayPosition(this.getTickPosition(), false);
        }
        this.playing = true;
        this.stopAllSounds();
        if (this.recording) {
            this.midiWindow.pianoRoll.emptySelection();
        }
        this.time = this.getTickPosition() / 480L;
        this.previousTime = this.time;
        this.seqTimer.restart();
        this.midiWindow.play();
        this.guiTimer.restart();
        this.sequencer.start();
    }
    
    public void stop() {
        this.stopSequencer();
        this.stopAllSounds();
        if (this.playing && this.recording) {
            this.record();
        }
        this.playing = false;
        this.midiWindow.stop();
        this.guiTimer.stop();
        this.seqTimer.stop();
    }
    
    public void stopSequencer() {
        this.sequencer.stop();
    }
    
    public boolean isPlaying() {
        return this.playing;
    }
    
    public boolean isLoopOn() {
        return this.loop;
    }
    
    public boolean isRecording() {
        return this.recording;
    }
    
    public boolean sequencerIsRunning() {
        return this.sequencer.isRunning();
    }
    
    public void selectProgram(final Program program, final int n) {
        try {
            final ShortMessage shortMessage = new ShortMessage();
            shortMessage.setMessage(192, n, program.getProgram(), 0);
            this.outputFilter.send(shortMessage, -1L);
        }
        catch (Exception ex) {}
    }
    
    public void playNote(final int n, final long n2, final int n3, final int n4) {
        if (n >= 0 && n < 16) {
            final Program programAtTime = this.midiWindow.pianoRoll.getProgramAtTime(n, n2);
            if (programAtTime != null) {
                this.selectProgram(programAtTime, n);
            }
            this.playNoteJava(n, n3, n4);
            this.midiWindow.pianoRoll.controllerGraph.hitKey(n3, MidiWindow.velocityColor(MidiWindow.channelColor[n], n4));
        }
    }
    
    public void playNoteJava(final int n, final int n2, final int n3) {
        try {
            final ShortMessage shortMessage = new ShortMessage();
            shortMessage.setMessage(144, n, n2, n3);
            this.outputFilter.send(shortMessage, -1L);
        }
        catch (Exception ex) {}
    }
    
    public void stopNote(final int n, final int n2, final int n3) {
        this.stopNoteJava(n, n2, n3);
        this.midiWindow.pianoRoll.controllerGraph.releaseKey(n2);
    }
    
    public void stopNoteJava(final int n, final int n2, final int n3) {
        try {
            final ShortMessage shortMessage = new ShortMessage();
            shortMessage.setMessage(128, n, n2, n3);
            this.outputFilter.send(shortMessage, -1L);
        }
        catch (Exception ex) {}
    }
    
    public void stopAllSounds() {
        for (int i = 0; i < 16; ++i) {
            this.stopAllSounds(i);
        }
        this.midiWindow.pianoRoll.notesBeingScrubbed.removeAllElements();
    }
    
    public void stopAllSounds(final int n) {
        this.stopAllSoundsJava(n);
    }
    
    public void stopAllSoundsJava(final int n) {
        try {
            final ShortMessage shortMessage = new ShortMessage();
            shortMessage.setMessage(176, n, 120, 0);
            for (int i = 0; i < this.getNumberOfOutputs(); ++i) {
                if (this.getOutput(i).isOpen()) {
                    this.getOutput(i).getReceiver().send(shortMessage, -1L);
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void setOutputShift(final int outputShift) {
        this.stopAllSounds();
        this.outputShift = outputShift;
    }
    
    public void finalize() {
        if (this.sequencer.isOpen()) {
            this.sequencer.close();
        }
        if (MidiSwing.debug) {
            System.out.println("Devices are closed.");
        }
    }
    
    public void initializeTracks(final int n) {
        this.removeAllTracks();
        this.currentTrack = 0;
        for (int i = 0; i < 16; ++i) {
            this.midiWindow.channelButton[i].setEnabled(false);
            this.midiWindow.channelButton[i].setSelected(false);
        }
    }
    
    public int getNumberOfTracks() {
        if (this.sequence != null) {
            return this.sequence.getTracks().length;
        }
        return 0;
    }
    
    public int getTrackLength(final int n) {
        if (this.sequence == null) {
            return 0;
        }
        if (n < this.sequence.getTracks().length) {
            return this.sequence.getTracks()[n].size();
        }
        return 0;
    }
    
    public Track getTrack(final int n) {
        Track track = null;
        if (n < this.sequence.getTracks().length) {
            track = this.sequence.getTracks()[n];
        }
        return track;
    }
    
    public Track getCurrentTrack() {
        return this.getTrack(this.currentTrack);
    }
    
    public void removeAllTracks() {
        this.midiWindow.trackChooser.removeAllItems();
        this.midiWindow.pianoRoll.removeAllTracks();
        this.numberOfTracks = 0;
    }
    
    public void deleteTrack(final int n) {
        if (this.numberOfTracks != 1) {
            this.sequence.deleteTrack(this.getTrack(n));
            this.fixTempo();
            this.midiWindow.pianoRoll.deleteTrack(n);
            --this.numberOfTracks;
            this.midiWindow.trackChooser.removeItemAt(n);
            this.trackMainChannelNumber.removeElementAt(n);
            this.outputForTrack.removeElementAt(n);
            switch (n) {
                case 0: {
                    this.currentTrack = 0;
                    break;
                }
                default: {
                    this.currentTrack = n - 1;
                    break;
                }
            }
            this.midiWindow.trackChooser.setSelectedIndex(this.currentTrack);
            this.midiWindow.pianoRoll.pianoRollGraph.repaint();
            this.midiWindow.pianoRoll.controllerGraph.repaint();
            this.midiWindow.midiEventTable.update();
            this.modification();
        }
    }
    
    public void renameTrack(final int n) {
        final String showInputDialog = JOptionPane.showInputDialog(this.midiWindow, MidiSwing.resource.getString("NEW_NAME_FOR_TRACK") + n + ":");
        this.midiWindow.requestFocus();
        if (showInputDialog != null && showInputDialog != "") {
            this.setTrackName(n, showInputDialog);
            this.modification();
        }
    }
    
    public void setTrackName(final int selectedIndex, final String s) {
        if (selectedIndex < this.numberOfTracks) {
            this.midiWindow.trackChooser.removeItemAt(selectedIndex);
            this.midiWindow.trackChooser.insertItemAt(s, selectedIndex);
        }
        else {
            this.midiWindow.trackChooser.addItem(s);
        }
        this.midiWindow.trackChooser.setSelectedIndex(selectedIndex);
        this.midiWindow.trackChooser.repaint();
        if (this.getTrack(selectedIndex).size() != 0) {
            int i = 0;
            int n = 0;
            while (i == 0) {
                final MidiEvent value = this.getTrack(selectedIndex).get(n);
                if (value.getMessage() instanceof MetaMessage && ((MetaMessage)value.getMessage()).getType() == 3) {
                    this.getTrack(selectedIndex).remove(value);
                }
                ++n;
                if (value.getTick() > 0L || n >= this.getTrack(selectedIndex).size()) {
                    i = 1;
                }
            }
        }
        final MetaMessage metaMessage = new MetaMessage();
        final byte[] bytes = s.getBytes();
        try {
            metaMessage.setMessage(3, bytes, bytes.length);
            this.getTrack(selectedIndex).add(new MidiEvent(metaMessage, 0L));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void addNewTrack(int min) {
        this.midiWindow.pianoRoll.addNewTrack();
        this.trackMainChannelNumber.addElement(new Integer(min));
        switch (this.numberOfTracks) {
            case 0: {
                if (this.midiFileType == 0) {
                    this.midiWindow.trackChooser.addItem(MidiSwing.resource.getString("MY_SEQUENCE"));
                    break;
                }
                this.midiWindow.trackChooser.addItem(MidiSwing.resource.getString("TEMPO_TRACK"));
                break;
            }
            default: {
                this.midiWindow.trackChooser.addItem(MidiSwing.resource.getString("TRACK") + " " + this.numberOfTracks);
                if (min == -1) {}
                if (min == -2) {
                    min = Math.min(15, this.minUnusedChannel());
                    this.enableChannel(min);
                    this.setMainChannelForTrack(this.numberOfTracks, min);
                    break;
                }
                break;
            }
        }
        this.setOutputForTrack(this.defaultOutputNumber, this.numberOfTracks, false);
        ++this.numberOfTracks;
    }
    
    public void createTrack(final int n) {
        this.sequence.createTrack();
        this.addNewTrack(n);
    }
    
    public void createTrackAndSelectIt(final int n) {
        this.createTrack(n);
        this.selectTrack(this.numberOfTracks - 1);
        this.setEndOfCurrentTrack(7680L);
    }
    
    public void insertNewTrack(final int n, final int n2) {
        if (n < this.numberOfTracks) {
            try {
                final Sequence sequence = new Sequence(this.sequence.getDivisionType(), this.sequence.getResolution());
                for (int i = 0; i < n; ++i) {
                    final Track track = sequence.createTrack();
                    for (int j = 0; j < this.getTrack(i).size(); ++j) {
                        track.add(this.getTrack(i).get(j));
                    }
                }
                sequence.createTrack();
                this.trackMainChannelNumber.insertElementAt(new Integer(n2), n);
                this.outputForTrack.insertElementAt(new Integer(this.defaultOutputNumber), n);
                this.midiWindow.trackChooser.insertItemAt(MidiSwing.resource.getString("TRACK") + " -", n);
                this.midiWindow.pianoRoll.insertNewTrack(n);
                for (int k = n; k < this.numberOfTracks; ++k) {
                    final Track track2 = sequence.createTrack();
                    for (int l = 0; l < this.getTrack(k).size(); ++l) {
                        track2.add(this.getTrack(k).get(l));
                    }
                }
                this.sequence = sequence;
                ++this.numberOfTracks;
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            if (this.currentTrack >= n) {
                this.selectTrack(this.currentTrack + 1);
            }
        }
    }
    
    public void selectTrack(final int n) {
        this.currentTrack = n;
        this.setEndOfCurrentTrack(this.getTrack(n).ticks());
        this.midiWindow.trackChooser.setSelectedIndex(n);
        this.midiWindow.outputChooser.setSelectedIndex(this.outputForTrack.get(n));
        this.selectChannel(this.trackMainChannelNumber.get(n));
        this.midiWindow.repaint();
        this.midiWindow.pianoRoll.pianoRollGraph.repaint();
        this.midiWindow.pianoRoll.controllerGraph.repaint();
        this.midiWindow.midiEventTable.update();
    }
    
    public void selectTrackWhoseMainChannelIs(final int n) {
        final int trackWhoseMainChannelIs = this.trackWhoseMainChannelIs(n);
        if (trackWhoseMainChannelIs != -1) {
            this.selectTrack(trackWhoseMainChannelIs);
        }
        else {
            this.createTrackAndSelectIt(n);
        }
    }
    
    int trackWhoseMainChannelIs(final int n) {
        int n2 = 0;
        if (this.midiFileType == 1) {
            n2 = -1;
            for (int i = 0; i < this.trackMainChannelNumber.size(); ++i) {
                if ((int)this.trackMainChannelNumber.get(i) == n) {
                    n2 = i;
                }
            }
        }
        return n2;
    }
    
    int channelForTrack(final int n) {
        int intValue = -1;
        if (n >= 0 && n < this.trackMainChannelNumber.size()) {
            intValue = this.trackMainChannelNumber.get(n);
        }
        return intValue;
    }
    
    public void setMainChannelForTrack(final int n, final int n2) {
        if (this.channelForTrack(n) < 0 && n < this.trackMainChannelNumber.size()) {
            this.trackMainChannelNumber.setElementAt(new Integer(n2), n);
        }
    }
    
    int minUnusedChannel() {
        int n = 0;
        for (int i = 0; i < this.trackMainChannelNumber.size(); ++i) {
            final int intValue = this.trackMainChannelNumber.get(i);
            if (intValue == n + 1) {
                n = intValue;
            }
        }
        return n + 1;
    }
    
    public void selectChannel(final int currentChannel) {
        this.currentChannel = currentChannel;
        final Program programAtTime = this.midiWindow.pianoRoll.getProgramAtTime(this.currentChannel, this.getTickPosition());
        if (programAtTime != null) {
            this.selectProgram(programAtTime, this.currentChannel);
        }
        this.updateChannels();
    }
    
    public void updateChannels() {
        for (int i = 0; i < 16; ++i) {
            if (i == this.currentChannel) {
                this.midiWindow.channelButton2[i].setSelected(true);
                this.enableChannel(i);
            }
            else {
                this.midiWindow.channelButton2[i].setSelected(false);
            }
        }
        this.midiWindow.pianoRoll.pianoRollGraph.repaint();
        this.midiWindow.pianoRoll.controllerGraph.repaint();
    }
    
    public void enableChannel(final int n) {
        this.midiWindow.channelButton[n].setEnabled(true);
        this.midiWindow.channelButton[n].setSelected(true);
        ++this.numberOfSelectedChannels;
        this.midiWindow.pianoRoll.repaint();
    }
    
    public void disableChannel(final int n) {
        this.midiWindow.channelButton[n].setSelected(false);
        --this.numberOfSelectedChannels;
        this.midiWindow.pianoRoll.repaint();
    }
    
    public boolean isEnabledChannel(final int n) {
        return this.midiWindow.channelButton[n].isSelected();
    }
    
    public void newLyric() {
        if (this.midiFileType == 1) {
            if (this.lyricsTrackNumber == -1) {
                this.insertNewTrack(1, -1);
                this.setTrackName(this.lyricsTrackNumber = 1, "Words");
            }
            if (this.karaokeSoftTrackNumber == -1) {
                this.insertNewTrack(1, -1);
                this.karaokeSoftTrackNumber = 1;
                ++this.lyricsTrackNumber;
                this.setTrackName(this.karaokeSoftTrackNumber, "Soft karaoke");
                try {
                    final MetaMessage metaMessage = new MetaMessage();
                    metaMessage.setMessage(1, "@KMIDI KARAOKE FILE".getBytes(), "@KMIDI KARAOKE FILE".getBytes().length);
                    this.getTrack(this.karaokeSoftTrackNumber).add(new MidiEvent(metaMessage, 0L));
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            this.selectTrack(this.currentTrack);
        }
    }
    
    public void addKaraokeInfo(final String s) {
    }
    
    public void deleteLyrics() {
        if (this.lyricsTrackNumber != -1) {
            final Track track = this.getTrack(this.lyricsTrackNumber);
            while (track.size() > 1) {
                track.remove(track.get(0));
            }
        }
        this.lyrics = new Vector();
        this.lyricsInfo = new Vector();
    }
    
    public void initializeLyrics() {
        this.lyricsTrackNumber = -1;
        this.karaokeSoftTrackNumber = -1;
        this.lyrics = new Vector();
        this.lyricsInfo = new Vector();
    }
    
    public void addDefaultInfo() {
        this.addLyricsInfo(-1, "@LENGL", null);
        this.addLyricsInfo(-1, "@TUntitled", null);
        this.addLyricsInfo(-1, "@Tby Unknown", null);
    }
    
    public void assignLyricsInfo() {
        if (this.lyricsInfo.size() == 0) {
            this.addDefaultInfo();
        }
        for (int i = 0; i < this.lyricsInfo.size(); ++i) {
            final Lyric lyric = this.lyricsInfo.get(i);
            if (lyric.event == null) {
                final String text = lyric.text;
                try {
                    final MetaMessage metaMessage = new MetaMessage();
                    metaMessage.setMessage(1, text.getBytes(), text.getBytes().length);
                    final MidiEvent event = new MidiEvent(metaMessage, 0L);
                    if (this.lyricsTrackNumber == -1) {
                        this.newLyric();
                    }
                    this.getTrack(this.lyricsTrackNumber).add(event);
                    lyric.trackNumber = this.lyricsTrackNumber;
                    lyric.event = event;
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
    
    public Lyric addLyricsInfo(final int n, final String s, final MidiEvent midiEvent) {
        final Lyric lyric = new Lyric(n, s, midiEvent);
        this.lyricsInfo.add(lyric);
        return lyric;
    }
    
    public Lyric addLyric(final int n, final String s, final MidiEvent midiEvent) {
        final Lyric lyric = new Lyric(n, s, midiEvent);
        this.lyrics.add(lyric);
        return lyric;
    }
    
    public void importLyrics(final File file) {
        this.deleteLyrics();
        int i = 0;
        int n = 1;
        String concat = "";
        String s = "";
        try {
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
            int n2 = 0;
            int n3 = 10;
            while (i == 0) {
                try {
                    final int n4 = n2;
                    n2 = n3;
                    n3 = bufferedReader.read();
                    if (n3 == 13) {
                        n3 = bufferedReader.read();
                        System.out.println("Retour chariot " + n3);
                    }
                    if (n != 0) {
                        if (n3 != 10 && n2 == 10 && n4 == 10) {
                            n = 0;
                        }
                        else if (n3 == 10) {
                            this.addLyricsInfo(-1, "@T" + concat, null);
                            concat = "";
                        }
                        else {
                            concat = concat.concat("" + (char)n3);
                        }
                    }
                    if (n == 0) {
                        if (n3 == 10 || n3 == 32 || n3 == 9 || n3 == 45 || n3 == 95) {
                            if (n2 == 92) {
                                s = s.concat("" + (char)n3);
                            }
                            else if (n3 != 32 || n2 != 32) {
                                if (n3 == 32 && n2 != 32) {
                                    s = s.concat(" ");
                                }
                                this.addLyric(-1, s, null);
                                s = "";
                            }
                        }
                        else {
                            if (n3 != 92) {
                                s = s.concat("" + (char)n3);
                            }
                            if (n2 == 10 && n4 == 10) {
                                s = "\\" + s;
                            }
                            else if (n2 == 10) {
                                s = "/" + s;
                            }
                        }
                    }
                    if (n3 != -1) {
                        continue;
                    }
                    i = 1;
                }
                catch (IOException ex2) {
                    i = 1;
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        this.midiWindow.pianoRoll.assignLyricsToTrack(-1);
        this.assignLyricsInfo();
        this.modification();
    }
    
    public void eventReceived(final Event event) {
        switch (event.message) {
            case 1: {
                this.play();
                break;
            }
            case 2: {
                this.stop();
                break;
            }
            case 3: {
                this.rewind();
                break;
            }
            case 4: {
                this.record();
                break;
            }
            case 5: {
                this.loop();
                break;
            }
        }
    }
    
    public void checkForUpdates(final boolean b) {
        try {
            int n = 1;
            final URLConnection openConnection = new URL("http://www.les-stooges.org/pascal/midiswing/version.txt").openConnection();
            try {
                openConnection.connect();
            }
            catch (Exception ex) {
                n = 0;
                if (b) {
                    JOptionPane.showMessageDialog(this.midiWindow, MidiSwing.resource.getString("CONNECTION_FAILED"));
                    this.midiWindow.requestFocus();
                }
            }
            String string = "";
            if (n != 0) {
                final byte[] array = { 0 };
                for (int i = 0; i < openConnection.getContentLength(); ++i) {
                    try {
                        ((FilterInputStream)openConnection.getContent()).read(array);
                        if (new String(array).compareTo(";") == 0) {
                            i = openConnection.getContentLength();
                        }
                        else {
                            string += new String(array);
                        }
                    }
                    catch (IOException ex2) {
                        n = 0;
                        if (b) {
                            JOptionPane.showMessageDialog(this.midiWindow, MidiSwing.resource.getString("CONNECTION_ERROR"));
                            this.midiWindow.requestFocus();
                        }
                    }
                }
            }
            if (n != 0) {
                if (string.compareTo("0.3.6") > 0) {
                    JOptionPane.showMessageDialog(this.midiWindow, MidiSwing.resource.getString("NEW_VERSION").replace("{0}", string));
                    this.midiWindow.requestFocus();
                }
                else if (b) {
                    JOptionPane.showMessageDialog(this.midiWindow, MidiSwing.resource.getString("VERSION_UP_TO_DATE"));
                    this.midiWindow.requestFocus();
                }
            }
        }
        catch (Exception ex3) {}
    }
    
    public void notifyTranslation() {
        final Locale default1 = Locale.getDefault();
        final String language = default1.getLanguage();
        if (language.compareTo("en") != 0 && language.compareTo("fr") != 0 && language.compareTo("es") != 0 && language.compareTo("ja") != 0 && language.compareTo("de") != 0 && language.compareTo("se") != 0 && language.compareTo("fi") != 0 && language.compareTo("it") != 0 && language.compareTo("ru") != 0 && language.compareTo("zh") != 0 && language.compareTo("zh_tw") != 0 && language.compareTo("nl") != 0 && language.compareTo("pl") != 0 && language.compareTo("pt") != 0) {
            final ResourceBundle bundle = ResourceBundle.getBundle("MidiSwingTranslate");
            JOptionPane.showMessageDialog(this.midiWindow, bundle.getString("TRANSLATE").replace("{0}", default1.getDisplayLanguage(bundle.getLocale())));
        }
    }
    
    public void retrievePreferences() {
        (this.prefs = Preferences.userNodeForPackage(this.getClass())).put("LAUNCH_COUNT", "" + (Integer.valueOf(this.prefs.get("LAUNCH_COUNT", "0")) + 1));
        this.windowWidth = Integer.valueOf(this.prefs.get("WINDOW_WIDTH", "0"));
        if (this.windowWidth == 0) {
            this.windowWidth = 968;
        }
        this.windowHeight = Integer.valueOf(this.prefs.get("WINDOW_HEIGHT", "0"));
        if (this.windowHeight == 0) {
            this.windowHeight = 680;
        }
        this.dividerLocation = Integer.valueOf(this.prefs.get("DIVIDER_LOCATION", "0"));
        if (this.dividerLocation == 0) {
            this.dividerLocation = 345;
        }
        this.selectedFile = this.prefs.get("SELECTED_FILE", "0");
        this.currentDirectory = this.prefs.get("CURRENT_DIRECTORY", "0");
    }
    
    public void savePreferences() {
        this.prefs.put("WINDOW_WIDTH", "" + this.midiWindow.getWidth());
        this.prefs.put("WINDOW_HEIGHT", "" + this.midiWindow.getHeight());
        this.prefs.put("DIVIDER_LOCATION", "" + this.midiWindow.pianoRoll.splitPane.getDividerLocation());
        final File selectedFile = this.midiWindow.chooser.getSelectedFile();
        if (selectedFile != null) {
            this.prefs.put("SELECTED_FILE", "" + selectedFile.getPath());
        }
        final File currentDirectory = this.midiWindow.chooser.getCurrentDirectory();
        if (currentDirectory != null) {
            this.prefs.put("CURRENT_DIRECTORY", "" + currentDirectory.getPath());
        }
    }
    
    public void close(final boolean b) {
        if (MidiSwing.numberOfWindows == 1) {
            if (b) {
                this.savePreferences();
                System.exit(0);
            }
            else {
                this.emptyDocument = true;
                this.midiWindow.pianoRoll.emptySelection();
                this.loadFile((File)null);
            }
        }
        else {
            this.stop();
            this.midiWindow.dispose();
            --MidiSwing.numberOfWindows;
            this.midiWindow.midiSwing = null;
            System.gc();
        }
    }
    
    public static void initialize() {
        System.out.println("");
        System.out.println("Midi Swing 0.3.6");
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception ex) {}
    }
    
    public static void main(final String[] array) {
        initialize();
        MidiSwing.numberOfWindows = 0;
        if (array.length == 1) {
            new MidiSwing(0, new File(array[0]), 1);
        }
        else {
            new MidiSwing(0, null, 1);
        }
    }
    
    static void findSoundBanks(final String s) {
        final File file = new File(s);
        if (!file.exists()) {
            return;
        }
        final String[] list = file.list();
        if (list.length == 0) {
            return;
        }
        final Vector vector = new Vector();
        for (int i = 0; i < list.length; ++i) {
            final String s2 = list[i];
            if (s2.endsWith(".dls") || s2.endsWith(".DLS")) {
                MidiSwing.soundBankFileList.addElement(s + File.separator + s2);
                MidiSwing.soundBankNameList.addElement(s2);
                MidiSwing.soundBankInstrumentKitList.addElement(MidiSwing.GM_Kit);
            }
            if (s2.endsWith(".sf2") || s2.endsWith(".SF2")) {
                final String string = s + File.separator + s2;
                MidiSwing.soundBankFileList.addElement(string);
                final SoundFont soundFont = new SoundFont(new File(string));
                MidiSwing.soundBankNameList.addElement(soundFont.getName());
                MidiSwing.soundBankInstrumentKitList.addElement(soundFont.getKit());
            }
        }
    }
    
    static {
        MidiSwing.resource = ResourceBundle.getBundle("MidiSwingResource");
        MidiSwing.debug = true;
        MidiSwing.GM_Kit = InstrumentKit.getGM_Kit();
    }
    
    public class SoundbankDevice implements MidiDevice
    {
        public SoftSynthesizer musicDevice;
        String soundBankFileName;
        public SoundbankDeviceInfo info;
        public Receiver receiver;
        private boolean isOpen;
        
        public SoundbankDevice(final String soundBankFileName, final String s) {
            this.musicDevice = new SoftSynthesizer();
            this.soundBankFileName = soundBankFileName;
            this.info = new SoundbankDeviceInfo(s, new String(""), new String("Gervill Music Device"), new String(""));
            this.isOpen = false;
            try {
                this.receiver = this.musicDevice.getReceiver();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        public void close() {
            this.isOpen = false;
        }
        
        public Info getDeviceInfo() {
            return this.info;
        }
        
        public int getMaxReceivers() {
            return 1;
        }
        
        public int getMaxTransmitters() {
            return 0;
        }
        
        public long getMicrosecondPosition() {
            return 0L;
        }
        
        public Receiver getReceiver() {
            return this.receiver;
        }
        
        public List<Receiver> getReceivers() {
            return null;
        }
        
        public Transmitter getTransmitter() {
            return null;
        }
        
        public List<Transmitter> getTransmitters() {
            return null;
        }
        
        public boolean isOpen() {
            return this.isOpen;
        }
        
        public void open() {
            if (!this.isOpen) {
                if (this.soundBankFileName != "") {
                    try {
                        this.musicDevice.open();
                        this.musicDevice.loadAllInstruments(MidiSystem.getSoundbank(new File(this.soundBankFileName)));
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                this.isOpen = true;
            }
        }
        
        public String getBankFilename() {
            return this.soundBankFileName;
        }
        
        public class SoundbankDeviceInfo extends Info
        {
            public SoundbankDeviceInfo(final String s, final String s2, final String s3, final String s4) {
                super(s, s2, s3, s4);
            }
        }
    }
}
