import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Dimension;
import javax.swing.JSpinner;
import java.awt.Component;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JFrame;

// 
// Decompiled by Procyon v0.5.30
// 

public class InputOptions extends JFrame
{
    private JButton okButton;
    
    public InputOptions(final MidiWindow midiWindow) {
        final MidiSwing midiSwing = midiWindow.midiSwing;
        super(MidiSwing.resource.getString("INPUT_OPTIONS"));
        this.setLayout(new GridBagLayout());
        final GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 0.5;
        final JLabel label = new JLabel("Pitch shift");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        this.add(label, gridBagConstraints);
        final JSpinner spinner = new JSpinner();
        spinner.setValue(0);
        spinner.setMinimumSize(new Dimension(60, 20));
        spinner.addChangeListener(new ChangeListener() {
            public void stateChanged(final ChangeEvent changeEvent) {
            }
        });
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        this.add(spinner, gridBagConstraints);
        final JLabel label2 = new JLabel("Start new recording");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        this.add(label2, gridBagConstraints);
        final JTextField textField = new JTextField(10);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        this.add(textField, gridBagConstraints);
        final JLabel label3 = new JLabel("Delete recording and rewind");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        this.add(label3, gridBagConstraints);
        final JTextField textField2 = new JTextField(10);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        this.add(textField2, gridBagConstraints);
        this.okButton = new JButton("OK");
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        this.add(this.okButton, gridBagConstraints);
        this.okButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                InputOptions.this.setVisible(false);
            }
        });
        this.setSize(new Dimension(400, 300));
    }
}
