import javax.sound.midi.MidiEvent;
import java.awt.event.MouseEvent;
import java.awt.image.ImageObserver;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.Timer;
import java.awt.Image;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseListener;
import javax.swing.JPanel;

// 
// Decompiled by Procyon v0.5.30
// 

class PianoRollGraph extends JPanel implements MouseListener, MouseMotionListener
{
    public PianoRoll p;
    public MidiSwing m;
    public long selectionStartX;
    public long selectionEndX;
    public long selectionMoveX;
    public long insertionStartX;
    public int selectionStartY;
    public int selectionEndY;
    public int selectionMoveY;
    public int insertionStartY;
    public double stretchX;
    public double stretchY;
    private int clickX;
    private int clickY;
    private int dragX;
    private int dragY;
    private Note pointedNote;
    private int partOfPointedNote;
    public static final int timeLineHeight = 13;
    private Image sliderImage;
    private Timer mouseTimer;
    
    public PianoRollGraph(final PianoRoll p) {
        this.setBackground(Color.white);
        this.p = p;
        this.m = this.p.midiWindow.midiSwing;
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        this.selectionMoveX = 0L;
        this.selectionMoveY = 0;
        this.stretchX = 1.0;
        this.stretchY = 1.0;
        this.pointedNote = null;
        this.sliderImage = Toolkit.getDefaultToolkit().getImage(this.getClass().getClassLoader().getResource("images/greenSlider.gif"));
        this.mouseTimer = new Timer(60, new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                if (PianoRollGraph.this.dragX > PianoRollGraph.this.getWidth()) {
                    PianoRollGraph.this.p.increaseViewPositionX(200L);
                    if (PianoRollGraph.this.dragX > PianoRollGraph.this.getWidth() + 50) {
                        PianoRollGraph.this.p.increaseViewPositionX(200L);
                    }
                }
                if (PianoRollGraph.this.dragX < 0) {
                    PianoRollGraph.this.p.increaseViewPositionX(-200L);
                    if (PianoRollGraph.this.dragX < -50) {
                        PianoRollGraph.this.p.increaseViewPositionX(-200L);
                    }
                }
            }
        });
    }
    
    public void paintMeasures(final Graphics graphics) {
        final int currentTrack = this.m.currentTrack;
        final int numberOfTracks = this.m.numberOfTracks;
        final int resolution = this.p.getResolution();
        final int width = this.getWidth();
        final int height = this.getHeight();
        final long viewPositionX = this.p.viewPositionX;
        final long n = (long)(this.p.viewPositionX + width * resolution / this.p.scaleX);
        final Color color = new Color(180, 180, 180);
        graphics.setFont(new Font("Arial", 0, Math.max(8, 2 + (int)Math.max(1.0, Math.floor(this.p.scaleY)))));
        final long endOfCurrentTrack = this.p.endOfCurrentTrack;
        long min = Math.min(n, endOfCurrentTrack);
        while (min > viewPositionX) {
            final Data dataAtTime = this.p.getDataAtTime(7, 0, 0, min);
            if (dataAtTime == null) {
                graphics.setColor(color);
                graphics.fillRect(0, 0, this.p.mapX(min) + 1, height);
                min = viewPositionX;
            }
            else {
                final long timestamp = dataAtTime.getTimestamp();
                final int[] array = (int[])dataAtTime.getValue();
                int n2 = resolution / (1 << array[1] - 2);
                if (n2 == 0) {
                    n2 = 480;
                }
                final PianoRoll p = this.p;
                final double n3 = 38.4 * 0.5;
                final PianoRoll p2 = this.p;
                final double n4 = 38.4 * 1.1;
                final PianoRoll p3 = this.p;
                final double n5 = 38.4 * 1.4;
                final PianoRoll p4 = this.p;
                final double n6 = 38.4 * 1.9;
                final PianoRoll p5 = this.p;
                final double n7 = 38.4 * 2.8;
                final PianoRoll p6 = this.p;
                final double n8 = 38.4 * 3.5;
                for (int n9 = n2 / 8, i = Math.max(0, (int)(viewPositionX - timestamp) / n9); i <= (int)(min - timestamp) / n9; ++i) {
                    if (i % (8 * array[0]) == 0 && this.p.scaleX > n3) {
                        graphics.setColor(new Color(140, 140, 140));
                        graphics.drawLine(this.p.mapX(timestamp + i * n9), 0, this.p.mapX(timestamp + i * n9), height);
                    }
                    else if (i % 8 == 0 && this.p.scaleX > n3) {
                        graphics.setColor(new Color(180, 180, 180));
                        graphics.drawLine(this.p.mapX(timestamp + i * n9), 0, this.p.mapX(timestamp + i * n9), height);
                    }
                    else if (i % 4 == 0 && this.p.scaleX > n4 && this.p.scaleX < n5) {
                        graphics.setColor(new Color(200, 200, 200));
                        graphics.drawLine(this.p.mapX(timestamp + i * n9), 0, this.p.mapX(timestamp + i * n9), height);
                    }
                    else if (i % 2 == 0 && this.p.scaleX > n6 && this.p.scaleX < n7) {
                        graphics.setColor(new Color(220, 220, 220));
                        graphics.drawLine(this.p.mapX(timestamp + i * n9), 0, this.p.mapX(timestamp + i * n9), height);
                    }
                    else if (this.p.scaleX > n8) {
                        graphics.setColor(new Color(220, 220, 220));
                        graphics.drawLine(this.p.mapX(timestamp + i * n9), 0, this.p.mapX(timestamp + i * n9), height);
                    }
                }
                for (int n10 = n2 / 6, j = Math.max(0, (int)(viewPositionX - timestamp) / n10); j <= (int)(min - timestamp) / n10; ++j) {
                    if ((j % 6 == 2 || j % 6 == 4) && this.p.scaleX > n5 && this.p.scaleX <= n6) {
                        graphics.setColor(new Color(210, 210, 250));
                        graphics.drawLine(this.p.mapX(timestamp + j * n10), 0, this.p.mapX(timestamp + j * n10), height);
                    }
                    if ((j % 6 == 2 || j % 6 == 4 || j % 6 == 1 || j % 6 == 5) && this.p.scaleX > n7 && this.p.scaleX <= n8) {
                        graphics.setColor(new Color(210, 210, 250));
                        graphics.drawLine(this.p.mapX(timestamp + j * n10), 0, this.p.mapX(timestamp + j * n10), height);
                    }
                    if (j % 6 == 3 && this.p.scaleX > n7 && this.p.scaleX <= n8) {
                        graphics.setColor(new Color(200, 200, 200));
                        graphics.drawLine(this.p.mapX(timestamp + j * n10), 0, this.p.mapX(timestamp + j * n10), height);
                    }
                }
                if (min != timestamp) {
                    min = timestamp - 1L;
                }
                else {
                    min = viewPositionX;
                }
            }
        }
        if (endOfCurrentTrack <= n) {
            graphics.setColor(new Color(100, 100, 100));
            graphics.drawLine(this.p.mapX(endOfCurrentTrack) - 2, 0, this.p.mapX(endOfCurrentTrack) - 2, height);
            graphics.drawLine(this.p.mapX(endOfCurrentTrack), 0, this.p.mapX(endOfCurrentTrack), height);
            graphics.drawLine(this.p.mapX(endOfCurrentTrack) + 1, 0, this.p.mapX(endOfCurrentTrack) + 1, height);
            graphics.setColor(color);
            graphics.fillRect(this.p.mapX(endOfCurrentTrack) + 2, 0, width - this.p.mapX(endOfCurrentTrack), height);
        }
        if (this.p.selectionStart != this.p.selectionEnd) {
            long min2 = Math.min(this.p.selectionStart, this.p.selectionEnd);
            long max = Math.max(this.p.selectionStart, this.p.selectionEnd);
            if (this.p.mode2 == 12) {
                min2 += this.selectionMoveX;
                max += this.selectionMoveX;
            }
            if (this.p.midiWindow.altKey) {
                graphics.setColor(new Color(255, 0, 0, 30));
            }
            else {
                graphics.setColor(new Color(0, 0, 0, 30));
            }
            graphics.fillRect(this.p.mapX(min2), 0, this.p.mapX(max) - this.p.mapX(min2), height);
            graphics.setColor(new Color(150, 150, 150));
            graphics.drawLine(this.p.mapX(min2), 0, this.p.mapX(min2), height);
            graphics.drawLine(this.p.mapX(max), 0, this.p.mapX(max), height);
        }
    }
    
    public void paintComponent(final Graphics graphics) {
        super.paintComponent(graphics);
        final int currentTrack = this.m.currentTrack;
        final int numberOfTracks = this.m.numberOfTracks;
        final int resolution = this.p.getResolution();
        final int width = this.getWidth();
        final int height = this.getHeight();
        final long viewPositionX = this.p.viewPositionX;
        final long n = (long)(this.p.viewPositionX + width * resolution / this.p.scaleX);
        final int n2 = (int)Math.max(1.0, Math.floor(this.p.scaleY));
        final int max = Math.max(8, 2 + n2);
        for (int i = 0; i <= 10; ++i) {
            if (i == 6) {
                graphics.setColor(new Color(255, 230, 230));
            }
            else {
                graphics.setColor(new Color(255, 240, 240));
            }
            graphics.fillRect(0, this.p.mapY(i * 12), width, n2);
        }
        this.paintMeasures(graphics);
        for (int j = 0; j < numberOfTracks; ++j) {
            for (int k = 0; k < this.p.getNumberOfNotesInTrack(j); ++k) {
                final Note note = this.p.getNote(j, k);
                if (this.p.midiWindow.channelButton[note.channel].isSelected() && note.start < n && note.end > viewPositionX) {
                    if (j != currentTrack && this.p.singleTrackDisplay) {
                        note.paint(graphics, this.selectionMoveX, this.selectionMoveY, this.stretchX, new Color(0, 0, 0, 32));
                    }
                    else {
                        final Color color = MidiWindow.channelColor[note.channel];
                        int n3;
                        if (note.selected) {
                            n3 = (int)Math.min(255.0, Math.floor(this.stretchY * 2.0 * note.velocity));
                        }
                        else {
                            n3 = 2 * note.velocity;
                        }
                        note.paint(graphics, this.selectionMoveX, this.selectionMoveY, this.stretchX, new Color(color.getRed(), color.getGreen(), color.getBlue(), n3));
                    }
                }
            }
        }
        graphics.setColor(new Color(100, 100, 100));
        graphics.setFont(new Font("Arial", 0, max));
        for (int l = 0; l <= 10; ++l) {
            graphics.drawString("C" + l, 5, this.p.mapY(l * 12) + (n2 + max) / 2);
        }
        graphics.setColor(new Color(240, 240, 240));
        graphics.fillRect(0, 0, width, 13);
        graphics.setColor(new Color(188, 188, 188));
        graphics.drawLine(0, 13, width, 13);
        for (int n4 = 0; n4 < 6; ++n4) {
            graphics.setColor(new Color(0, 0, 0, 2 * (6 - n4) * (6 - n4)));
            graphics.drawLine(0, 14 + n4, width, 14 + n4);
        }
        graphics.setColor(new Color(100, 100, 100));
        graphics.setFont(new Font("Arial", 0, max));
        for (int n5 = (int)viewPositionX / resolution; n5 <= (int)n / resolution; ++n5) {
            if (n5 % 4 == 0) {
                graphics.drawString("" + n5 / 4, 5 + this.p.mapX(n5 * resolution), 10);
            }
        }
        if (this.p.mode2 == 3) {
            graphics.setColor(new Color(0, 0, 0, 25));
            final long min = Math.min(this.selectionStartX, this.selectionEndX);
            final long max2 = Math.max(this.selectionStartX, this.selectionEndX);
            final int min2 = Math.min(this.selectionStartY, this.selectionEndY);
            final int max3 = Math.max(this.selectionStartY, this.selectionEndY);
            graphics.fillRect(this.p.mapX(min), this.p.mapY(max3), this.p.scaleX(max2 - min), this.p.scaleY(max3 - min2));
            graphics.setColor(new Color(180, 180, 180));
            graphics.drawRect(this.p.mapX(min), this.p.mapY(max3), this.p.scaleX(max2 - min), this.p.scaleY(max3 - min2));
        }
        if (this.p.mode2 == 11) {
            graphics.setColor(new Color(0, 0, 0, 25));
            final long min3 = Math.min(this.selectionStartX, this.selectionEndX);
            graphics.fillRect(this.p.mapX(min3), 0, this.p.scaleX(Math.max(this.selectionStartX, this.selectionEndX) - min3), 13);
        }
        if (this.p.selectionStart != this.p.selectionEnd) {
            long min4 = Math.min(this.p.selectionStart, this.p.selectionEnd);
            long max4 = Math.max(this.p.selectionStart, this.p.selectionEnd);
            if (this.p.mode2 == 12) {
                min4 += this.selectionMoveX;
                max4 += this.selectionMoveX;
            }
            if (this.p.midiWindow.altKey) {
                graphics.setColor(new Color(255, 0, 0, 30));
            }
            else {
                graphics.setColor(new Color(0, 0, 0, 30));
            }
            graphics.fillRect(this.p.mapX(min4), 0, this.p.mapX(max4) - this.p.mapX(min4), 13);
            graphics.setColor(new Color(150, 150, 150));
            graphics.drawLine(this.p.mapX(min4), 0, this.p.mapX(min4), height);
            graphics.drawLine(this.p.mapX(max4), 0, this.p.mapX(max4), height);
        }
        graphics.setColor(Color.green);
        graphics.drawLine(this.p.mapX(this.p.playPosition), 0, this.p.mapX(this.p.playPosition), height);
        graphics.drawImage(this.sliderImage, this.p.mapX(this.p.playPosition) - 8, 0, 17, 20, this);
        graphics.setColor(new Color(0, 0, 0, 80));
        graphics.drawLine(this.p.mapX(this.p.playPosition) - 8, 9, this.p.mapX(this.p.playPosition) - 8, 10);
        graphics.drawLine(this.p.mapX(this.p.playPosition) + 8, 9, this.p.mapX(this.p.playPosition) + 8, 10);
        graphics.drawLine(this.p.mapX(this.p.playPosition) - 8, 11, this.p.mapX(this.p.playPosition), 19);
        graphics.drawLine(this.p.mapX(this.p.playPosition) + 8, 11, this.p.mapX(this.p.playPosition) + 1, 18);
        graphics.setColor(new Color(0, 0, 0, 40));
        graphics.drawLine(this.p.mapX(this.p.playPosition) - 8, 12, this.p.mapX(this.p.playPosition), 20);
        graphics.drawLine(this.p.mapX(this.p.playPosition) + 8, 12, this.p.mapX(this.p.playPosition) + 1, 19);
        if (this.m.midiFileType == 1 && this.m.currentTrack == 0) {
            graphics.setColor(new Color(100, 160, 200));
            graphics.setFont(new Font("Arial", 0, 16));
            final MidiSwing m = this.m;
            graphics.drawString(MidiSwing.resource.getString("NOT_RECOMMENDED_TEMPO_TRACK"), 20, 40);
        }
    }
    
    public void mouseClicked(final MouseEvent mouseEvent) {
        if (mouseEvent.getClickCount() == 2 && this.pointedNote != null) {
            this.p.changeNoteProperties(this.pointedNote);
        }
    }
    
    public Note pointedNote(final int n, final int n2) {
        final int width = this.getWidth();
        this.getHeight();
        final long viewPositionX = this.p.viewPositionX;
        final long n3 = (long)(this.p.viewPositionX + width * this.p.getResolution() / this.p.scaleX);
        Note note = null;
        for (int n4 = 0; note == null && n4 < this.m.getNumberOfTracks(); ++n4) {
            if (n4 == this.m.currentTrack || !this.p.singleTrackDisplay) {
                for (int n5 = 0; note == null && n5 < this.p.getNumberOfNotesInTrack(n4); ++n5) {
                    final Note note2 = this.p.getNote(n4, n5);
                    if (this.p.midiWindow.channelButton[note2.channel].isSelected() && note2.start < n3 && note2.end > viewPositionX && note2.contains(n, n2)) {
                        note = note2;
                    }
                }
            }
        }
        return note;
    }
    
    public void mousePressed(final MouseEvent mouseEvent) {
        this.mouseTimer.restart();
        this.clickX = mouseEvent.getX();
        this.clickY = mouseEvent.getY();
        this.selectionStartX = this.p.invertX(mouseEvent.getX());
        this.selectionStartY = this.p.invertY(mouseEvent.getY());
        if (mouseEvent.getY() < 13) {
            if (this.clickX >= this.p.mapX(this.p.playPosition) - 8 && this.clickX <= this.p.mapX(this.p.playPosition) + 8) {
                this.p.rememberMode = this.p.mode2;
                this.p.mode2 = 8;
            }
            else if (this.p.selectionStart != this.p.selectionEnd && this.clickX >= this.p.mapX(this.p.selectionEnd) - 2 && this.clickX <= this.p.mapX(this.p.selectionEnd) + 2) {
                this.p.rememberMode = this.p.mode2;
                this.p.mode2 = 10;
            }
            else if (this.p.selectionStart != this.p.selectionEnd && this.clickX >= this.p.mapX(this.p.selectionStart) - 2 && this.clickX <= this.p.mapX(this.p.selectionStart) + 2) {
                this.p.rememberMode = this.p.mode2;
                this.p.mode2 = 9;
            }
            else if (this.p.selectionStart != this.p.selectionEnd && this.clickX >= this.p.mapX(this.p.selectionStart) + 2 && this.clickX <= this.p.mapX(this.p.selectionEnd) - 2) {
                this.selectionEndX = this.selectionStartX;
                this.selectionEndY = this.selectionStartY;
                this.selectionMoveX = 0L;
                this.selectionMoveY = 0;
                this.p.rememberMode = this.p.mode2;
                this.p.mode2 = 12;
            }
            else if (this.p.mode2 == 2 || this.p.mode2 == 4 || this.p.mode2 == 1) {
                this.selectionEndX = this.selectionStartX;
                this.selectionEndY = this.selectionStartY;
                this.p.rememberMode = this.p.mode2;
                this.p.mode2 = 11;
            }
        }
        else if (this.p.mode2 == 1) {
            this.m.setPlayPosition(this.p.invertX(mouseEvent.getX()), true);
            this.p.rememberMode = this.p.mode2;
            this.p.mode2 = 8;
        }
        else {
            this.pointedNote = this.pointedNote(mouseEvent.getX(), mouseEvent.getY());
            if (this.pointedNote == null) {
                if (this.clickX >= this.p.mapX(this.p.endOfCurrentTrack) - 2 && this.clickX <= this.p.mapX(this.p.endOfCurrentTrack) + 2) {
                    this.p.rememberMode = this.p.mode2;
                    this.p.mode2 = 7;
                }
                else if (this.p.selectionStart != this.p.selectionEnd && this.clickX >= this.p.mapX(this.p.selectionEnd) - 2 && this.clickX <= this.p.mapX(this.p.selectionEnd) + 2) {
                    this.p.rememberMode = this.p.mode2;
                    this.p.mode2 = 10;
                }
                else if (this.p.selectionStart != this.p.selectionEnd && this.clickX >= this.p.mapX(this.p.selectionStart) - 2 && this.clickX <= this.p.mapX(this.p.selectionStart) + 2) {
                    this.p.rememberMode = this.p.mode2;
                    this.p.mode2 = 9;
                }
                else if (this.p.selectionStart != this.p.selectionEnd && this.clickX >= this.p.mapX(this.p.selectionStart) + 2 && this.clickX <= this.p.mapX(this.p.selectionEnd) - 2) {
                    this.selectionEndX = this.selectionStartX;
                    this.selectionEndY = this.selectionStartY;
                    this.selectionMoveX = 0L;
                    this.selectionMoveY = 0;
                    this.p.rememberMode = this.p.mode2;
                    this.p.mode2 = 12;
                }
                else {
                    if (this.p.mode2 == 2) {
                        this.selectionEndX = this.selectionStartX;
                        this.selectionEndY = this.selectionStartY;
                        this.p.mode2 = 3;
                    }
                    if (this.p.mode2 == 4) {
                        final int currentChannel = this.m.currentChannel;
                        final int currentTrack = this.m.currentTrack;
                        if (currentChannel != -1) {
                            this.m.playNote(currentChannel, this.selectionStartX, this.selectionStartY, 100);
                            this.pointedNote = new Note(this.selectionStartY, 100, currentChannel, this.selectionStartX, this.selectionStartX + this.m.noteDuration, currentTrack, null, null, true, null, this.p);
                            this.p.addNote(currentTrack, this.pointedNote);
                            this.p.emptySelection();
                            this.p.selectionStart = this.p.selectionEnd;
                            this.p.addNoteToSelection(this.pointedNote);
                        }
                        this.repaint();
                        this.p.mode2 = 5;
                    }
                }
            }
            else {
                if (this.p.mode2 == 2) {
                    this.m.playNote(this.pointedNote.channel, this.pointedNote.start, this.pointedNote.pitch, this.pointedNote.velocity);
                    if (this.pointedNote.selected) {
                        if (mouseEvent.isAltDown()) {
                            this.p.removeNoteFromSelection(this.pointedNote);
                        }
                    }
                    else {
                        if (!mouseEvent.isShiftDown() && !mouseEvent.isAltDown()) {
                            this.p.emptySelection();
                        }
                        if (!mouseEvent.isAltDown()) {
                            this.p.addNoteToSelection(this.pointedNote);
                        }
                    }
                    this.repaint();
                }
                if (this.p.mode2 == 4) {
                    this.m.playNote(this.pointedNote.channel, this.pointedNote.start, this.pointedNote.pitch, this.pointedNote.velocity);
                    if (!this.pointedNote.selected && !mouseEvent.isShiftDown()) {
                        this.p.emptySelection();
                    }
                    this.p.addNoteToSelection(this.pointedNote);
                    if (mouseEvent.isAltDown()) {
                        this.p.copySelection();
                        this.p.pasteClipboard(this.selectionStartX);
                        this.p.mode2 = 5;
                    }
                    this.repaint();
                }
                this.p.selectDataUnderSelectedNotes();
            }
        }
    }
    
    public void mouseReleased(final MouseEvent mouseEvent) {
        this.mouseTimer.stop();
        final int currentTrack = this.m.currentTrack;
        switch (this.p.mode2) {
            case 8: {
                this.m.stopAllSounds();
                this.p.mode2 = this.p.rememberMode;
                break;
            }
            case 9: {
                this.p.alterSelection(0L, 0, 1.0, 1.0);
                this.p.selectionStart0 = this.p.selectionStart;
                this.p.mode2 = this.p.rememberMode;
                this.p.emptySelection();
                for (int i = 0; i < this.m.getNumberOfTracks(); ++i) {
                    if (i == this.m.currentTrack || !this.p.singleTrackDisplay) {
                        for (int j = 0; j < this.p.getNumberOfNotesInTrack(i); ++j) {
                            final Note note = this.p.getNote(i, j);
                            if (this.p.midiWindow.channelButton[note.channel].isSelected() && note.start <= this.p.selectionEnd && note.start >= this.p.selectionStart) {
                                this.p.addNoteToSelection(note);
                            }
                        }
                    }
                }
                this.p.selectDataUnderSelectedNotes();
                break;
            }
            case 10: {
                this.p.alterSelection(0L, 0, 1.0, 1.0);
                this.p.selectionEnd0 = this.p.selectionEnd;
                this.p.mode2 = this.p.rememberMode;
                this.p.emptySelection();
                for (int k = 0; k < this.m.getNumberOfTracks(); ++k) {
                    if (k == this.m.currentTrack || !this.p.singleTrackDisplay) {
                        for (int l = 0; l < this.p.getNumberOfNotesInTrack(k); ++l) {
                            final Note note2 = this.p.getNote(k, l);
                            if (this.p.midiWindow.channelButton[note2.channel].isSelected() && note2.start <= this.p.selectionEnd && note2.start >= this.p.selectionStart) {
                                this.p.addNoteToSelection(note2);
                            }
                        }
                    }
                }
                this.p.selectDataUnderSelectedNotes();
                break;
            }
            case 2: {
                if (this.pointedNote != null) {
                    this.m.stopAllSounds(this.pointedNote.channel);
                }
                this.p.alterSelection(this.selectionMoveX, this.selectionMoveY, this.stretchX, this.stretchY);
                if (this.m.magnetiseGrid) {
                    this.p.quantizeSelection();
                    break;
                }
                break;
            }
            case 12: {
                this.p.selectionStart = this.p.selectionStart + this.selectionEndX - this.selectionStartX;
                this.p.selectionEnd = this.p.selectionEnd + this.selectionEndX - this.selectionStartX;
                this.p.alterSelection(this.selectionMoveX, this.selectionMoveY, this.stretchX, this.stretchY);
                if (this.m.magnetiseGrid) {
                    this.p.quantizeSelection();
                }
                this.p.selectionStart0 = this.p.selectionStart;
                this.p.selectionEnd0 = this.p.selectionEnd;
                this.p.mode2 = this.p.rememberMode;
                break;
            }
            case 3: {
                this.selectionEndX = this.p.invertX(mouseEvent.getX());
                this.selectionEndY = this.p.invertY(mouseEvent.getY());
                if (!mouseEvent.isShiftDown() && !mouseEvent.isAltDown()) {
                    this.p.emptySelection();
                }
                for (int n = 0; n < this.m.getNumberOfTracks(); ++n) {
                    if (n == this.m.currentTrack || !this.p.singleTrackDisplay) {
                        for (int n2 = 0; n2 < this.p.getNumberOfNotesInTrack(n); ++n2) {
                            final Note note3 = this.p.getNote(n, n2);
                            if (this.p.midiWindow.channelButton[note3.channel].isSelected() && note3.start <= Math.max(this.selectionStartX, this.selectionEndX) && note3.start >= Math.min(this.selectionStartX, this.selectionEndX) && note3.pitch >= Math.min(this.selectionStartY, this.selectionEndY) && note3.pitch <= Math.max(this.selectionStartY, this.selectionEndY)) {
                                if (mouseEvent.isAltDown()) {
                                    this.p.removeNoteFromSelection(note3);
                                }
                                else {
                                    this.p.addNoteToSelection(note3);
                                }
                            }
                        }
                    }
                }
                this.p.selectDataUnderSelectedNotes();
                this.p.mode2 = 2;
                this.p.selectionStart = this.selectionStartX;
                this.p.selectionStart0 = this.selectionStartX;
                this.p.selectionEnd = this.selectionStartX;
                this.p.selectionEnd0 = this.selectionStartX;
                this.m.setPlayPosition(this.selectionStartX, true);
                this.repaint();
                break;
            }
            case 11: {
                this.selectionEndX = this.p.invertX(mouseEvent.getX());
                this.selectionEndY = this.p.invertY(mouseEvent.getY());
                if (Math.abs(this.clickX - mouseEvent.getX()) > 20) {
                    final long min = Math.min(this.selectionStartX, this.selectionEndX);
                    final long max = Math.max(this.selectionStartX, this.selectionEndX);
                    if (mouseEvent.isShiftDown()) {
                        this.p.selectionStart = Math.min(min, this.p.selectionStart0);
                        this.p.selectionEnd = Math.max(max, this.p.selectionEnd0);
                    }
                    else {
                        this.p.selectionStart = min;
                        this.p.selectionEnd = max;
                    }
                    this.p.emptySelection();
                    for (int n3 = 0; n3 < this.m.getNumberOfTracks(); ++n3) {
                        if (n3 == this.m.currentTrack || !this.p.singleTrackDisplay) {
                            for (int n4 = 0; n4 < this.p.getNumberOfNotesInTrack(n3); ++n4) {
                                final Note note4 = this.p.getNote(n3, n4);
                                if (this.p.midiWindow.channelButton[note4.channel].isSelected() && note4.start <= this.p.selectionEnd && note4.start >= this.p.selectionStart) {
                                    this.p.addNoteToSelection(note4);
                                }
                            }
                        }
                    }
                    this.p.selectDataUnderSelectedNotes();
                }
                else {
                    this.selectionStartX = this.selectionEndX;
                    this.p.selectionStart = this.selectionStartX;
                    this.p.selectionEnd = this.selectionStartX;
                }
                this.p.selectionStart0 = this.p.selectionStart;
                this.p.selectionEnd0 = this.p.selectionEnd;
                this.p.mode2 = this.p.rememberMode;
                this.m.setPlayPosition(this.selectionStartX, true);
                this.repaint();
                break;
            }
            case 4: {
                if (this.pointedNote != null) {
                    this.m.stopAllSounds(this.pointedNote.channel);
                }
                this.p.alterSelection(this.selectionMoveX, this.selectionMoveY, this.stretchX, this.stretchY);
                this.p.mode2 = 4;
                if (this.m.magnetiseGrid) {
                    this.p.quantizeSelection();
                    break;
                }
                break;
            }
            case 5: {
                if (this.pointedNote != null) {
                    this.m.stopAllSounds(this.pointedNote.channel);
                }
                this.p.alterSelection(this.selectionMoveX, this.selectionMoveY, this.stretchX, this.stretchY);
                this.p.mode2 = 4;
                if (this.m.magnetiseGrid) {
                    this.p.quantizeSelection();
                    break;
                }
                break;
            }
            case 7: {
                this.m.setEndOfCurrentTrack(this.p.invertX(mouseEvent.getX()));
                this.m.modification();
                this.p.mode2 = this.p.rememberMode;
                break;
            }
        }
        this.selectionMoveX = 0L;
        this.selectionMoveY = 0;
        this.stretchX = 1.0;
        this.stretchY = 1.0;
    }
    
    public void mouseEntered(final MouseEvent mouseEvent) {
        final PianoRoll p = this.p;
        final PianoRoll p2 = this.p;
        p.currentGraph = 1;
    }
    
    public void mouseExited(final MouseEvent mouseEvent) {
        if ((this.p.mode2 == 2 || this.p.mode2 == 4) && this.p.rememberMode != 0) {
            this.p.mode2 = this.p.rememberMode;
            this.p.rememberMode = 0;
            this.setCursor(this.p.cursorWhile[this.p.mode2]);
        }
    }
    
    public void mouseMoved(final MouseEvent mouseEvent) {
        if (mouseEvent.getY() < 13) {
            this.setCursor(this.p.cursorWhile[2]);
            if (this.p.selectionStart != this.p.selectionEnd && mouseEvent.getX() >= this.p.mapX(this.p.selectionEnd) - 2 && mouseEvent.getX() <= this.p.mapX(this.p.selectionEnd) + 2) {
                this.setCursor(this.p.stretchCursor);
            }
            else if (this.p.selectionStart != this.p.selectionEnd && mouseEvent.getX() >= this.p.mapX(this.p.selectionStart) - 2 && mouseEvent.getX() <= this.p.mapX(this.p.selectionStart) + 2) {
                this.setCursor(this.p.stretchCursor);
            }
            else if (this.p.selectionStart != this.p.selectionEnd && mouseEvent.getX() > this.p.mapX(this.p.selectionStart) + 2 && mouseEvent.getX() < this.p.mapX(this.p.selectionEnd) - 2) {
                this.setCursor(this.p.handCursor);
            }
        }
        else {
            if (this.p.rememberMode != 0) {
                this.p.mode2 = this.p.rememberMode;
                this.p.rememberMode = 0;
            }
            this.pointedNote = this.pointedNote(mouseEvent.getX(), mouseEvent.getY());
            if (this.pointedNote == null) {
                if (mouseEvent.getX() >= this.p.mapX(this.p.endOfCurrentTrack) - 2 && mouseEvent.getX() <= this.p.mapX(this.p.endOfCurrentTrack) + 2) {
                    this.setCursor(this.p.stretchCursor);
                }
                else if (this.p.selectionStart != this.p.selectionEnd && mouseEvent.getX() >= this.p.mapX(this.p.selectionEnd) - 2 && mouseEvent.getX() <= this.p.mapX(this.p.selectionEnd) + 2) {
                    if (this.p.mode2 != 1) {
                        this.setCursor(this.p.stretchCursor);
                    }
                }
                else if (this.p.selectionStart != this.p.selectionEnd && mouseEvent.getX() >= this.p.mapX(this.p.selectionStart) - 2 && mouseEvent.getX() <= this.p.mapX(this.p.selectionStart) + 2) {
                    if (this.p.mode2 != 1) {
                        this.setCursor(this.p.stretchCursor);
                    }
                }
                else if (this.p.selectionStart != this.p.selectionEnd && mouseEvent.getX() > this.p.mapX(this.p.selectionStart) + 2 && mouseEvent.getX() < this.p.mapX(this.p.selectionEnd) - 2) {
                    if (this.p.mode2 != 1) {
                        this.setCursor(this.p.handCursor);
                    }
                }
                else {
                    this.setCursor(this.p.cursorWhile[this.p.mode2]);
                }
            }
            if ((this.p.mode2 == 2 || this.p.mode2 == 4) && this.pointedNote != null) {
                switch (this.partOfPointedNote = this.pointedNote.partOfNote(this.p.invertX(mouseEvent.getX()))) {
                    case 0: {
                        this.setCursor(this.p.velocityCursor);
                        break;
                    }
                    case 1: {
                        this.setCursor(this.p.moveCursor);
                        break;
                    }
                    case 2: {
                        this.setCursor(this.p.stretchCursor);
                        break;
                    }
                }
            }
        }
    }
    
    public void mouseDragged(final MouseEvent mouseEvent) {
        this.dragX = mouseEvent.getX();
        this.dragY = mouseEvent.getY();
        if (this.p.mode2 == 8) {
            this.m.setPlayPosition(Math.max(0L, this.p.invertX(mouseEvent.getX())), true);
        }
        if (this.p.mode2 == 9) {
            this.p.selectionStart = this.p.invertX(mouseEvent.getX());
            this.p.repaint();
        }
        if (this.p.mode2 == 10) {
            this.p.selectionEnd = this.p.invertX(mouseEvent.getX());
            this.p.repaint();
        }
        if ((this.p.mode2 == 2 || this.p.mode2 == 4) && this.pointedNote != null) {
            switch (this.partOfPointedNote) {
                case 0: {
                    this.selectionEndY = this.p.invertY(mouseEvent.getY());
                    this.stretchY = Math.max(0.05, 1.0 - (mouseEvent.getY() - this.clickY) / 60.0);
                    this.repaint();
                    break;
                }
                case 2: {
                    this.selectionEndX = this.p.invertX(mouseEvent.getX());
                    this.stretchX = Math.max(0.1, 1.0 + (0.0 + this.selectionEndX - this.selectionStartX) / (this.pointedNote.end - this.pointedNote.start));
                    this.repaint();
                    break;
                }
                case 1: {
                    final int selectionEndY = this.selectionEndY;
                    this.selectionEndX = this.p.invertX(mouseEvent.getX());
                    this.selectionEndY = this.p.invertY(mouseEvent.getY());
                    if (this.selectionEndY != selectionEndY && this.pointedNote != null) {
                        this.m.stopNote(this.pointedNote.channel, selectionEndY, 0);
                        this.m.playNote(this.pointedNote.channel, this.selectionEndX, this.selectionEndY, this.pointedNote.velocity);
                    }
                    this.selectionMoveX = this.selectionEndX - this.selectionStartX;
                    this.selectionMoveY = this.selectionEndY - this.selectionStartY;
                    this.repaint();
                    break;
                }
            }
        }
        if (this.p.mode2 == 12) {
            this.selectionEndX = this.p.invertX(mouseEvent.getX());
            this.selectionMoveX = this.selectionEndX - this.selectionStartX;
            this.repaint();
        }
        if (this.p.mode2 == 3 || this.p.mode2 == 11) {
            this.selectionEndX = this.p.invertX(mouseEvent.getX());
            this.selectionEndY = this.p.invertY(mouseEvent.getY());
            this.repaint();
        }
        if (this.p.mode2 == 5) {
            final int selectionEndY2 = this.selectionEndY;
            this.selectionEndX = this.p.invertX(mouseEvent.getX());
            this.selectionEndY = this.p.invertY(mouseEvent.getY());
            this.selectionMoveX = this.selectionEndX - this.selectionStartX;
            this.selectionMoveY = this.selectionEndY - this.selectionStartY;
            if (this.selectionEndY != selectionEndY2 && this.pointedNote != null) {
                this.m.stopNote(this.pointedNote.channel, selectionEndY2, 0);
                this.m.playNote(this.pointedNote.channel, this.selectionEndX, this.selectionEndY, this.pointedNote.velocity);
            }
            this.repaint();
        }
        if (this.p.mode2 == 7 && mouseEvent.getY() > 13) {
            this.p.endOfCurrentTrack = this.p.invertX(mouseEvent.getX());
            this.p.repaint();
        }
    }
}
