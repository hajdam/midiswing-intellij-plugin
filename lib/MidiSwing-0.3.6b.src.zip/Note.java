import java.awt.Font;
import java.awt.Color;
import java.awt.Graphics;
import javax.sound.midi.MidiEvent;
import java.awt.Rectangle;

// 
// Decompiled by Procyon v0.5.30
// 

public class Note
{
    public PianoRoll p;
    private Rectangle boundingBox;
    public int pitch;
    public int velocity;
    public int channel;
    public int track;
    public long start;
    public long end;
    public MidiEvent beginningEvent;
    public MidiEvent endingEvent;
    public boolean selected;
    public Lyric lyric;
    
    public Note(final int pitch, final int velocity, final int channel, final long start, final long end, final int track, final MidiEvent beginningEvent, final MidiEvent endingEvent, final boolean selected, final Lyric lyric, final PianoRoll p11) {
        this.boundingBox = new Rectangle();
        this.pitch = pitch;
        this.start = start;
        this.end = end;
        this.track = track;
        this.velocity = velocity;
        this.channel = channel;
        this.beginningEvent = beginningEvent;
        this.endingEvent = endingEvent;
        this.selected = selected;
        this.lyric = lyric;
        this.p = p11;
    }
    
    public void setEnd(final long end) {
        this.end = end;
    }
    
    public void setEndingEvent(final MidiEvent endingEvent) {
        this.endingEvent = endingEvent;
    }
    
    private void calcBoundingBox(final long n, final int n2, final double n3) {
        if (this.selected) {
            if (this.p.selectionEnd != this.p.selectionStart && (this.p.selectionEnd0 != this.p.selectionEnd || this.p.selectionStart0 != this.p.selectionStart) && this.p.midiWindow.altKey) {
                this.boundingBox.x = this.p.mapX(this.p.selectionStart + (int)Math.floor((this.start - this.p.selectionStart0) * (this.p.selectionEnd - this.p.selectionStart + 0.0) / (this.p.selectionEnd0 - this.p.selectionStart0)) + n);
                this.boundingBox.width = Math.max(1, (int)Math.floor(n3 * this.p.scaleX(this.end - this.start) * (this.p.selectionEnd - this.p.selectionStart + 0.0) / (this.p.selectionEnd0 - this.p.selectionStart0)));
            }
            else {
                this.boundingBox.x = this.p.mapX(this.start + n);
                this.boundingBox.width = Math.max(1, (int)Math.floor(n3 * this.p.scaleX(this.end - this.start)));
            }
            this.boundingBox.y = this.p.mapY(this.pitch + n2);
        }
        else {
            this.boundingBox.x = this.p.mapX(this.start);
            this.boundingBox.y = this.p.mapY(this.pitch);
            this.boundingBox.width = Math.max(1, this.p.scaleX(this.end - this.start));
        }
        this.boundingBox.height = Math.max(1, this.p.scaleY(1) - 1);
    }
    
    public Note copy() {
        return new Note(this.pitch, this.velocity, this.channel, this.start, this.end, this.track, null, null, this.selected, this.lyric, this.p);
    }
    
    public void setLyric(final String text) {
        this.lyric.setText(text);
    }
    
    public void setLyric(final Lyric lyric) {
        this.lyric = lyric;
    }
    
    public void paint(final Graphics graphics, final long n, final int n2, final double n3, final Color color) {
        this.calcBoundingBox(n, n2, n3);
        if (this.selected) {
            graphics.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)Math.round(0.15 * color.getAlpha())));
            final int[] array = new int[8];
            final int[] array2 = new int[8];
            array[0] = this.boundingBox.x;
            array2[0] = this.boundingBox.y - 3;
            array[1] = this.boundingBox.x + this.boundingBox.width;
            array2[1] = this.boundingBox.y - 3;
            array[2] = this.boundingBox.x + this.boundingBox.width + 3;
            array2[2] = this.boundingBox.y;
            array[3] = this.boundingBox.x + this.boundingBox.width + 3;
            array2[3] = this.boundingBox.y + this.boundingBox.height;
            array[4] = this.boundingBox.x + this.boundingBox.width;
            array2[4] = this.boundingBox.y + this.boundingBox.height + 3;
            array[5] = this.boundingBox.x;
            array2[5] = this.boundingBox.y + this.boundingBox.height + 3;
            array[6] = this.boundingBox.x - 3;
            array2[6] = this.boundingBox.y + this.boundingBox.height;
            array[7] = this.boundingBox.x - 3;
            array2[7] = this.boundingBox.y;
            graphics.drawPolygon(array, array2, 8);
            graphics.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)Math.round(0.3 * color.getAlpha())));
            array[0] = this.boundingBox.x;
            array2[0] = this.boundingBox.y - 2;
            array[1] = this.boundingBox.x + this.boundingBox.width;
            array2[1] = this.boundingBox.y - 2;
            array[2] = this.boundingBox.x + this.boundingBox.width + 2;
            array2[2] = this.boundingBox.y;
            array[3] = this.boundingBox.x + this.boundingBox.width + 2;
            array2[3] = this.boundingBox.y + this.boundingBox.height;
            array[4] = this.boundingBox.x + this.boundingBox.width;
            array2[4] = this.boundingBox.y + this.boundingBox.height + 2;
            array[5] = this.boundingBox.x;
            array2[5] = this.boundingBox.y + this.boundingBox.height + 2;
            array[6] = this.boundingBox.x - 2;
            array2[6] = this.boundingBox.y + this.boundingBox.height;
            array[7] = this.boundingBox.x - 2;
            array2[7] = this.boundingBox.y;
            graphics.drawPolygon(array, array2, 8);
            graphics.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)Math.round(0.6 * color.getAlpha())));
            graphics.drawLine(this.boundingBox.x, this.boundingBox.y - 1, this.boundingBox.x + this.boundingBox.width, this.boundingBox.y - 1);
            graphics.drawLine(this.boundingBox.x, this.boundingBox.y + this.boundingBox.height + 1, this.boundingBox.x + this.boundingBox.width, this.boundingBox.y + this.boundingBox.height + 1);
            graphics.drawLine(this.boundingBox.x - 1, this.boundingBox.y, this.boundingBox.x - 1, this.boundingBox.y + this.boundingBox.height);
            graphics.drawLine(this.boundingBox.x + this.boundingBox.width + 1, this.boundingBox.y, this.boundingBox.x + this.boundingBox.width + 1, this.boundingBox.y + this.boundingBox.height);
            graphics.setColor(color);
            graphics.drawRect(this.boundingBox.x, this.boundingBox.y, this.boundingBox.width, this.boundingBox.height);
            graphics.setColor(Color.white);
            graphics.fillRect(this.boundingBox.x + 1, this.boundingBox.y + 1, this.boundingBox.width - 1, this.boundingBox.height - 1);
        }
        else {
            graphics.setColor(color);
            graphics.fillRect(this.boundingBox.x, this.boundingBox.y, this.boundingBox.width, this.boundingBox.height);
        }
        if (this.lyric != null) {
            graphics.setFont(new Font("MS Mincho", 1, 12));
            graphics.setColor(new Color(20, 20, 20));
            graphics.drawString(this.lyric.text, this.boundingBox.x, this.boundingBox.y - 5);
        }
    }
    
    public int partOfNote(final long n) {
        int n2;
        if (n > this.end - (this.end - this.start) / 4L) {
            n2 = 2;
        }
        else if (n < this.start + (this.end - this.start) / 4L) {
            n2 = 0;
        }
        else {
            n2 = 1;
        }
        return n2;
    }
    
    public boolean contains(final int n, final int n2) {
        return this.boundingBox.contains(n, n2);
    }
}
