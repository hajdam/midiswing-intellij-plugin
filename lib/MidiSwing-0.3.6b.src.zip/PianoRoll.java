import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JFrame;
import java.awt.event.KeyEvent;
import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.sound.midi.MetaMessage;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.MidiEvent;
import javax.sound.midi.ShortMessage;
import java.awt.GridBagConstraints;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import java.awt.Component;
import javax.swing.ListCellRenderer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Dimension;
import javax.swing.Icon;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.Point;
import java.awt.Toolkit;
import java.util.Vector;
import javax.swing.JComboBox;
import javax.swing.JToggleButton;
import java.awt.Cursor;
import javax.swing.ImageIcon;
import javax.swing.JScrollBar;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JScrollPane;
import javax.swing.JPanel;

// 
// Decompiled by Procyon v0.5.30
// 

class PianoRoll extends JPanel implements EventListener
{
    public MidiWindow midiWindow;
    private JScrollPane scrollPane;
    public JSplitPane splitPane;
    private JSlider sliderX;
    private JSlider sliderY;
    private JScrollBar scrollBarX;
    private JScrollBar scrollBarY;
    public int currentGraph;
    public static final int PIANOROLLGRAPH = 1;
    public static final int CONTROLLERGRAPH = 2;
    public int mode;
    public int mode2;
    public int rememberMode;
    public static final int PLAYING = 1;
    public static final int SELECTING = 2;
    public static final int DRAGSELECTING = 3;
    public static final int INSERTING = 4;
    public static final int DRAGINSERTING = 5;
    public static final int SLIDING = 6;
    public static final int DRAGEND = 7;
    public static final int DRAGSCRUB = 8;
    public static final int DRAGSTARTSELECTION = 9;
    public static final int DRAGENDSELECTION = 10;
    public static final int DRAGSELECTINGTIME = 11;
    public static final int DRAGTIMESELECTION = 12;
    public int controllerType;
    private ImageIcon listenIcon;
    private ImageIcon arrowIcon;
    private ImageIcon penIcon;
    private ImageIcon fingerIcon;
    private ImageIcon handIcon;
    private ImageIcon listen32Icon;
    private ImageIcon pen32Icon;
    private ImageIcon hand32Icon;
    private ImageIcon noteRondeP;
    private ImageIcon noteRonde;
    private ImageIcon noteRonde3;
    private ImageIcon noteBlancheP;
    private ImageIcon noteBlanche;
    private ImageIcon noteBlanche3;
    private ImageIcon noteNoireP;
    private ImageIcon noteNoire;
    private ImageIcon noteNoire3;
    private ImageIcon noteCrocheP;
    private ImageIcon noteCroche;
    private ImageIcon noteCroche3;
    private ImageIcon noteDoubleP;
    private ImageIcon noteDouble;
    private ImageIcon noteDouble3;
    private ImageIcon noteTripleP;
    private ImageIcon noteTriple;
    private ImageIcon noteTriple3;
    public final Cursor[] cursorWhile;
    public Cursor listenCursor;
    public Cursor arrowCursor;
    public Cursor penCursor;
    public Cursor fingerCursor;
    public Cursor handCursor;
    public Cursor moveCursor;
    public Cursor stretchCursor;
    public Cursor velocityCursor;
    public JToggleButton modePlayButton;
    public JToggleButton modeSelectButton;
    public JToggleButton modeInsertButton;
    public static final int[] controllerChooserList;
    public JComboBox controllerChooser;
    public JComboBox noteMenu;
    public int[] dataAttachedToNotes;
    public boolean attachDataToNotes;
    public boolean singleTrackDisplay;
    public boolean animatePianoRoll;
    public boolean animateKeyboard;
    public long playPosition;
    public long endOfCurrentTrack;
    public long selectionStart;
    public long selectionEnd;
    public long selectionStart0;
    public long selectionEnd0;
    public PianoRollGraph pianoRollGraph;
    public ControllerGraph controllerGraph;
    private Vector noteTracks;
    private Vector[] programTracks;
    private Vector[][] dataTracks;
    public Vector selectedNotes;
    public Vector notesToBeRemoved;
    public Vector notesToBeRestored;
    public Vector selectedData;
    public Vector dataToBeRemoved;
    public Vector dataToBeRestored;
    public Vector notesBeingScrubbed;
    static Vector clipboardNotes;
    static Vector clipboardData;
    static int clipboardTrackNumber;
    static MidiSwing clipboardMidiSwing;
    public double scaleX;
    public double scaleY;
    public static final double defaultScaleX = 38.4;
    public static final double minScaleY = 1.0;
    public static final double defaultScaleY = 6.0;
    public static final double maxScaleY = 14.0;
    public long viewPositionX;
    public long lengthX;
    public int viewPositionY;
    public int lengthY;
    
    public PianoRoll(final MidiWindow midiWindow) {
        this.listenIcon = new ImageIcon(this.getClass().getClassLoader().getResource("images/listen816.gif"));
        this.arrowIcon = new ImageIcon(this.getClass().getClassLoader().getResource("images/arrow816.gif"));
        this.penIcon = new ImageIcon(this.getClass().getClassLoader().getResource("images/pen8162.gif"));
        this.fingerIcon = new ImageIcon(this.getClass().getClassLoader().getResource("images/finger816.gif"));
        this.handIcon = new ImageIcon(this.getClass().getClassLoader().getResource("images/hand.gif"));
        this.listen32Icon = new ImageIcon(this.getClass().getClassLoader().getResource("images/listen32.gif"));
        this.pen32Icon = new ImageIcon(this.getClass().getClassLoader().getResource("images/pen32.gif"));
        this.hand32Icon = new ImageIcon(this.getClass().getClassLoader().getResource("images/hand32.gif"));
        this.noteRondeP = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-ronde-p.png"));
        this.noteRonde = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-ronde.png"));
        this.noteRonde3 = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-ronde-3.png"));
        this.noteBlancheP = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-blanche-p.png"));
        this.noteBlanche = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-blanche.png"));
        this.noteBlanche3 = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-blanche-3.png"));
        this.noteNoireP = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-noire-p.png"));
        this.noteNoire = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-noire.png"));
        this.noteNoire3 = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-noire-3.png"));
        this.noteCrocheP = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-croche-p.png"));
        this.noteCroche = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-croche.png"));
        this.noteCroche3 = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-croche-3.png"));
        this.noteDoubleP = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-double-p.png"));
        this.noteDouble = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-double.png"));
        this.noteDouble3 = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-double-3.png"));
        this.noteTripleP = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-triple-p.png"));
        this.noteTriple = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-triple.png"));
        this.noteTriple3 = new ImageIcon(this.getClass().getClassLoader().getResource("images/note-triple-3.png"));
        this.cursorWhile = new Cursor[13];
        this.dataAttachedToNotes = new int[] { 2, 4, 3, 10, 5 };
        this.animatePianoRoll = true;
        this.animateKeyboard = true;
        this.notesBeingScrubbed = new Vector();
        this.midiWindow = midiWindow;
        this.currentGraph = 1;
        this.mode = 1;
        this.mode2 = 1;
        this.controllerType = 0;
        this.playPosition = 0L;
        this.endOfCurrentTrack = 1920L;
        this.singleTrackDisplay = false;
        this.attachDataToNotes = true;
        this.selectionStart = 0L;
        this.selectionEnd = 0L;
        this.selectionStart0 = 0L;
        this.selectionEnd0 = 0L;
        if (Toolkit.getDefaultToolkit().getBestCursorSize(32, 32).width == 32) {
            this.listenCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.listen32Icon.getImage(), new Point(7, 22), "listen");
            this.penCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.pen32Icon.getImage(), new Point(0, 31), "pen");
            this.fingerCursor = new Cursor(12);
            this.handCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.hand32Icon.getImage(), new Point(7, 22), "hand");
        }
        else {
            this.listenCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.listenIcon.getImage(), new Point(7, 7), "listen");
            this.penCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.penIcon.getImage(), new Point(0, 15), "pen");
            this.fingerCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.fingerIcon.getImage(), new Point(6, 0), "finger");
            this.handCursor = Toolkit.getDefaultToolkit().createCustomCursor(this.handIcon.getImage(), new Point(7, 7), "hand");
        }
        this.arrowCursor = new Cursor(0);
        this.moveCursor = new Cursor(13);
        this.stretchCursor = new Cursor(11);
        this.velocityCursor = new Cursor(8);
        this.cursorWhile[1] = this.listenCursor;
        this.cursorWhile[2] = this.arrowCursor;
        this.cursorWhile[4] = this.penCursor;
        this.cursorWhile[3] = this.arrowCursor;
        this.cursorWhile[5] = this.penCursor;
        this.cursorWhile[6] = this.stretchCursor;
        this.cursorWhile[7] = this.stretchCursor;
        this.cursorWhile[8] = this.stretchCursor;
        this.cursorWhile[9] = this.stretchCursor;
        this.cursorWhile[10] = this.stretchCursor;
        this.cursorWhile[11] = this.arrowCursor;
        this.cursorWhile[12] = this.arrowCursor;
        this.noteTracks = new Vector();
        this.programTracks = new Vector[16];
        this.dataTracks = new Vector[16][11];
        for (int i = 0; i < 16; ++i) {
            this.programTracks[i] = new Vector();
            for (int j = 0; j < this.dataTracks[i].length; ++j) {
                this.dataTracks[i][j] = new Vector();
            }
        }
        this.selectedNotes = new Vector();
        this.notesToBeRemoved = new Vector();
        this.notesToBeRestored = new Vector();
        this.selectedData = new Vector();
        this.dataToBeRemoved = new Vector();
        this.dataToBeRestored = new Vector();
        this.scaleX = 38.4;
        this.scaleY = 6.0;
        this.viewPositionX = 0L;
        this.viewPositionY = 35;
        this.lengthX = 0L;
        this.lengthY = 127;
        this.setFocusable(false);
        (this.scrollBarX = new JScrollBar(0)).addAdjustmentListener(new AdjustmentListener() {
            public void adjustmentValueChanged(final AdjustmentEvent adjustmentEvent) {
                PianoRoll.this.viewPositionX = Math.round(PianoRoll.this.scrollBarX.getValue() * PianoRoll.this.getResolution() / PianoRoll.this.scaleX);
                PianoRoll.this.pianoRollGraph.repaint();
                PianoRoll.this.controllerGraph.repaint();
            }
        });
        (this.scrollBarY = new JScrollBar(1)).setMaximum((int)Math.floor(this.lengthY * this.scaleY));
        this.scrollBarY.setValue((int)Math.floor(this.viewPositionY * this.scaleY));
        this.scrollBarY.addAdjustmentListener(new AdjustmentListener() {
            public void adjustmentValueChanged(final AdjustmentEvent adjustmentEvent) {
                PianoRoll.this.viewPositionY = (int)Math.floor(PianoRoll.this.scrollBarY.getValue() / PianoRoll.this.scaleY);
                PianoRoll.this.pianoRollGraph.repaint();
            }
        });
        (this.sliderX = new JSlider(0)).setPaintTicks(true);
        this.sliderX.setFocusable(false);
        this.sliderX.addChangeListener(new ChangeListener() {
            public void stateChanged(final ChangeEvent changeEvent) {
                final double n = PianoRoll.this.sliderX.getValue();
                final double n2 = 50.0;
                final double n3 = 100.0;
                final double n4 = 38.4;
                final double n5 = 230.39999999999998;
                final double min = Math.min(PianoRoll.this.midiWindow.getWidth() * 400.0 / PianoRoll.this.midiWindow.midiSwing.getSequenceLength(), n4);
                if (n > n2) {
                    PianoRoll.this.scaleX = n5 * (n - n2) / (n3 - n2) + n4 * (n - n3) / (n2 - n3);
                }
                else {
                    PianoRoll.this.scaleX = min * (n - n2) / (0.0 - n2) + n4 * (n / n2);
                }
                PianoRoll.this.pianoRollGraph.repaint();
                PianoRoll.this.controllerGraph.repaint();
                PianoRoll.this.updateScrollBarX();
                PianoRoll.this.scrollBarX.repaint();
            }
        });
        (this.sliderY = new JSlider(1, 0, 100, 61)).setPaintTicks(true);
        this.sliderY.setFocusable(false);
        this.sliderY.addChangeListener(new ChangeListener() {
            public void stateChanged(final ChangeEvent changeEvent) {
                PianoRoll.this.scaleY = 14.0 - 13.0 * PianoRoll.this.sliderY.getValue() / 100.0;
                PianoRoll.this.pianoRollGraph.repaint();
                PianoRoll.this.updateScrollBarY();
                PianoRoll.this.scrollBarY.repaint();
            }
        });
        (this.controllerChooser = new JComboBox()).setMaximumRowCount(20);
        this.controllerChooser.setFocusable(false);
        for (int k = 0; k < PianoRoll.controllerChooserList.length; ++k) {
            this.controllerChooser.addItem(MidiConstants.getDataName(PianoRoll.controllerChooserList[k]));
        }
        this.controllerChooser.addPopupMenuListener(new PopupMenuListener() {
            public void popupMenuWillBecomeInvisible(final PopupMenuEvent popupMenuEvent) {
                PianoRoll.this.selectController(PianoRoll.this.controllerChooser.getSelectedIndex());
            }
            
            public void popupMenuWillBecomeVisible(final PopupMenuEvent popupMenuEvent) {
            }
            
            public void popupMenuCanceled(final PopupMenuEvent popupMenuEvent) {
            }
        });
        this.modePlayButton = new JToggleButton(this.listenIcon);
        this.modeSelectButton = new JToggleButton(this.arrowIcon);
        this.modeInsertButton = new JToggleButton(this.penIcon);
        this.modePlayButton.setPreferredSize(new Dimension(32, 32));
        this.modeSelectButton.setPreferredSize(new Dimension(32, 32));
        this.modeInsertButton.setPreferredSize(new Dimension(32, 32));
        this.modePlayButton.setFocusable(false);
        this.modeSelectButton.setFocusable(false);
        this.modeInsertButton.setFocusable(false);
        this.modePlayButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                PianoRoll.this.mode = 1;
                PianoRoll.this.mode2 = 1;
                PianoRoll.this.rememberMode = 0;
                PianoRoll.this.updateModeButtons();
            }
        });
        this.modeSelectButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                PianoRoll.this.mode = 2;
                PianoRoll.this.mode2 = 2;
                PianoRoll.this.rememberMode = 0;
                PianoRoll.this.updateModeButtons();
            }
        });
        this.modeInsertButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                PianoRoll.this.mode = 4;
                PianoRoll.this.mode2 = 4;
                PianoRoll.this.rememberMode = 0;
                PianoRoll.this.updateModeButtons();
            }
        });
        (this.noteMenu = new JComboBox()).setFocusable(false);
        this.noteMenu.setMaximumRowCount(32);
        final ComboBoxRenderer renderer = new ComboBoxRenderer();
        renderer.setPreferredSize(new Dimension(16, 24));
        this.noteMenu.setRenderer(renderer);
        this.noteMenu.addItem(this.noteRondeP);
        this.noteMenu.addItem(this.noteRonde);
        this.noteMenu.addItem(this.noteRonde3);
        this.noteMenu.addItem(this.noteBlancheP);
        this.noteMenu.addItem(this.noteBlanche);
        this.noteMenu.addItem(this.noteBlanche3);
        this.noteMenu.addItem(this.noteNoireP);
        this.noteMenu.addItem(this.noteNoire);
        this.noteMenu.addItem(this.noteNoire3);
        this.noteMenu.addItem(this.noteCrocheP);
        this.noteMenu.addItem(this.noteCroche);
        this.noteMenu.addItem(this.noteCroche3);
        this.noteMenu.addItem(this.noteDoubleP);
        this.noteMenu.addItem(this.noteDouble);
        this.noteMenu.addItem(this.noteDouble3);
        this.noteMenu.addItem(this.noteTripleP);
        this.noteMenu.addItem(this.noteTriple);
        this.noteMenu.addItem(this.noteTriple3);
        this.selectNoteDuration(7);
        this.noteMenu.addPopupMenuListener(new PopupMenuListener() {
            public void popupMenuWillBecomeInvisible(final PopupMenuEvent popupMenuEvent) {
                PianoRoll.this.selectNoteDuration(PianoRoll.this.noteMenu.getSelectedIndex());
            }
            
            public void popupMenuWillBecomeVisible(final PopupMenuEvent popupMenuEvent) {
            }
            
            public void popupMenuCanceled(final PopupMenuEvent popupMenuEvent) {
            }
        });
        final JPanel panel = new JPanel();
        panel.setFocusable(false);
        panel.add(this.sliderX);
        panel.add(this.controllerChooser);
        panel.add(this.modePlayButton);
        panel.add(this.modeSelectButton);
        panel.add(this.modeInsertButton);
        panel.add(this.noteMenu);
        this.pianoRollGraph = new PianoRollGraph(this);
        this.controllerGraph = new ControllerGraph(this);
        (this.splitPane = new JSplitPane(0, this.pianoRollGraph, this.controllerGraph)).setContinuousLayout(true);
        this.splitPane.setOneTouchExpandable(true);
        this.splitPane.setDividerLocation(this.midiWindow.midiSwing.dividerLocation);
        final JPanel panel2 = new JPanel();
        panel2.setLayout(new GridBagLayout());
        final GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.fill = 1;
        panel2.add(this.splitPane, gridBagConstraints);
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.fill = 3;
        panel2.add(this.scrollBarY, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.fill = 2;
        panel2.add(this.scrollBarX, gridBagConstraints);
        this.setLayout(new GridBagLayout());
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = 17;
        this.add(panel, gridBagConstraints);
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        this.add(this.sliderY, gridBagConstraints);
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = 1;
        this.add(panel2, gridBagConstraints);
        this.updateModeButtons();
        this.updateScrollBarX();
        this.updateScrollBarY();
    }
    
    public void selectNoteDuration(final int selectedIndex) {
        long noteDuration = 0L;
        switch (selectedIndex) {
            case 0: {
                noteDuration = 2880L;
                break;
            }
            case 1: {
                noteDuration = 1920L;
                break;
            }
            case 2: {
                noteDuration = 1440L;
                break;
            }
            case 3: {
                noteDuration = 1440L;
                break;
            }
            case 4: {
                noteDuration = 960L;
                break;
            }
            case 5: {
                noteDuration = 720L;
                break;
            }
            case 6: {
                noteDuration = 720L;
                break;
            }
            case 7: {
                noteDuration = 480L;
                break;
            }
            case 8: {
                noteDuration = 320L;
                break;
            }
            case 9: {
                noteDuration = 360L;
                break;
            }
            case 10: {
                noteDuration = 240L;
                break;
            }
            case 11: {
                noteDuration = 160L;
                break;
            }
            case 12: {
                noteDuration = 180L;
                break;
            }
            case 13: {
                noteDuration = 120L;
                break;
            }
            case 14: {
                noteDuration = 80L;
                break;
            }
            case 15: {
                noteDuration = 90L;
                break;
            }
            case 16: {
                noteDuration = 60L;
                break;
            }
            case 17: {
                noteDuration = 40L;
                break;
            }
        }
        this.midiWindow.midiSwing.noteDuration = noteDuration;
        this.noteMenu.setSelectedIndex(selectedIndex);
        this.noteMenu.repaint();
    }
    
    public void selectController(final int n) {
        this.controllerType = n;
        this.controllerChooser.setSelectedIndex(n);
        this.updateModeButtons();
        this.pianoRollGraph.repaint();
        this.controllerGraph.repaint();
    }
    
    public void nextController() {
        this.selectController(Math.min(this.controllerChooser.getItemCount() - 1, this.controllerType + 1));
    }
    
    public void previousController() {
        this.selectController(Math.max(0, this.controllerType - 1));
    }
    
    public int getControllerNumberForDataType(final int n) {
        int n2 = -1;
        for (int i = 0; i < PianoRoll.controllerChooserList.length; ++i) {
            if (PianoRoll.controllerChooserList[i] == n) {
                n2 = i;
            }
        }
        return n2;
    }
    
    public int getResolution() {
        return this.midiWindow.getResolution();
    }
    
    public void animatePianoRoll() {
        if (this.animatePianoRoll) {
            this.animatePianoRoll = false;
            this.midiWindow.pianoRollMenuItem.setSelected(false);
        }
        else {
            this.animatePianoRoll = true;
            this.midiWindow.pianoRollMenuItem.setSelected(true);
        }
    }
    
    public void animateKeyboard() {
        if (this.animateKeyboard) {
            this.animateKeyboard = false;
            this.midiWindow.keyboardMenuItem.setSelected(false);
        }
        else {
            this.animateKeyboard = true;
            this.midiWindow.keyboardMenuItem.setSelected(true);
        }
    }
    
    public void removeAllTracks() {
        this.noteTracks.removeAllElements();
        for (int i = 0; i < 16; ++i) {
            this.programTracks[i].removeAllElements();
            for (int j = 0; j < this.dataTracks[i].length; ++j) {
                this.dataTracks[i][j].removeAllElements();
            }
        }
    }
    
    public void deleteTrack(final int n) {
        this.noteTracks.removeElementAt(n);
        for (int i = 0; i < 16; ++i) {
            this.programTracks[i].removeElementAt(n);
            for (int j = 0; j < this.dataTracks[i].length; ++j) {
                this.dataTracks[i][j].removeElementAt(n);
            }
        }
    }
    
    public void renameTrack() {
    }
    
    public void addNewTrack() {
        this.noteTracks.add(new Vector<Vector>());
        for (int i = 0; i < 16; ++i) {
            this.programTracks[i].add(new Vector<Vector<Vector<Vector>>>());
            for (int j = 0; j < this.dataTracks[i].length; ++j) {
                this.dataTracks[i][j].add(new Vector<Vector<Vector>>());
            }
        }
    }
    
    public void insertNewTrack(final int n) {
        final MidiSwing midiSwing = this.midiWindow.midiSwing;
        for (int i = n; i < midiSwing.numberOfTracks; ++i) {
            for (int j = 0; j < this.getNumberOfNotesInTrack(i); ++j) {
                this.getNote(i, j).track = i + 1;
            }
            for (int k = 0; k < 16; ++k) {
                for (int l = 0; l < this.programTracks[k].get(i).size(); ++l) {
                    System.out.println("size =" + this.programTracks[k].size());
                    this.getProgram(i, k, l).trackNumber = i + 1;
                }
                for (int n2 = 0; n2 < this.dataTracks[k].length; ++n2) {
                    for (int n3 = 0; n3 < this.dataTracks[k][n2].get(i).size(); ++n3) {
                        this.getData(i, k, n2, n3).trackNumber = i + 1;
                    }
                }
            }
        }
        this.noteTracks.insertElementAt(new Vector<Vector>(), n);
        for (int n4 = 0; n4 < 16; ++n4) {
            this.programTracks[n4].insertElementAt(new Vector<Vector<Vector<Vector>>>(), n);
            for (int n5 = 0; n5 < this.dataTracks[n4].length; ++n5) {
                this.dataTracks[n4][n5].insertElementAt(new Vector<Vector<Vector>>(), n);
            }
        }
    }
    
    void singleTrackDisplay() {
        if (this.singleTrackDisplay) {
            this.singleTrackDisplay = false;
            this.midiWindow.singleTrackDisplayMenuItem.setSelected(false);
        }
        else {
            this.singleTrackDisplay = true;
            this.midiWindow.singleTrackDisplayMenuItem.setSelected(true);
        }
        this.pianoRollGraph.repaint();
        this.controllerGraph.repaint();
    }
    
    public void addProgram(final int n, final int n2, final Program program) {
        this.programTracks[n2].get(n).add(program);
    }
    
    public Program getProgram(final int n, final int n2, final int n3) {
        return this.programTracks[n2].get(n).get(n3);
    }
    
    public Program getProgramAtTime(final int n, final long n2) {
        int numberOfProgramsIn = -1;
        final int trackWhoseMainChannelIs = this.midiWindow.midiSwing.trackWhoseMainChannelIs(n);
        if (n != -1 && trackWhoseMainChannelIs != -1) {
            numberOfProgramsIn = this.getNumberOfProgramsIn(trackWhoseMainChannelIs, n);
        }
        Program program = null;
        for (int n3 = numberOfProgramsIn - 1; n3 >= 0 && program == null; --n3) {
            final Program program2 = this.getProgram(trackWhoseMainChannelIs, n, n3);
            if (program2.getTimestamp() <= n2) {
                program = program2;
            }
        }
        return program;
    }
    
    public void removeProgram(final Program program) {
        this.removeProgram(program.trackNumber, program.channelNumber, program);
    }
    
    public void removeProgram(final int n, final int n2, final Program program) {
        final Vector vector = this.programTracks[n2].get(n);
        if (program.programEvent != null) {
            this.midiWindow.midiSwing.getTrack(program.trackNumber).remove(program.programEvent);
        }
        if (program.bankEvent != null) {
            this.midiWindow.midiSwing.getTrack(program.trackNumber).remove(program.bankEvent);
        }
        vector.remove(program);
    }
    
    public void insertProgram(final int n, final int n2, final Program program) {
        final Vector<Program> vector = this.programTracks[n2].get(n);
        boolean b = false;
        for (int i = vector.size() - 1; i > -1; --i) {
            if (program.getTimestamp() >= vector.get(i).getTimestamp()) {
                vector.insertElementAt(program, i + 1);
                i = -1;
                b = true;
            }
        }
        if (!b) {
            vector.insertElementAt(program, 0);
        }
    }
    
    public int getNumberOfProgramsIn(final int n, final int n2) {
        int size = -1;
        if (n > -1) {
            size = this.programTracks[n2].get(n).size();
        }
        return size;
    }
    
    public void alterProgram(final Program program) {
        if (this.midiWindow.midiSwing.isPlaying()) {
            this.midiWindow.midiSwing.stop();
        }
        final MidiEvent programEvent = program.programEvent;
        final MidiEvent bankEvent = program.bankEvent;
        final int bank = program.getBank();
        if (programEvent != null) {
            this.midiWindow.midiSwing.getTrack(program.trackNumber).remove(programEvent);
        }
        if (bankEvent != null) {
            this.midiWindow.midiSwing.getTrack(program.trackNumber).remove(bankEvent);
        }
        final ShortMessage shortMessage = new ShortMessage();
        final ShortMessage shortMessage2 = new ShortMessage();
        try {
            shortMessage.setMessage(192, program.getChannel(), program.getProgram(), 0);
            if (bank >= 0 && bank < 128) {
                shortMessage2.setMessage(176, program.getChannel(), 0, bank);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        if (bank >= 0 && bank < 128) {
            final MidiEvent bankEvent2 = new MidiEvent(shortMessage2, program.getTimestamp());
            this.midiWindow.midiSwing.getTrack(program.trackNumber).add(bankEvent2);
            program.bankEvent = bankEvent2;
        }
        else {
            program.bankEvent = null;
        }
        final MidiEvent programEvent2 = new MidiEvent(shortMessage, program.getTimestamp());
        this.midiWindow.midiSwing.getTrack(program.trackNumber).add(programEvent2);
        program.programEvent = programEvent2;
        this.midiWindow.midiSwing.modification();
    }
    
    public void attachDataToNotes() {
        if (this.attachDataToNotes) {
            this.attachDataToNotes = false;
            this.midiWindow.attachDataToNotesMenuItem.setSelected(false);
            this.emptyDataSelection();
        }
        else {
            this.attachDataToNotes = true;
            this.midiWindow.attachDataToNotesMenuItem.setSelected(true);
        }
        this.pianoRollGraph.repaint();
        this.controllerGraph.repaint();
    }
    
    public void addData(final Data data) {
        this.addData(data.trackNumber, data.channelNumber, data.dataType, data);
    }
    
    public void addData(final int n, final int n2, final int n3, final Data data) {
        this.dataTracks[n2][n3].get(n).add(data);
    }
    
    public Data getData(final int n, final int n2, final int n3, final int n4) {
        return this.dataTracks[n2][n3].get(n).get(n4);
    }
    
    public Data getDataAtTime(final int n, final int n2, final int n3, final long n4) {
        int numberOfDataIn = -1;
        if (n3 != -1) {
            numberOfDataIn = this.getNumberOfDataIn(n2, n3, n);
        }
        Data data = null;
        for (int n5 = numberOfDataIn - 1; n5 >= 0 && data == null; --n5) {
            final Data data2 = this.getData(n2, n3, n, n5);
            if (data2.getTimestamp() <= n4) {
                data = data2;
            }
        }
        return data;
    }
    
    public void removeData(final Data data) {
        this.removeData(data.trackNumber, data.channelNumber, data.dataType, data);
    }
    
    public void removeData(final int n, final int n2, final int n3, final Data data) {
        final Vector vector = this.dataTracks[n2][n3].get(n);
        if (data.beginningEvent != null) {
            this.midiWindow.midiSwing.getTrack(data.trackNumber).remove(data.beginningEvent);
        }
        vector.remove(data);
    }
    
    public void deleteData(final Data data) {
        this.removeData(data);
        this.midiWindow.midiSwing.getTrack(data.trackNumber).remove(data.beginningEvent);
    }
    
    public void removeDataInTheRange(final int n, final int n2, final int n3, final long n4, final long n5) {
        for (int n6 = this.getNumberOfDataIn(n, n2, n3) - 1, n7 = 1; n7 != 0 && n6 >= 0; --n6) {
            final Data data = this.getData(n, n2, n3, n6);
            if (data.getTimestamp() < Math.min(n4, n5)) {
                n7 = 0;
            }
            else if (data.getTimestamp() <= Math.max(n4, n5)) {
                this.removeData(data);
            }
        }
    }
    
    public void insertData(final int n, final int n2, final int n3, final Data data) {
        final Vector<Data> vector = this.dataTracks[n2][n3].get(n);
        boolean b = false;
        for (int i = vector.size() - 1; i > -1; --i) {
            if (data.getTimestamp() >= vector.get(i).getTimestamp()) {
                vector.insertElementAt(data, i + 1);
                i = -1;
                b = true;
            }
        }
        if (!b) {
            vector.insertElementAt(data, 0);
        }
        this.dataToBeRemoved.add(data);
    }
    
    public int getNumberOfDataIn(final int n, final int n2, final int n3) {
        return this.dataTracks[n2][n3].get(n).size();
    }
    
    public void alterData(final Data data) {
        if (this.midiWindow.midiSwing.isPlaying()) {
            this.midiWindow.midiSwing.stop();
        }
        MidiMessage midiMessage = null;
        final MidiEvent beginningEvent = data.beginningEvent;
        if (beginningEvent != null) {
            this.midiWindow.midiSwing.getTrack(data.trackNumber).remove(beginningEvent);
        }
        try {
            switch (data.dataType) {
                case 4: {
                    midiMessage = new ShortMessage();
                    ((ShortMessage)midiMessage).setMessage(176, data.channelNumber, 10, data.getIntValue());
                    break;
                }
                case 2: {
                    midiMessage = new ShortMessage();
                    ((ShortMessage)midiMessage).setMessage(176, data.channelNumber, 7, data.getIntValue());
                    break;
                }
                case 5: {
                    midiMessage = new ShortMessage();
                    ((ShortMessage)midiMessage).setMessage(176, data.channelNumber, 91, data.getIntValue());
                    break;
                }
                case 10: {
                    midiMessage = new ShortMessage();
                    ((ShortMessage)midiMessage).setMessage(176, data.channelNumber, 64, data.getIntValue());
                    break;
                }
                case 3: {
                    midiMessage = new ShortMessage();
                    ((ShortMessage)midiMessage).setMessage(224, data.channelNumber, 0, data.getIntValue());
                    break;
                }
                case 6: {
                    midiMessage = new MetaMessage();
                    final byte[] array = { (byte)(data.getIntValue() / 65536), 0, 0 };
                    array[1] = (byte)((data.getIntValue() - 65536 * array[0]) / 256);
                    array[2] = (byte)(data.getIntValue() - 65536 * array[0] - 256 * array[1]);
                    ((MetaMessage)midiMessage).setMessage(81, array, 3);
                    break;
                }
                case 7: {
                    midiMessage = new MetaMessage();
                    final int[] array2 = (int[])data.getValue();
                    final byte[] array3 = { (byte)array2[0], (byte)array2[1], (byte)array2[2], (byte)array2[3] };
                    ((MetaMessage)midiMessage).setMessage(88, array3, array3.length);
                    break;
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        if (midiMessage != null) {
            final MidiEvent beginningEvent2 = new MidiEvent(midiMessage, data.getTimestamp());
            this.midiWindow.midiSwing.getTrack(data.trackNumber).add(beginningEvent2);
            data.beginningEvent = beginningEvent2;
        }
    }
    
    public void addDataToSelection(final Data data) {
        if (!this.selectedData.contains(data)) {
            this.selectedData.add(data);
            data.selected = true;
        }
    }
    
    public void removeDataFromSelection(final Data data) {
        data.selected = false;
        this.selectedData.removeElement(data);
    }
    
    public Data getSelectedData(final int n) {
        return this.selectedData.elementAt(n);
    }
    
    public int getNumberOfNotesInTrack(final int n) {
        return this.noteTracks.get(n).size();
    }
    
    public void addNote(final int n, final Note note) {
        int i = this.getNumberOfNotesInTrack(n) - 1;
        if (i == -1) {
            this.noteTracks.get(n).add(note);
        }
        else {
            while (i > -1) {
                if (this.getNote(n, i).start <= note.start) {
                    this.noteTracks.get(n).insertElementAt(note, i + 1);
                    i = -1;
                }
                else {
                    if (i == 0) {
                        this.noteTracks.get(n).insertElementAt(note, 0);
                    }
                    --i;
                }
            }
        }
        this.notesToBeRemoved.add(note);
    }
    
    public Note getNote(final int n, final int n2) {
        return this.noteTracks.get(n).get(n2);
    }
    
    public void removeNote(final Note note) {
        this.noteTracks.get(note.track).remove(note);
    }
    
    public void deleteNote(final Note note) {
        this.removeNote(note);
        this.midiWindow.midiSwing.getTrack(note.track).remove(note.beginningEvent);
        this.midiWindow.midiSwing.getTrack(note.track).remove(note.endingEvent);
        if (note.lyric != null) {
            this.midiWindow.midiSwing.getTrack(note.lyric.trackNumber).remove(note.lyric.event);
        }
    }
    
    public void addNoteToSelection(final Note note) {
        if (!this.selectedNotes.contains(note)) {
            this.selectedNotes.add(note);
            note.selected = true;
        }
    }
    
    public void removeNoteFromSelection(final Note note) {
        note.selected = false;
        this.selectedNotes.removeElement(note);
    }
    
    public Note getSelectedNote(final int n) {
        return this.selectedNotes.elementAt(n);
    }
    
    public boolean anyNoteSelected() {
        return this.selectedNotes.size() != 0;
    }
    
    public void changeNoteProperties(final Note note) {
        final MidiSwing midiSwing = this.midiWindow.midiSwing;
        final JTextField textField = new JTextField("" + note.velocity);
        String text = "";
        if (note.lyric != null) {
            text = note.lyric.text;
        }
        final JTextField textField2 = new JTextField("" + text);
        final int showConfirmDialog = JOptionPane.showConfirmDialog(this.midiWindow, new Object[] { MidiSwing.resource.getString("NOTE_VELOCITY_LABEL"), textField, MidiSwing.resource.getString("LYRIC"), textField2 });
        this.midiWindow.requestFocus();
        if (showConfirmDialog == 0) {
            if (textField.getText() != "") {
                note.velocity = Integer.parseInt(textField.getText());
            }
            if (note.lyric != null) {
                note.lyric.text = textField2.getText();
            }
            else if (textField2.getText() != "") {
                final Lyric addLyric = this.midiWindow.midiSwing.addLyric(note.track, textField2.getText(), null);
                if (this.midiWindow.midiSwing.lyricsTrackNumber == -1) {
                    this.midiWindow.midiSwing.newLyric();
                    this.midiWindow.midiSwing.assignLyricsInfo();
                }
                addLyric.trackNumber = this.midiWindow.midiSwing.lyricsTrackNumber;
                note.lyric = addLyric;
            }
            this.alterSelection(0L, 0, 1.0, 1.0);
        }
    }
    
    public void selectAll() {
        this.emptySelection();
        final int currentTrack = this.midiWindow.midiSwing.currentTrack;
        for (int i = 0; i < this.midiWindow.midiSwing.getNumberOfTracks(); ++i) {
            if (i == currentTrack || !this.singleTrackDisplay) {
                for (int j = 0; j < this.getNumberOfNotesInTrack(i); ++j) {
                    final Note note = this.getNote(i, j);
                    if (this.midiWindow.channelButton[note.channel].isSelected()) {
                        this.addNoteToSelection(note);
                    }
                }
            }
        }
        this.selectDataUnderSelectedNotes();
        this.pianoRollGraph.repaint();
    }
    
    public void selectDataUnderSelectedNotes() {
        if (this.attachDataToNotes) {
            this.emptyDataSelection();
            this.selectedData = this.findDataUnderSelectedNotes(false);
            for (int i = 0; i < this.selectedData.size(); ++i) {
                ((Data)this.selectedData.get(i)).selected = true;
            }
            this.controllerGraph.repaint();
        }
    }
    
    public void emptyDataSelection() {
        for (int i = 0; i < this.selectedData.size(); ++i) {
            ((Data)this.selectedData.get(i)).selected = false;
        }
        this.selectedData.removeAllElements();
    }
    
    public void emptyNoteSelection() {
        for (int i = 0; i < this.selectedNotes.size(); ++i) {
            ((Note)this.selectedNotes.get(i)).selected = false;
        }
        this.selectedNotes.removeAllElements();
    }
    
    public void emptySelection() {
        this.emptyNoteSelection();
        this.emptyDataSelection();
    }
    
    public void deleteSelection() {
        this.notesToBeRemoved.removeAllElements();
        this.notesToBeRestored.removeAllElements();
        if (this.selectionStart == this.selectionEnd) {
            for (int i = 0; i < this.selectedNotes.size(); ++i) {
                final Note note = this.selectedNotes.get(i);
                this.notesToBeRestored.add(note.copy());
                this.deleteNote(note);
            }
            this.emptySelection();
        }
        if (this.selectionStart != this.selectionEnd) {
            this.emptySelection();
            final Vector<Note> vector = new Vector<Note>();
            final int currentTrack = this.midiWindow.midiSwing.currentTrack;
            for (int j = 0; j < this.midiWindow.midiSwing.getNumberOfTracks(); ++j) {
                for (int k = 0; k < this.getNumberOfNotesInTrack(j); ++k) {
                    final Note note2 = this.getNote(j, k);
                    final long start = note2.start;
                    final long end = note2.end;
                    if (start < this.selectionStart && end > this.selectionStart) {
                        System.out.println(this.selectionStart + " " + this.selectionEnd + " " + start + " " + end);
                        this.notesToBeRestored.add(note2.copy());
                        note2.end = this.selectionStart;
                        this.addNoteToSelection(note2);
                        this.notesToBeRemoved.add(note2);
                    }
                    if (start >= this.selectionStart && start < this.selectionEnd) {
                        this.notesToBeRestored.add(note2.copy());
                        vector.add(note2);
                    }
                    else if (start >= this.selectionEnd) {
                        this.notesToBeRestored.add(note2.copy());
                        note2.start -= this.selectionEnd - this.selectionStart;
                        note2.end -= this.selectionEnd - this.selectionStart;
                        this.addNoteToSelection(note2);
                        this.notesToBeRemoved.add(note2);
                    }
                }
            }
            for (int l = 0; l < vector.size(); ++l) {
                this.deleteNote(vector.get(l));
            }
            this.alterSelection(0L, 0, 1.0, 1.0);
            this.selectionEnd = this.selectionStart;
        }
        this.pianoRollGraph.repaint();
        this.midiWindow.midiSwing.modification();
    }
    
    public void cutSelection() {
        this.copySelection();
        this.deleteSelection();
    }
    
    public void copySelection() {
        PianoRoll.clipboardTrackNumber = this.midiWindow.midiSwing.currentTrack;
        PianoRoll.clipboardMidiSwing = this.midiWindow.midiSwing;
        PianoRoll.clipboardNotes.removeAllElements();
        long n = this.midiWindow.midiSwing.getSequenceLength();
        for (int i = 0; i < this.selectedNotes.size(); ++i) {
            final Note note = this.selectedNotes.get(i);
            if (note.start < n) {
                n = note.start;
            }
        }
        for (int j = 0; j < this.selectedNotes.size(); ++j) {
            final Note copy = this.selectedNotes.get(j).copy();
            copy.start -= n;
            copy.end -= n;
            PianoRoll.clipboardNotes.add(copy);
        }
        this.pianoRollGraph.repaint();
        if (this.attachDataToNotes) {
            PianoRoll.clipboardData.removeAllElements();
            for (int k = 0; k < this.selectedData.size(); ++k) {
                final Data copy2 = this.selectedData.get(k).copy();
                copy2.start -= n;
                PianoRoll.clipboardData.add(copy2);
            }
            this.controllerGraph.repaint();
        }
    }
    
    public Vector findDataUnderSelectedNotes(final boolean b) {
        final MidiSwing midiSwing = this.midiWindow.midiSwing;
        final Vector<Data> vector = new Vector<Data>();
        for (int i = 0; i < 16; ++i) {
            long n = midiSwing.getSequenceLength();
            long end = 0L;
            for (int j = 0; j < this.selectedNotes.size(); ++j) {
                final Note note = this.selectedNotes.get(j);
                if (note.channel == i && note.start <= n) {
                    n = note.start;
                }
                if (note.channel == i && note.end >= end) {
                    end = note.end;
                }
            }
            for (int k = 0; k < midiSwing.getNumberOfTracks(); ++k) {
                if (k == midiSwing.currentTrack || !this.singleTrackDisplay) {
                    for (int l = 0; l < this.dataAttachedToNotes.length; ++l) {
                        for (int n2 = this.dataAttachedToNotes[l], n3 = 0; n3 < this.getNumberOfDataIn(k, i, n2); ++n3) {
                            final Data data = this.getData(k, i, n2, n3);
                            if (this.midiWindow.channelButton[i].isSelected() && data.start <= end && data.start >= n && data.selected == b) {
                                vector.add(data);
                            }
                        }
                    }
                }
            }
        }
        return vector;
    }
    
    public void emptyBackUp() {
        this.notesToBeRemoved.removeAllElements();
        this.notesToBeRestored.removeAllElements();
        this.dataToBeRemoved.removeAllElements();
        this.dataToBeRestored.removeAllElements();
    }
    
    public void quantizeSelection() {
        this.emptyBackUp();
        if (this.selectedNotes.size() > 0) {
            final Data dataAtTime = this.getDataAtTime(7, 0, 0, this.selectedNotes.get(0).start);
            final long timestamp = dataAtTime.getTimestamp();
            final int n = this.getResolution() / (1 << ((int[])dataAtTime.getValue())[1] - 2);
            for (int i = 0; i < this.selectedNotes.size(); ++i) {
                final Note note = this.selectedNotes.get(i);
                this.notesToBeRestored.add(note.copy());
                final long n2 = note.start - timestamp;
                int n3 = n;
                if (this.scaleX > 134.4) {
                    n3 = n / 8;
                }
                else if (this.scaleX > 107.52) {
                    n3 = n / 6;
                }
                else if (this.scaleX > 72.96) {
                    n3 = n / 4;
                }
                else if (this.scaleX > 53.76) {
                    n3 = n / 3;
                }
                else if (this.scaleX > 42.24) {
                    n3 = n / 2;
                }
                else if (this.scaleX > 19.2) {
                    n3 = n;
                }
                note.start = timestamp + Math.round(n2 / (n3 + 0.0)) * n3;
                note.end = note.end + Math.round(n2 / (n3 + 0.0)) * n3 - n2;
                this.notesToBeRemoved.add(note);
            }
            this.alterSelection(0L, 0, 1.0, 1.0);
        }
    }
    
    public void alterSelection(final long n, final int n2, final double n3, final double n4) {
        final MidiSwing midiSwing = this.midiWindow.midiSwing;
        if (midiSwing.isPlaying()) {
            midiSwing.stop();
        }
        if (n != 0L || n2 != 0 || n3 != 1.0 || n4 != 1.0 || this.selectionEnd0 != this.selectionEnd || this.selectionStart0 != this.selectionStart) {
            this.emptyBackUp();
        }
        for (int i = 0; i < this.selectedNotes.size(); ++i) {
            final Note note = this.selectedNotes.get(i);
            if (n != 0L || n2 != 0 || n3 != 1.0 || n4 != 1.0 || this.selectionEnd0 != this.selectionEnd || this.selectionStart0 != this.selectionStart) {
                this.notesToBeRemoved.add(note);
                this.notesToBeRestored.add(note.copy());
            }
            if (this.midiWindow.altKey && this.selectionEnd != this.selectionStart && (this.selectionEnd0 != this.selectionEnd || this.selectionStart0 != this.selectionStart)) {
                final long start = this.selectionStart + (long)Math.floor((note.start - this.selectionStart0) * (this.selectionEnd - this.selectionStart + 0.0) / (this.selectionEnd0 - this.selectionStart0));
                final long end = this.selectionStart + (long)Math.floor((note.end - this.selectionStart0) * (this.selectionEnd - this.selectionStart + 0.0) / (this.selectionEnd0 - this.selectionStart0));
                note.start = start;
                note.end = end;
                note.pitch += n2;
                note.velocity = (int)Math.min(127.0, Math.floor(n4 * note.velocity));
            }
            else {
                note.start += n;
                note.end = note.end + n + (long)Math.floor((n3 - 1.0) * (note.end - note.start));
                note.pitch += n2;
                note.velocity = (int)Math.min(127.0, Math.floor(n4 * note.velocity));
            }
            midiSwing.getTrack(note.track).remove(note.beginningEvent);
            midiSwing.getTrack(note.track).remove(note.endingEvent);
            if (note.lyric != null) {
                midiSwing.getTrack(note.lyric.trackNumber).remove(note.lyric.event);
            }
            final ShortMessage shortMessage = new ShortMessage();
            final ShortMessage shortMessage2 = new ShortMessage();
            final MetaMessage metaMessage = new MetaMessage();
            try {
                shortMessage.setMessage(144, note.channel, note.pitch, note.velocity);
                shortMessage2.setMessage(128, note.channel, note.pitch, note.velocity);
                if (note.lyric != null) {
                    metaMessage.setMessage(1, note.lyric.text.getBytes(), note.lyric.text.getBytes().length);
                }
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            final MidiEvent beginningEvent = new MidiEvent(shortMessage, note.start);
            final MidiEvent endingEvent = new MidiEvent(shortMessage2, note.end);
            midiSwing.getTrack(note.track).add(beginningEvent);
            midiSwing.getTrack(note.track).add(endingEvent);
            if (note.lyric != null) {
                final MidiEvent event = new MidiEvent(metaMessage, note.start);
                midiSwing.getTrack(note.lyric.trackNumber).add(event);
                note.lyric.event = event;
            }
            note.beginningEvent = beginningEvent;
            note.endingEvent = endingEvent;
            this.removeNote(note);
            this.addNote(note.track, note);
        }
        if (this.attachDataToNotes) {
            final Vector dataUnderSelectedNotes = this.findDataUnderSelectedNotes(false);
            for (int j = 0; j < dataUnderSelectedNotes.size(); ++j) {
                final Data data = dataUnderSelectedNotes.get(j);
                this.dataToBeRestored.add(data.copy());
                this.deleteData(data);
            }
            for (int k = 0; k < this.selectedData.size(); ++k) {
                final Data data2 = this.selectedData.get(k);
                if (n != 0L || n2 != 0 || n3 != 1.0 || n4 != 1.0 || this.selectionEnd0 != this.selectionEnd || this.selectionStart0 != this.selectionStart) {
                    this.dataToBeRemoved.add(data2);
                    this.dataToBeRestored.add(data2.copy());
                }
                if (this.midiWindow.altKey && this.selectionEnd != this.selectionStart && (this.selectionEnd0 != this.selectionEnd || this.selectionStart0 != this.selectionStart)) {
                    data2.start = this.selectionStart + (long)Math.floor((data2.start - this.selectionStart0) * (this.selectionEnd - this.selectionStart + 0.0) / (this.selectionEnd0 - this.selectionStart0));
                }
                else {
                    data2.start += n;
                }
                this.removeData(data2);
                this.insertData(data2.trackNumber, data2.channelNumber, data2.dataType, data2);
                this.alterData(data2);
            }
        }
        midiSwing.modification();
    }
    
    public void pasteClipboard(final long n) {
        final MidiSwing midiSwing = this.midiWindow.midiSwing;
        final int currentTrack = midiSwing.currentTrack;
        boolean b;
        if (midiSwing == PianoRoll.clipboardMidiSwing) {
            b = (currentTrack == PianoRoll.clipboardTrackNumber);
        }
        else {
            final Object[] array = { "This track", "Several tracks" };
            final Object showInputDialog = JOptionPane.showInputDialog(null, "would you like to paste on this track/channel or on several tracks/channels?", "What would like to do?", 2, null, array, array[0]);
            this.midiWindow.requestFocus();
            b = (showInputDialog != array[0]);
        }
        this.emptySelection();
        for (int i = 0; i < PianoRoll.clipboardNotes.size(); ++i) {
            final Note copy = PianoRoll.clipboardNotes.get(i).copy();
            copy.start += n;
            copy.end += n;
            if (b) {
                if (!midiSwing.isEnabledChannel(copy.channel)) {
                    midiSwing.enableChannel(copy.channel);
                }
                if (midiSwing.midiFileType == 1) {
                    if (midiSwing.trackWhoseMainChannelIs(copy.channel) == -1) {
                        midiSwing.createTrack(copy.channel);
                    }
                    copy.track = midiSwing.trackWhoseMainChannelIs(copy.channel);
                }
                else {
                    copy.track = midiSwing.currentTrack;
                }
            }
            else {
                copy.channel = midiSwing.currentChannel;
                copy.track = currentTrack;
            }
            copy.p = this;
            final ShortMessage shortMessage = new ShortMessage();
            final ShortMessage shortMessage2 = new ShortMessage();
            try {
                shortMessage.setMessage(144, copy.channel, copy.pitch, copy.velocity);
                shortMessage2.setMessage(128, copy.channel, copy.pitch, copy.velocity);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            final MidiEvent beginningEvent = new MidiEvent(shortMessage, copy.start);
            final MidiEvent endingEvent = new MidiEvent(shortMessage2, copy.end);
            midiSwing.getTrack(copy.track).add(beginningEvent);
            midiSwing.getTrack(copy.track).add(endingEvent);
            copy.beginningEvent = beginningEvent;
            copy.endingEvent = endingEvent;
            this.addNote(copy.track, copy);
            this.addNoteToSelection(copy);
            this.notesToBeRemoved.add(copy);
        }
        this.pianoRollGraph.repaint();
        if (this.attachDataToNotes) {
            final Vector dataUnderSelectedNotes = this.findDataUnderSelectedNotes(false);
            for (int j = 0; j < dataUnderSelectedNotes.size(); ++j) {
                final Data data = dataUnderSelectedNotes.get(j);
                this.dataToBeRestored.add(data.copy());
                this.deleteData(data);
            }
            for (int k = 0; k < PianoRoll.clipboardData.size(); ++k) {
                final Data copy2 = PianoRoll.clipboardData.get(k).copy();
                copy2.start += n;
                if (b) {
                    if (!midiSwing.isEnabledChannel(copy2.channelNumber)) {
                        midiSwing.enableChannel(copy2.channelNumber);
                    }
                    if (midiSwing.midiFileType == 1) {
                        if (midiSwing.trackWhoseMainChannelIs(copy2.channelNumber) == -1) {
                            midiSwing.createTrack(copy2.channelNumber);
                        }
                        copy2.trackNumber = midiSwing.trackWhoseMainChannelIs(copy2.channelNumber);
                    }
                    else {
                        copy2.trackNumber = midiSwing.currentTrack;
                    }
                }
                else {
                    copy2.channelNumber = midiSwing.currentChannel;
                    copy2.trackNumber = currentTrack;
                }
                (copy2.p = this).insertData(copy2.trackNumber, copy2.channelNumber, copy2.dataType, copy2);
                this.alterData(copy2);
                this.addDataToSelection(copy2);
                this.dataToBeRemoved.add(copy2);
            }
            this.controllerGraph.repaint();
        }
        this.midiWindow.midiSwing.modification();
    }
    
    public void restoreNotes() {
        final int currentTrack = this.midiWindow.midiSwing.currentTrack;
        this.emptySelection();
        for (int i = 0; i < this.notesToBeRemoved.size(); ++i) {
            final Note note = this.notesToBeRemoved.get(i);
            this.removeNoteFromSelection(note);
            this.deleteNote(note);
        }
        for (int j = 0; j < this.dataToBeRemoved.size(); ++j) {
            final Data data = this.dataToBeRemoved.get(j);
            this.removeDataFromSelection(data);
            this.deleteData(data);
        }
        for (int k = 0; k < this.notesToBeRestored.size(); ++k) {
            final Note note2 = this.notesToBeRestored.elementAt(k);
            this.addNote(note2.track, note2);
            if (note2.selected) {
                note2.selected = false;
            }
            final ShortMessage shortMessage = new ShortMessage();
            final ShortMessage shortMessage2 = new ShortMessage();
            try {
                shortMessage.setMessage(144, note2.channel, note2.pitch, note2.velocity);
                shortMessage2.setMessage(128, note2.channel, note2.pitch, note2.velocity);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
            final MidiEvent beginningEvent = new MidiEvent(shortMessage, note2.start);
            final MidiEvent endingEvent = new MidiEvent(shortMessage2, note2.end);
            this.midiWindow.midiSwing.getTrack(note2.track).add(beginningEvent);
            this.midiWindow.midiSwing.getTrack(note2.track).add(endingEvent);
            note2.beginningEvent = beginningEvent;
            note2.endingEvent = endingEvent;
            if (note2.lyric != null) {
                final MetaMessage metaMessage = new MetaMessage();
                try {
                    metaMessage.setMessage(1, note2.lyric.text.getBytes(), note2.lyric.text.getBytes().length);
                }
                catch (Exception ex2) {
                    ex2.printStackTrace();
                }
                final MidiEvent event = new MidiEvent(metaMessage, note2.start);
                this.midiWindow.midiSwing.getTrack(note2.lyric.trackNumber).add(event);
                note2.lyric.event = event;
            }
            this.addNoteToSelection(note2);
        }
        for (int l = 0; l < this.dataToBeRestored.size(); ++l) {
            final Data data2 = this.dataToBeRestored.elementAt(l);
            if (data2.selected) {
                data2.selected = false;
            }
            this.insertData(data2.trackNumber, data2.channelNumber, data2.dataType, data2);
            this.alterData(data2);
            this.addDataToSelection(data2);
        }
        this.notesToBeRestored.removeAllElements();
        this.notesToBeRemoved.removeAllElements();
        this.dataToBeRestored.removeAllElements();
        this.dataToBeRemoved.removeAllElements();
        this.midiWindow.midiSwing.modification();
        this.pianoRollGraph.repaint();
    }
    
    public long getLengthX() {
        return this.lengthX;
    }
    
    public int mapX(final long n) {
        return (int)Math.floor((n - this.viewPositionX) * this.scaleX / this.getResolution());
    }
    
    public int mapY(final int n) {
        return (int)Math.floor(12.0 + (this.lengthY - n - this.viewPositionY) * this.scaleY);
    }
    
    public int scaleX(final long n) {
        return (int)Math.round(this.scaleX * n / this.getResolution());
    }
    
    public int scaleY(final int n) {
        return (int)Math.floor(this.scaleY * n);
    }
    
    public long invertX(final int n) {
        return (long)Math.ceil(this.viewPositionX + n * this.getResolution() / this.scaleX);
    }
    
    public int invertY(final int n) {
        return (int)Math.ceil(this.lengthY - this.viewPositionY - (n - 12) / this.scaleY);
    }
    
    public void checkBounds() {
        final long n = (long)(this.pianoRollGraph.getWidth() * this.getResolution() / this.scaleX);
        if (this.playPosition > this.viewPositionX + n) {
            this.viewPositionX += n;
            this.updateScrollBarX();
        }
        if (this.playPosition < this.viewPositionX) {
            this.viewPositionX -= n;
            this.updateScrollBarX();
        }
        if (this.midiWindow.midiSwing.isPlaying() && this.selectionStart != this.selectionEnd && this.playPosition > Math.max(this.selectionEnd, this.selectionStart)) {
            if (this.midiWindow.midiSwing.isLoopOn()) {
                this.midiWindow.midiSwing.setPlayPosition(Math.min(this.selectionEnd, this.selectionStart), false);
            }
            else {
                this.midiWindow.midiSwing.stop();
            }
        }
    }
    
    public void setPlayPosition(final long playPosition, final boolean b) {
        this.playPosition = playPosition;
        if (!this.midiWindow.midiSwing.isPlaying()) {
            for (int i = 0; i < this.notesBeingScrubbed.size(); ++i) {
                final Note note = this.notesBeingScrubbed.get(i);
                if (note.start >= playPosition + 20L || note.end <= playPosition + 20L) {
                    this.notesBeingScrubbed.remove(note);
                    this.midiWindow.midiSwing.stopNote(note.channel, note.pitch, note.velocity);
                }
            }
        }
        if (this.midiWindow.keyboardMenuItem.isSelected()) {
            final int currentTrack = this.midiWindow.midiSwing.currentTrack;
            final int numberOfTracks = this.midiWindow.midiSwing.numberOfTracks;
            this.controllerGraph.releaseAllKeys();
            for (int j = 0; j < numberOfTracks; ++j) {
                for (int k = 0; k < this.getNumberOfNotesInTrack(j); ++k) {
                    final Note note2 = this.getNote(j, k);
                    if (this.midiWindow.channelButton[note2.channel].isSelected()) {
                        Color velocityColor;
                        if (j == currentTrack || !this.singleTrackDisplay) {
                            velocityColor = MidiWindow.velocityColor(MidiWindow.channelColor[note2.channel], note2.velocity);
                        }
                        else {
                            velocityColor = new Color(120, 120, 120);
                        }
                        if (note2.start < playPosition + 20L && note2.end > playPosition + 20L) {
                            if (this.controllerType == 0) {
                                if (this.animateKeyboard) {
                                    this.controllerGraph.hitKey(note2.pitch, velocityColor);
                                }
                            }
                            else {
                                this.controllerGraph.repaint();
                            }
                            if (!this.midiWindow.midiSwing.isPlaying() && b && !this.notesBeingScrubbed.contains(note2)) {
                                this.notesBeingScrubbed.add(note2);
                                this.midiWindow.midiSwing.playNote(note2.channel, playPosition, note2.pitch, note2.velocity);
                            }
                        }
                    }
                }
            }
        }
        if (this.midiWindow.midiSwing.isPlaying()) {
            this.checkBounds();
        }
        if (this.midiWindow.pianoRollMenuItem.isSelected()) {
            this.pianoRollGraph.repaint();
            this.controllerGraph.repaint();
        }
    }
    
    public void update(final long endOfCurrentTrack) {
        if (this.singleTrackDisplay) {
            this.endOfCurrentTrack = endOfCurrentTrack;
        }
        else {
            this.endOfCurrentTrack = this.midiWindow.midiSwing.getSequenceLength();
        }
        this.pianoRollGraph.repaint();
        this.controllerGraph.repaint();
        this.midiWindow.updateProgressBar(this.midiWindow.midiSwing.getSequenceLength());
    }
    
    public void updateLengthX(final long lengthX) {
        this.lengthX = lengthX;
        this.midiWindow.updateProgressBar(lengthX);
        this.pianoRollGraph.repaint();
        this.updateScrollBarX();
    }
    
    public void compareThenUpdateLengthX(final long n) {
        if (n > this.lengthX) {
            this.updateLengthX(n);
        }
    }
    
    public void increaseViewPositionX(final long n) {
        this.viewPositionX = Math.max(0L, this.viewPositionX + n);
        this.updateScrollBarX();
    }
    
    public void updateViewPositionX(final long viewPositionX) {
        this.viewPositionX = viewPositionX;
        this.updateScrollBarX();
    }
    
    public void updateScrollBarX() {
        this.scrollBarX.setVisibleAmount(this.pianoRollGraph.getWidth());
        this.scrollBarX.setMaximum(this.scaleX(this.lengthX) + 400);
        this.scrollBarX.setBlockIncrement(this.pianoRollGraph.getWidth());
        this.scrollBarX.setUnitIncrement(this.pianoRollGraph.getWidth() / 12);
        this.scrollBarX.setValue(this.scaleX(this.viewPositionX));
        this.scrollBarX.repaint();
    }
    
    public void updateScrollBarY() {
        this.scrollBarY.setVisibleAmount(this.pianoRollGraph.getHeight());
        this.scrollBarY.setValue((int)Math.floor(this.scaleY * this.viewPositionY));
        this.scrollBarY.setMaximum((int)Math.floor(this.scaleY * this.lengthY));
        this.scrollBarY.setBlockIncrement(this.pianoRollGraph.getHeight() / 6);
        this.scrollBarY.setUnitIncrement(this.pianoRollGraph.getHeight() / 12);
        this.scrollBarY.repaint();
    }
    
    public void updateModeButtons() {
        switch (this.mode2) {
            case 1: {
                this.modePlayButton.setSelected(true);
                this.modeSelectButton.setSelected(false);
                this.modeInsertButton.setSelected(false);
                this.pianoRollGraph.setCursor(this.cursorWhile[1]);
                if (this.controllerType == 0) {
                    this.controllerGraph.setCursor(this.arrowCursor);
                    break;
                }
                this.controllerGraph.setCursor(this.cursorWhile[1]);
                break;
            }
            case 2: {
                this.modePlayButton.setSelected(false);
                this.modeSelectButton.setSelected(true);
                this.modeInsertButton.setSelected(false);
                this.pianoRollGraph.setCursor(this.cursorWhile[2]);
                if (this.controllerType == 0) {
                    this.controllerGraph.setCursor(this.arrowCursor);
                    break;
                }
                this.controllerGraph.setCursor(this.cursorWhile[2]);
                break;
            }
            case 4: {
                this.modePlayButton.setSelected(false);
                this.modeSelectButton.setSelected(false);
                this.modeInsertButton.setSelected(true);
                this.pianoRollGraph.setCursor(this.cursorWhile[4]);
                if (this.controllerType == 0) {
                    this.controllerGraph.setCursor(this.fingerCursor);
                    break;
                }
                this.controllerGraph.setCursor(this.cursorWhile[4]);
                break;
            }
        }
    }
    
    public void setMode(final int n) {
        this.mode = n;
        this.mode2 = n;
        this.updateModeButtons();
    }
    
    public void switchMode() {
        int mode = 1;
        switch (this.mode2) {
            case 1: {
                mode = 2;
                break;
            }
            case 2: {
                mode = 4;
                break;
            }
            case 4: {
                mode = 1;
                break;
            }
        }
        this.setMode(mode);
    }
    
    public void assignLyricsToTrack(int n) {
        if (this.midiWindow.midiSwing.midiFileType == 1) {
            if (n == -1) {
                final int itemCount = this.midiWindow.trackChooser.getItemCount();
                final String[] array = new String[itemCount];
                for (int i = 0; i < itemCount; ++i) {
                    array[i] = (String)this.midiWindow.trackChooser.getItemAt(i);
                }
                final MidiSwing midiSwing = this.midiWindow.midiSwing;
                final Object showInputDialog = JOptionPane.showInputDialog(this, MidiSwing.resource.getString("MSG_CHOOSE_THE_MELODY_TRACK"), "input", 1, null, array, array[this.midiWindow.midiSwing.currentTrack]);
                if (showInputDialog != null) {
                    for (int j = 0; j < itemCount; ++j) {
                        if (((String)showInputDialog).equals(array[j])) {
                            n = j;
                        }
                    }
                    this.assignLyricsToTrack(n, true);
                }
            }
            else {
                this.assignLyricsToTrack(n, true);
            }
        }
    }
    
    public void assignLyricsToTrack(int n, final boolean b) {
        final Vector lyrics = this.midiWindow.midiSwing.lyrics;
        if (b) {
            if (lyrics.size() != this.getNumberOfNotesInTrack(n)) {
                final MidiSwing midiSwing = this.midiWindow.midiSwing;
                final String string = MidiSwing.resource.getString("MSG_LYRICS_DO_NOT_MATCH");
                final MidiSwing midiSwing2 = this.midiWindow.midiSwing;
                final int showConfirmDialog = JOptionPane.showConfirmDialog(this, string, MidiSwing.resource.getString("MSG_WARNING"), 1, 2);
                this.midiWindow.requestFocus();
                switch (showConfirmDialog) {
                    case 0: {
                        this.assignLyricsToTrack(n, false);
                    }
                    case 1: {}
                }
            }
            else {
                this.assignLyricsToTrack(n, false);
            }
        }
        else {
            this.notesToBeRemoved.removeAllElements();
            this.notesToBeRestored.removeAllElements();
            for (int n2 = 0, n3 = 0; n2 < lyrics.size() && n3 < this.getNumberOfNotesInTrack(n); ++n2, ++n3) {
                final Lyric lyric = lyrics.get(n2);
                final Note note = this.getNote(n, n3);
                this.notesToBeRestored.add(note.copy());
                this.notesToBeRemoved.add(note);
                if (lyric.event == null) {
                    try {
                        final MetaMessage metaMessage = new MetaMessage();
                        metaMessage.setMessage(1, lyric.text.getBytes(), lyric.text.length());
                        final MidiEvent event = new MidiEvent(metaMessage, note.start);
                        if (this.midiWindow.midiSwing.lyricsTrackNumber == -1) {
                            this.midiWindow.midiSwing.newLyric();
                            n += 2;
                        }
                        lyric.trackNumber = this.midiWindow.midiSwing.lyricsTrackNumber;
                        this.midiWindow.midiSwing.getTrack(this.midiWindow.midiSwing.lyricsTrackNumber).add(event);
                        lyric.event = event;
                    }
                    catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                if (Math.abs(lyric.event.getTick() - note.start) < this.midiWindow.midiSwing.getResolution() / 4) {
                    note.setLyric(lyric);
                }
                else {
                    --n2;
                }
            }
        }
    }
    
    public void keyPressed(final KeyEvent keyEvent) {
        if ((keyEvent.getKeyCode() == 157 || keyEvent.getKeyCode() == 17) && this.mode2 != 3 && this.mode2 != 5 && this.rememberMode == 0) {
            if (this.mode == 4) {
                this.mode2 = 2;
            }
            if (this.mode == 2) {
                this.mode2 = 4;
            }
            this.updateModeButtons();
        }
    }
    
    public void keyReleased(final KeyEvent keyEvent) {
        if ((keyEvent.getKeyCode() == 157 || keyEvent.getKeyCode() == 17) && this.mode2 != 3 && this.mode2 != 5 && this.rememberMode == 0) {
            this.mode2 = this.mode;
            this.updateModeButtons();
        }
    }
    
    public void eventReceived(final Event event) {
        System.out.println("Evenement re\u00c1u !");
    }
    
    public static void main(final String[] array) {
        final PianoRoll pianoRoll = new PianoRoll((MidiWindow)null);
        pianoRoll.setSize(400, 400);
        final JFrame frame = new JFrame();
        frame.getContentPane().add(pianoRoll, "Center");
        frame.setSize(500, 200);
        frame.setDefaultCloseOperation(3);
        frame.setVisible(true);
    }
    
    static {
        controllerChooserList = new int[] { 0, 1, 2, 3, 4, 5, 10, 6, 7 };
        PianoRoll.clipboardNotes = new Vector();
        PianoRoll.clipboardData = new Vector();
        PianoRoll.clipboardTrackNumber = 0;
        PianoRoll.clipboardMidiSwing = null;
    }
    
    class ComboBoxRenderer extends JLabel implements ListCellRenderer
    {
        public ComboBoxRenderer() {
            this.setOpaque(true);
            this.setHorizontalAlignment(0);
            this.setVerticalAlignment(0);
        }
        
        public Component getListCellRendererComponent(final JList list, final Object o, final int n, final boolean b, final boolean b2) {
            if (b) {
                this.setBackground(list.getSelectionBackground());
                this.setForeground(list.getSelectionForeground());
            }
            else {
                this.setBackground(list.getBackground());
                this.setForeground(list.getForeground());
            }
            this.setIcon((Icon)o);
            return this;
        }
    }
}
