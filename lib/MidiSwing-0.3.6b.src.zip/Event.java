// 
// Decompiled by Procyon v0.5.30
// 

public class Event
{
    private Object source;
    public int message;
    public static final int PLAY = 1;
    public static final int STOP = 2;
    public static final int REWIND = 3;
    public static final int RECORD = 4;
    public static final int LOOP = 5;
    
    public Event(final int message, final Object source) {
        this.message = message;
        this.source = source;
    }
    
    public Object getSource() {
        return this.source;
    }
}
