import java.util.Vector;

// 
// Decompiled by Procyon v0.5.30
// 

public class InstrumentKit
{
    public Vector instrumentName;
    public Vector instrumentPreset;
    public Vector instrumentBank;
    
    public InstrumentKit() {
        this.instrumentName = new Vector();
        this.instrumentPreset = new Vector();
        this.instrumentBank = new Vector();
    }
    
    public int size() {
        return this.instrumentName.size();
    }
    
    public void add(final String s, final int n, final int n2) {
        this.instrumentName.add(s);
        this.instrumentPreset.add(new Integer(n));
        this.instrumentBank.add(new Integer(n2));
    }
    
    public String getName(final int n) {
        return this.instrumentName.get(n);
    }
    
    public int getPreset(final int n) {
        return this.instrumentPreset.get(n);
    }
    
    public int getBank(final int n) {
        return this.instrumentBank.get(n);
    }
    
    public String getName(final int n, final int n2) {
        String name = "";
        int n3 = 1;
        int n4 = 0;
        while (n3 != 0 && n4 < this.instrumentName.size()) {
            if (this.getPreset(n4) == n && this.getBank(n4) == n2) {
                n3 = 0;
            }
            else {
                ++n4;
            }
        }
        if (n3 == 0) {
            name = this.getName(n4);
        }
        return name;
    }
    
    public InstrumentKit getSubkitForPreset(final int n) {
        final InstrumentKit instrumentKit = new InstrumentKit();
        for (int i = 0; i < this.instrumentName.size(); ++i) {
            if (this.getPreset(i) == n && this.getBank(i) != 128) {
                instrumentKit.add(this.getName(i), n, this.getBank(i));
            }
        }
        return instrumentKit;
    }
    
    public InstrumentKit getSubkitForBank(final int n) {
        final InstrumentKit instrumentKit = new InstrumentKit();
        for (int i = 0; i < this.instrumentName.size(); ++i) {
            if (this.getBank(i) == n) {
                instrumentKit.add(this.getName(i), this.getPreset(i), n);
            }
        }
        return instrumentKit;
    }
    
    public static InstrumentKit getGM_Kit() {
        final InstrumentKit instrumentKit = new InstrumentKit();
        for (int i = 0; i < 128; ++i) {
            instrumentKit.add(MidiConstants.getGMinstrumentName(i), i, -1);
        }
        instrumentKit.add(MidiConstants.getGMdrumsetName(0), 0, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(8), 8, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(16), 16, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(24), 24, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(25), 25, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(32), 32, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(40), 40, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(48), 48, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(56), 56, 128);
        instrumentKit.add(MidiConstants.getGMdrumsetName(127), 127, 128);
        return instrumentKit;
    }
}
