import java.awt.event.ActionEvent;
import javax.swing.JRadioButtonMenuItem;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import java.awt.GridBagConstraints;
import java.awt.Component;
import javax.swing.BorderFactory;
import javax.swing.JPanel;

// 
// Decompiled by Procyon v0.5.30
// 

public class MidiWindowQT extends MidiWindow
{
    public MidiWindowQT(final MidiSwing midiSwing, final String s) {
        super(midiSwing, s);
        System.out.println("coucou-----------------------------------");
        final JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(1, 10, 1, 10));
        panel.add(((MidiSwingQT)this.midiSwing).videoPanel);
        final GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 0.0;
        gridBagConstraints.weighty = 0.0;
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        this.topPane.add(panel, gridBagConstraints);
        final MidiSwing midiSwing2 = this.midiSwing;
        final JMenu menu = new JMenu(MidiSwing.resource.getString("VIDEO"));
        this.menuBar.add(menu);
        final MidiSwing midiSwing3 = this.midiSwing;
        final JMenuItem menuItem = new JMenuItem(MidiSwing.resource.getString("OPEN_VIDEO"));
        menuItem.setActionCommand("OPEN_VIDEO");
        menuItem.addActionListener(this);
        menu.add(menuItem);
        final MidiSwing midiSwing4 = this.midiSwing;
        final JMenuItem menuItem2 = new JMenuItem(MidiSwing.resource.getString("CLOSE_VIDEO"));
        menuItem2.setActionCommand("CLOSE_VIDEO");
        menuItem2.addActionListener(this);
        menu.add(menuItem2);
        menu.addSeparator();
        final MidiSwing midiSwing5 = this.midiSwing;
        final JRadioButtonMenuItem radioButtonMenuItem = new JRadioButtonMenuItem(MidiSwing.resource.getString("PLAY_VIDEO"));
        radioButtonMenuItem.setActionCommand("PLAY_VIDEO");
        radioButtonMenuItem.addActionListener(this);
        radioButtonMenuItem.setSelected(false);
        menu.add(radioButtonMenuItem);
    }
    
    @Override
    public void actionPerformed(final ActionEvent actionEvent) {
        super.actionPerformed(actionEvent);
        if (actionEvent.getActionCommand() == "OPEN_VIDEO") {
            ((MidiSwingQT)this.midiSwing).openMovie();
        }
        if (actionEvent.getActionCommand() == "CLOSE_VIDEO") {
            ((MidiSwingQT)this.midiSwing).closeMovie();
        }
        if (actionEvent.getActionCommand() == "PLAY_VIDEO") {
            ((MidiSwingQT)this.midiSwing).switchVideo();
        }
    }
}
