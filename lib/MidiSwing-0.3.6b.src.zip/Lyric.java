import javax.sound.midi.MidiEvent;

// 
// Decompiled by Procyon v0.5.30
// 

public class Lyric
{
    public int trackNumber;
    public String text;
    public MidiEvent event;
    
    public Lyric(final int trackNumber, final String text, final MidiEvent event) {
        this.trackNumber = trackNumber;
        this.text = text;
        this.event = event;
    }
    
    public void setEvent(final MidiEvent event) {
        this.event = event;
    }
    
    public Lyric copy() {
        return new Lyric(this.trackNumber, this.text, this.event);
    }
    
    public void setText(final String text) {
        this.text = text;
    }
    
    public void setLyric(final int trackNumber, final String text, final MidiEvent event) {
        this.trackNumber = trackNumber;
        this.text = text;
        this.event = event;
    }
}
