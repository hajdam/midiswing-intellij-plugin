import java.io.File;
import javax.swing.filechooser.FileFilter;

// 
// Decompiled by Procyon v0.5.30
// 

public class MidiFilter extends FileFilter
{
    public boolean accept(final File file) {
        if (file.isDirectory()) {
            return true;
        }
        final String extension = getExtension(file);
        return extension != null && (extension.equals("mid") || extension.equals("midi") || extension.equals("kar"));
    }
    
    public String getDescription() {
        return "MIDI Files";
    }
    
    public static String getExtension(final File file) {
        String lowerCase = null;
        final String name = file.getName();
        final int lastIndex = name.lastIndexOf(46);
        if (lastIndex > 0 && lastIndex < name.length() - 1) {
            lowerCase = name.substring(lastIndex + 1).toLowerCase();
        }
        return lowerCase;
    }
}
