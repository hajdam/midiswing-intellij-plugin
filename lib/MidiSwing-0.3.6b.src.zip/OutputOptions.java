import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.Dimension;
import java.awt.Component;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.LayoutManager;
import java.awt.GridBagLayout;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.JFrame;

// 
// Decompiled by Procyon v0.5.30
// 

public class OutputOptions extends JFrame
{
    private JButton okButton;
    private MidiSwing midiSwing;
    private JSpinner shiftSpinner;
    
    public OutputOptions(final MidiWindow midiWindow) {
        final MidiSwing midiSwing = midiWindow.midiSwing;
        super(MidiSwing.resource.getString("OUTPUT_OPTIONS"));
        this.midiSwing = midiWindow.midiSwing;
        this.setLayout(new GridBagLayout());
        final GridBagConstraints gridBagConstraints = new GridBagConstraints();
        gridBagConstraints.weightx = 0.5;
        gridBagConstraints.weighty = 0.5;
        final JLabel label = new JLabel("Pitch shift");
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        this.add(label, gridBagConstraints);
        (this.shiftSpinner = new JSpinner()).setValue(0);
        this.shiftSpinner.setMinimumSize(new Dimension(60, 20));
        this.shiftSpinner.addChangeListener(new ChangeListener() {
            public void stateChanged(final ChangeEvent changeEvent) {
                OutputOptions.this.midiSwing.setOutputShift((int)OutputOptions.this.shiftSpinner.getValue());
            }
        });
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        this.add(this.shiftSpinner, gridBagConstraints);
        this.okButton = new JButton("OK");
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        this.add(this.okButton, gridBagConstraints);
        this.okButton.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent actionEvent) {
                OutputOptions.this.setVisible(false);
            }
        });
        this.setSize(new Dimension(400, 300));
    }
}
