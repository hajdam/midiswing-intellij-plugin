import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import java.awt.Container;
import java.awt.LayoutManager;
import javax.swing.BoxLayout;
import quicktime.QTSession;
import quicktime.QTException;
import quicktime.qd.QDRect;
import java.awt.Component;
import javax.swing.JComponent;
import quicktime.app.view.QTFactory;
import quicktime.std.movies.media.DataRef;
import java.awt.Dimension;
import quicktime.app.view.QTJComponent;
import quicktime.app.view.MoviePlayer;
import quicktime.std.movies.Movie;
import javax.swing.JDialog;
import quicktime.Errors;
import javax.swing.JPanel;

// 
// Decompiled by Procyon v0.5.30
// 

public class VideoPanel extends JPanel implements Errors
{
    private JDialog errorDialog;
    private Movie movie;
    private MoviePlayer moviePlayer;
    private QTJComponent qtjc;
    
    public VideoPanel() {
        this.qtjc = null;
        this.setPreferredSize(new Dimension(160, 90));
        this.movie = null;
        this.moviePlayer = null;
    }
    
    public void createNewMovieFromURL(final String s) {
        try {
            this.movie = Movie.fromDataRef(new DataRef(s), 1);
            this.moviePlayer = new MoviePlayer(this.movie);
            if (this.qtjc == null) {
                this.qtjc = QTFactory.makeQTJComponent(this.moviePlayer);
                this.removeAll();
                this.add((Component)this.qtjc);
            }
            else {
                this.qtjc.setMoviePlayer(this.moviePlayer);
            }
            this.movie.setBox(new QDRect(160, 90));
        }
        catch (QTException ex) {
            ex.printStackTrace();
        }
    }
    
    public MoviePlayer getMoviePlayer() {
        return this.moviePlayer;
    }
    
    public Movie getMovie() throws QTException {
        return this.movie;
    }
    
    public void closeMovie() {
        try {
            if (this.qtjc != null) {
                this.qtjc.setMoviePlayer((MoviePlayer)null);
                this.movie = null;
                this.qtjc = null;
                this.repaint();
            }
        }
        catch (QTException ex) {}
    }
    
    public void goAway() {
        try {
            if (this.qtjc != null) {
                this.qtjc.setMoviePlayer((MoviePlayer)null);
            }
        }
        catch (QTException ex) {}
        QTSession.close();
        System.exit(0);
    }
    
    int getTime() {
        int time = -1;
        try {
            if (this.movie != null) {
                time = this.moviePlayer.getTime();
            }
        }
        catch (QTException ex) {
            ex.printStackTrace();
        }
        return time;
    }
    
    void setTime(final int time) {
        try {
            if (this.movie != null) {
                this.workaround();
                this.moviePlayer.setTime(time);
            }
        }
        catch (QTException ex) {
            ex.printStackTrace();
        }
    }
    
    void workaround() {
        try {
            this.qtjc.setMoviePlayer((MoviePlayer)null);
            this.moviePlayer = null;
            this.moviePlayer = new MoviePlayer(this.movie);
            this.qtjc = QTFactory.makeQTJComponent(this.moviePlayer);
            this.removeAll();
            this.add((Component)this.qtjc);
            this.movie.setBox(new QDRect(160, 90));
        }
        catch (QTException ex) {
            ex.printStackTrace();
        }
    }
    
    void startPlayer() {
        try {
            if (this.movie != null) {
                this.workaround();
                this.movie.setRate(1.0f);
            }
        }
        catch (QTException ex) {
            ex.printStackTrace();
        }
    }
    
    void stopPlayer() {
        try {
            if (this.movie != null) {
                this.movie.setRate(0.0f);
            }
        }
        catch (QTException ex) {
            ex.printStackTrace();
        }
    }
    
    private void showErrorDialog(final String s) {
        (this.errorDialog = new JDialog()).setModal(true);
        this.errorDialog.setResizable(false);
        final Container contentPane = this.errorDialog.getContentPane();
        contentPane.setLayout(new BoxLayout(contentPane, 1));
        final JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, 1));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        final JLabel label = new JLabel(s);
        label.setMaximumSize(new Dimension(270, 20));
        panel.add(label);
        final JPanel panel2 = new JPanel();
        panel2.setLayout(new BoxLayout(panel2, 1));
        panel2.setBorder(BorderFactory.createEmptyBorder(5, 125, 15, 10));
        final JButton button = new JButton("OK");
        button.setMaximumSize(new Dimension(70, 20));
        panel2.add(button);
        this.errorDialog.getContentPane().add(panel, "South");
        this.errorDialog.getContentPane().add(panel2, "South");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(final ActionEvent actionEvent) {
                VideoPanel.this.errorDialog.dispose();
            }
        });
        this.errorDialog.setBounds(0, 0, 300, 100);
        this.errorDialog.show();
    }
}
